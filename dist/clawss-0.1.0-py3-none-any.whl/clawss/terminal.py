import asyncio
import os
import socket
import sys
from typing import Dict, Optional

# ── PTY backend ────────────────────────────────────────────────────────────────
# Windows → pywinpty   (pip install pywinpty)
# Linux/Mac → ptyprocess  (pip install ptyprocess)
_PtyProcess = None
_IS_WINPTY = False

if sys.platform == "win32":
    try:
        from winpty import PtyProcess as _PtyProcess  # type: ignore
        _IS_WINPTY = True
    except ImportError:
        pass
else:
    try:
        from ptyprocess import PtyProcess as _PtyProcess  # type: ignore
    except ImportError:
        pass
    try:
        import fcntl
    except ImportError:
        fcntl = None  # type: ignore


def _unix_shell_argv(shell: str) -> list[str]:
    shell_name = os.path.basename(shell).lower()
    if shell_name in {"bash", "sh", "dash", "ksh"}:
        return [shell, "--norc", "--noprofile"]
    if shell_name == "zsh":
        return [shell, "-f"]
    return [shell]


class TerminalSession:
    def __init__(self, session_id: str, cwd: str, cols: int = 120, rows: int = 30):
        self.session_id = session_id
        self.cwd = cwd
        self.cols = cols
        self.rows = rows
        self._pty = None

    async def start(self):
        if _PtyProcess is None:
            pkg = "pywinpty" if sys.platform == "win32" else "ptyprocess"
            raise RuntimeError(
                f"Terminal requires {pkg}.\r\n"
                f"Run:  pip install {pkg}\r\n"
                "Then restart the backend."
            )

        if sys.platform == "win32":
            win_env = {
                **os.environ,
                "PYTHONIOENCODING": "utf-8",
                "VIRTUAL_TERMINAL_LEVEL": "1",
            }
            self._pty = _PtyProcess.spawn(
                ["powershell.exe", "-NoLogo", "-NoProfile", "-NoExit"],
                dimensions=(self.rows, self.cols),
                cwd=self.cwd,
                env=win_env,
            )
            # Prevent read() from blocking forever — timeout after 100ms
            self._pty.fileobj.settimeout(0.1)
            # Setup commands — identical to what the Node.js server sends.
            # Single line with ; separators ending with Clear-Host\r
            # Clear-Host wipes the terminal on the frontend — no server-side draining needed.
            self._pending_setup = (
                "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
                "[Console]::InputEncoding=[System.Text.Encoding]::UTF8; "
                "$OutputEncoding=[System.Text.Encoding]::UTF8; "
                "chcp 65001|Out-Null; "
                'function prompt{"$([char]27)[32m>_ "}; '
                "Clear-Host\r"
            )
        else:
            shell = os.environ.get("SHELL", "/bin/bash")
            self._pty = _PtyProcess.spawn(
                _unix_shell_argv(shell),
                dimensions=(self.rows, self.cols),
                cwd=self.cwd,
                env={
                    **os.environ,
                    "TERM": "xterm-256color",
                    "PS1": "\\[\\033[32m\\]>_ \\[\\033[36m\\]\\W\\[\\033[0m\\]> ",
                },
            )
            # Make reads non-blocking so read_loop doesn't hang
            try:
                if fcntl is not None:
                    flags = fcntl.fcntl(self._pty.fd, fcntl.F_GETFL)
                    fcntl.fcntl(self._pty.fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
            except Exception:
                pass
            self._pending_setup = None

    async def send_setup_after_delay(self):
        """Wait for the shell to initialize, then send setup commands.
        Matches the Node.js server approach: no draining, no intercepting.
        Clear-Host in the setup commands wipes the frontend terminal visually."""
        if not self._pending_setup or not self._pty:
            return
        await asyncio.sleep(0.5)
        text = self._pending_setup
        self._pending_setup = None
        try:
            if _IS_WINPTY:
                await asyncio.to_thread(self._pty.write, text)
            else:
                await asyncio.to_thread(self._pty.write, text.encode("utf-8"))
        except Exception:
            pass

    async def read(self) -> Optional[bytes]:
        if self._pty is None:
            return None
        try:
            data = await asyncio.to_thread(self._pty.read, 4096)
            if not data:
                return None
            # pywinpty returns str; ptyprocess returns bytes
            return data.encode("utf-8", errors="replace") if isinstance(data, str) else data
        except (socket.timeout, TimeoutError, BlockingIOError):
            # No data available right now (pywinpty timeout / ptyprocess non-blocking)
            return None
        except EOFError:
            # PTY closed
            return None
        except Exception:
            return None

    async def write(self, data: bytes):
        if self._pty is None:
            return
        try:
            if _IS_WINPTY:
                # pywinpty expects str
                await asyncio.to_thread(
                    self._pty.write, data.decode("utf-8", errors="replace")
                )
            else:
                # ptyprocess expects bytes
                await asyncio.to_thread(self._pty.write, data)
        except Exception:
            pass

    def resize(self, cols: int, rows: int):
        self.cols, self.rows = cols, rows
        if self._pty:
            try:
                self._pty.setwinsize(rows, cols)
            except Exception:
                pass

    def close(self):
        if self._pty:
            try:
                self._pty.terminate()
            except Exception:
                pass


class TerminalManager:
    def __init__(self):
        self.sessions: Dict[str, TerminalSession] = {}

    async def create(self, session_id: str, cwd: str) -> TerminalSession:
        session = TerminalSession(session_id, cwd)
        await session.start()
        self.sessions[session_id] = session
        return session

    def get(self, session_id: str) -> Optional[TerminalSession]:
        return self.sessions.get(session_id)

    def close(self, session_id: str):
        s = self.sessions.pop(session_id, None)
        if s:
            s.close()
