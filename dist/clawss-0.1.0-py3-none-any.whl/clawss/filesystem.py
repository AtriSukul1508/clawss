import json
from pathlib import Path
from typing import List, Optional

ICON_MAP = {
    ".py": "python",
    ".ipynb": "notebook",
    ".mpynb": "notebook",
    ".md": "markdown",
    ".csv": "csv",
    ".json": "json",
    ".txt": "text",
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".gif": "image",
    ".svg": "svg",
    ".html": "html",
    ".css": "css",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".env": "env",
    ".sh": "shell",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
    ".xml": "xml",
    ".pdf": "pdf",
    ".zip": "archive",
}

SKIP = {"__pycache__", "__cells__", "__mpynb__", ".git", ".mpynb_snapshots", "node_modules", ".venv", "venv"}


def file_type(path: Path) -> str:
    return ICON_MAP.get(path.suffix.lower(), "file")


def build_tree(root: Path, base: Optional[Path] = None) -> List[dict]:
    if base is None:
        base = root
    items = []
    try:
        entries = sorted(
            root.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())
        )
    except PermissionError:
        return items

    for entry in entries:
        if entry.name in SKIP:
            continue
        # Hide all dotfiles/dotdirs from the project tree.
        if entry.name.startswith("."):
            continue
        rel = str(entry.relative_to(base)).replace("\\", "/")
        if entry.is_dir():
            items.append(
                {
                    "id": rel,
                    "name": entry.name,
                    "type": "directory",
                    "children": build_tree(entry, base),
                }
            )
        else:
            node = {
                "id": rel,
                "name": entry.name,
                "type": file_type(entry),
                "size": entry.stat().st_size,
            }
            # Embed cell metadata for .mpynb files so the frontend can
            # expand them as virtual notebook folders in the Project sidebar.
            if entry.suffix.lower() == ".mpynb":
                try:
                    data = json.loads(entry.read_text(encoding="utf-8"))
                    node["cells"] = [
                        {"filename": c.get("filename", "")}
                        for c in data.get("cells", [])
                    ]
                except (json.JSONDecodeError, OSError):
                    pass
            items.append(node)
    return items
