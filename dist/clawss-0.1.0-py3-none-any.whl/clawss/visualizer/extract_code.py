"""Generate kernel-side extract script: build graph.json for one nn.Module instance.

5-strategy fallback chain:
  1. torchview            (library, op-level DAG with branches)
  2. torch.fx             (PyTorch built-in symbolic trace)
  3. torch.jit.trace      (PyTorch built-in concrete trace)
  4. torch.onnx.export    (PyTorch built-in via ONNX) + onnxsim post-process
  5. static + hooks       (custom, always works)

Each strategy is fully isolated. Failure of one is recorded as a warning
and never affects the next. First non-empty result wins.

Edge cases handled inside the kernel script:
  • Model.device honoured — dummy tensors moved to model's device
  • Original train/eval state restored after extraction
  • Multi-input tuples / dict outputs walked recursively for shapes
  • CUDA OOM caught → CPU retry of the failing strategy only
  • BatchNorm-with-batch-size-1 caught → suggest batch >= 2
  • Deep tree truncated at depth 50 to avoid pathological models
  • Disconnected nodes pruned from data-edge sequence
  • Hooks always removed (try/finally), even on forward error
  • Block detection collapses repeating Conv→Norm→Act patterns into macro nodes
  • onnxsim simplifies ONNX graph (constant fold, dead-node elim, identity drop)
"""
import json
from typing import Any, Dict


_TEMPLATE = r"""
import json as __viz_json, sys as __viz_sys, io as __viz_io
__viz_payload = __viz_json.loads(__VIZ_PAYLOAD_JSON__)
__viz_result = {"meta": {}, "nodes": [], "edges": [], "warnings": []}
__viz_emitted = [False]

def __viz_emit():
    if __viz_emitted[0]:
        return
    __viz_emitted[0] = True
    print("__MPYNB_VIZ_EXTRACT__" + __viz_json.dumps(__viz_result))

def __viz_fail(msg):
    __viz_result["meta"]["error"] = str(msg)
    __viz_emit()

try:
    import torch as __viz_torch
    import torch.nn as __viz_nn
except Exception as __viz_e:
    __viz_fail("torch not available: " + str(__viz_e))
else:
    __viz_mod_name = __viz_payload["module_name"]
    __viz_var_name = __viz_payload["var_name"]
    __viz_input_specs = __viz_payload["inputs"]
    __viz_max_depth = 50  # truncate pathological recursion

    __viz_mod = __viz_sys.modules.get(__viz_mod_name)
    if __viz_mod is None:
        __viz_fail("cell module not in kernel — run the cell first")
    elif not __viz_input_specs:
        __viz_fail("at least one input spec required")
    else:
        __viz_model = getattr(__viz_mod, "__dict__", {}).get(__viz_var_name)
        if __viz_model is None or not isinstance(__viz_model, __viz_nn.Module):
            __viz_fail("variable '%s' is not an nn.Module" % __viz_var_name)
        else:
            # ── Save & restore model state ─────────────────────────────────
            __viz_was_training = __viz_model.training
            try:
                __viz_dev = next(__viz_model.parameters()).device
            except StopIteration:
                __viz_dev = __viz_torch.device("cpu")

            # ── Build dummy inputs on the right device ─────────────────────
            __viz_dtype_map = {
                "float32": __viz_torch.float32, "float": __viz_torch.float32,
                "float16": __viz_torch.float16, "half": __viz_torch.float16,
                "bfloat16": __viz_torch.bfloat16,
                "float64": __viz_torch.float64, "double": __viz_torch.float64,
                "int32": __viz_torch.int32, "int": __viz_torch.int32,
                "int64": __viz_torch.int64, "long": __viz_torch.int64,
                "uint8": __viz_torch.uint8, "bool": __viz_torch.bool,
            }
            __viz_dummies = []
            __viz_input_labels = []
            try:
                for __viz_spec in __viz_input_specs:
                    __viz_name = str(__viz_spec.get("name", "")).strip()
                    __viz_dt = __viz_dtype_map.get(
                        str(__viz_spec.get("dtype", "float32")).lower(),
                        __viz_torch.float32,
                    )
                    __viz_shape = tuple(int(x) for x in __viz_spec["shape"])
                    if not __viz_shape:
                        raise ValueError("empty shape")
                    if __viz_dt in (__viz_torch.int32, __viz_torch.int64, __viz_torch.uint8):
                        __viz_high = int(__viz_spec.get("high", 1000))
                        __viz_t = __viz_torch.randint(
                            0, max(__viz_high, 2), __viz_shape, dtype=__viz_dt
                        )
                    elif __viz_dt == __viz_torch.bool:
                        __viz_t = __viz_torch.zeros(__viz_shape, dtype=__viz_dt)
                    else:
                        __viz_t = __viz_torch.randn(__viz_shape, dtype=__viz_dt)
                    try:
                        __viz_t = __viz_t.to(__viz_dev)
                    except Exception:
                        pass  # device move can fail (CUDA OOM); fall back to CPU
                    __viz_dummies.append(__viz_t)
                    __viz_input_labels.append(__viz_name or ("Input " + str(len(__viz_input_labels) + 1)))
            except Exception as __viz_e:
                __viz_fail("could not build dummy input: " + str(__viz_e))
                __viz_dummies = None

            if __viz_dummies is not None:
                __viz_model.eval()
                def __viz_bind_inputs(tensors):
                    args = []
                    kwargs = {}
                    idx = 0
                    for spec in __viz_input_specs:
                        tensor = tensors[idx]
                        idx += 1
                        name = str(spec.get("name", "")).strip()
                        if name:
                            kwargs[name] = tensor
                        else:
                            args.append(tensor)
                    return args, kwargs

                __viz_args, __viz_kwargs = __viz_bind_inputs(__viz_dummies)
                __viz_input_shapes = [list(d.shape) for d in __viz_dummies]
                __viz_expected_output_shapes = []

                # ── Op classification (shared) ─────────────────────────────
                # Extended with ONNX op_type coverage so strategy 4 output
                # doesn't collapse everything to "custom" (all-white).  Each
                # new category gets a matching viz-fill-* class in viz.css.
                def __viz_classify(raw_op):
                    n = (raw_op or "").lower()
                    if n in ("input", "placeholder"): return "input"
                    if n in ("output",): return "output"
                    if "linear" in n or n in ("addmm", "matmul", "mm", "gemm"):
                        return "linear"
                    if "conv" in n: return "conv"
                    if "norm" in n or "groupnorm" in n or n in ("layernormalization",
                                                                 "batchnormalization",
                                                                 "instancenormalization"):
                        return "norm"
                    if any(a in n for a in ("relu", "gelu", "silu", "sigmoid", "tanh",
                                             "softmax", "elu", "mish", "prelu", "swish",
                                             "hardswish", "hardsigmoid", "clip")):
                        return "activation"
                    if "pool" in n: return "pool"
                    if "embed" in n: return "embedding"
                    if "dropout" in n: return "dropout"
                    if "attn" in n or "attention" in n: return "attention"
                    if any(a in n for a in ("lstm", "gru", "rnn")): return "rnn"
                    if any(a in n for a in ("sequential", "modulelist", "moduledict",
                                             "block", "container")):
                        return "container"
                    # Reductions (ONNX: ReduceMean, ReduceSum, ReduceMax, ArgMax…)
                    if n.startswith("reduce") or n in ("argmax", "argmin", "mean", "sum", "max", "min"):
                        return "reduce"
                    # Element-wise arithmetic (ONNX + torch.jit node kinds)
                    if n in ("add", "sub", "mul", "div", "pow", "sqrt", "exp",
                             "log", "neg", "abs", "floor", "ceil", "rsub", "fmod",
                             "mod", "reciprocal", "rsqrt", "erf"):
                        return "arithmetic"
                    # Constant / shape-producing ops
                    if n in ("constant", "constantofshape", "shape", "size",
                             "range", "identity", "getattr", "numtotensor",
                             "int", "float", "bool", "listconstruct",
                             "tupleconstruct"):
                        return "constant"
                    # Tensor layout / slicing ops
                    if n in ("slice", "reshape", "transpose", "permute", "concat",
                             "cat", "stack", "flatten", "split", "squeeze", "unsqueeze",
                             "view", "gather", "scatter", "cast", "expand", "tile",
                             "pad", "where", "nonzero", "topk", "sort", "callmethod",
                             "dropoutnd", "upsample", "resize", "contiguous"):
                        return "tensor_op"
                    return "custom"

                def __viz_classify_module(m):
                    if m is None: return "custom"
                    cn = type(m).__name__
                    if isinstance(m, __viz_nn.Linear): return "linear"
                    if isinstance(m, (__viz_nn.Conv1d, __viz_nn.Conv2d, __viz_nn.Conv3d,
                                       __viz_nn.ConvTranspose1d, __viz_nn.ConvTranspose2d,
                                       __viz_nn.ConvTranspose3d)):
                        return "conv"
                    if isinstance(m, (__viz_nn.BatchNorm1d, __viz_nn.BatchNorm2d, __viz_nn.BatchNorm3d,
                                       __viz_nn.LayerNorm, __viz_nn.GroupNorm,
                                       __viz_nn.InstanceNorm1d, __viz_nn.InstanceNorm2d,
                                       __viz_nn.InstanceNorm3d)):
                        return "norm"
                    if isinstance(m, (__viz_nn.ReLU, __viz_nn.LeakyReLU, __viz_nn.GELU,
                                       __viz_nn.SiLU, __viz_nn.Sigmoid, __viz_nn.Tanh,
                                       __viz_nn.Softmax, __viz_nn.LogSoftmax,
                                       __viz_nn.PReLU, __viz_nn.ELU, __viz_nn.Mish)):
                        return "activation"
                    if isinstance(m, (__viz_nn.MaxPool1d, __viz_nn.MaxPool2d, __viz_nn.MaxPool3d,
                                       __viz_nn.AvgPool1d, __viz_nn.AvgPool2d, __viz_nn.AvgPool3d,
                                       __viz_nn.AdaptiveAvgPool1d, __viz_nn.AdaptiveAvgPool2d,
                                       __viz_nn.AdaptiveAvgPool3d, __viz_nn.AdaptiveMaxPool2d)):
                        return "pool"
                    if isinstance(m, __viz_nn.Embedding): return "embedding"
                    if isinstance(m, __viz_nn.Dropout): return "dropout"
                    if isinstance(m, __viz_nn.MultiheadAttention): return "attention"
                    if isinstance(m, (__viz_nn.RNN, __viz_nn.LSTM, __viz_nn.GRU)):
                        return "rnn"
                    if isinstance(m, (__viz_nn.Sequential, __viz_nn.ModuleList, __viz_nn.ModuleDict)):
                        return "container"
                    return __viz_classify(cn)

                def __viz_shape_of(obj, depth=0):
                    if depth > __viz_max_depth or obj is None: return None
                    if isinstance(obj, __viz_torch.Tensor):
                        return list(obj.shape)
                    if isinstance(obj, (list, tuple)):
                        if obj and all(hasattr(x, "__int__") and not isinstance(x, (list, tuple, dict))
                                       for x in obj):
                            try:
                                return [int(x) for x in obj]
                            except Exception:
                                pass
                        s = [__viz_shape_of(x, depth+1) for x in obj]
                        s = [x for x in s if x is not None]
                        return s if len(s) > 1 else (s[0] if s else None)
                    if isinstance(obj, dict):
                        for v in obj.values():
                            r = __viz_shape_of(v, depth+1)
                            if r is not None: return r
                        return None
                    if hasattr(obj, "__dataclass_fields__"):
                        for k in obj.__dataclass_fields__:
                            r = __viz_shape_of(getattr(obj, k, None), depth+1)
                            if r is not None: return r
                    return None

                def __viz_total_params(m):
                    try: return int(sum(p.numel() for p in m.parameters()))
                    except Exception: return 0

                def __viz_tensor_shapes(obj, depth=0):
                    s = __viz_shape_of(obj, depth)
                    if s is None:
                        return []
                    if isinstance(s, list) and s and isinstance(s[0], list):
                        return [list(x) for x in s if isinstance(x, list) and x]
                    if isinstance(s, list) and (not s or not isinstance(s[0], list)):
                        return [list(s)] if s else []
                    return []

                def __viz_tensor_ids(obj, depth=0):
                    if depth > __viz_max_depth or obj is None:
                        return []
                    if isinstance(obj, __viz_torch.Tensor):
                        return [id(obj)]
                    if isinstance(obj, (list, tuple)):
                        out = []
                        for x in obj:
                            out.extend(__viz_tensor_ids(x, depth+1))
                        return out
                    if isinstance(obj, dict):
                        out = []
                        for v in obj.values():
                            out.extend(__viz_tensor_ids(v, depth+1))
                        return out
                    if hasattr(obj, "__dataclass_fields__"):
                        out = []
                        for k in obj.__dataclass_fields__:
                            out.extend(__viz_tensor_ids(getattr(obj, k, None), depth+1))
                        return out
                    return []

                def __viz_forward_call(model):
                    return model(*__viz_args, **__viz_kwargs)

                __viz_probe_error = None
                try:
                    with __viz_torch.no_grad():
                        __viz_probe_y = __viz_forward_call(__viz_model)
                    __viz_expected_output_shapes = __viz_tensor_shapes(__viz_probe_y)
                except Exception as __viz_e:
                    __viz_probe_error = str(__viz_e)

                # ──────────────────────────────────────────────────────────
                # Strategy 1: torchview
                # ──────────────────────────────────────────────────────────
                def __viz_strategy_torchview():
                    if __viz_kwargs:
                        raise RuntimeError("torchview keyword-input tracing unavailable")
                    from torchview import draw_graph as __viz_draw
                    args = dict(expand_nested=True, depth=6,
                                hide_inner_tensors=True, hide_module_functions=True,
                                graph_name="m", save_graph=False)
                    if len(__viz_args) == 1:
                        mg = __viz_draw(__viz_model, input_data=__viz_args[0], **args)
                    else:
                        mg = __viz_draw(__viz_model, input_data=tuple(__viz_args), **args)
                    nodes = []
                    edges = []
                    seen = {}  # id(node_obj) → "tv0", "tv1", …
                    eid = [0]
                    def neid():
                        eid[0] += 1; return "e" + str(eid[0])
                    node_set = list(getattr(mg, "node_set", []) or [])
                    # Non-module node types we traverse through but do not add as graph nodes.
                    _SKIP = {"TensorNode", "FunctionNode"}

                    # Pass 1 — add only ModuleNodes to the node list.
                    for n in node_set:
                        if type(n).__name__ in _SKIP:
                            continue
                        m = getattr(n, "module_unit", None) or getattr(n, "compute_unit", None)
                        raw = getattr(n, "name", None)
                        if not raw:
                            raw = type(m).__name__ if m is not None else type(n).__name__
                        depth_val = int(getattr(n, "depth", 0) or 0)
                        in_sh = __viz_shape_of(getattr(n, "input_shape", None))
                        out_sh = __viz_shape_of(getattr(n, "output_shape", None))
                        if isinstance(m, __viz_nn.Module):
                            params = __viz_total_params(m)
                            t = __viz_classify_module(m)
                        else:
                            params = 0
                            t = __viz_classify(raw)
                        viz_id = "tv" + str(len(seen))
                        seen[id(n)] = viz_id
                        nodes.append({
                            "id": viz_id, "label": raw, "node_type": t,
                            "raw_op": raw, "shape_in": in_sh, "shape_out": out_sh,
                            "param_count": params, "depth": depth_val, "parent": None,
                        })

                    # Pass 2 — BFS through TensorNode/FunctionNode chains to build
                    # module→module data edges.  Single-hop bridge was insufficient for
                    # graphs where tensors connect via multi-hop chains.
                    def _reachable(start):
                        visited = {id(start)}
                        q = list(getattr(start, "children", []) or [])
                        found = []
                        while q:
                            cur = q.pop(0)
                            if id(cur) in visited:
                                continue
                            visited.add(id(cur))
                            if id(cur) in seen:
                                found.append(seen[id(cur)])
                            elif type(cur).__name__ in _SKIP:
                                q.extend(list(getattr(cur, "children", []) or []))
                        return found

                    edge_set = set()
                    for n in node_set:
                        if id(n) not in seen:
                            continue
                        src = seen[id(n)]
                        for dst in _reachable(n):
                            if src != dst and (src, dst) not in edge_set:
                                edge_set.add((src, dst))
                                edges.append({"id": neid(), "from": src,
                                              "to": dst, "edge_type": "data"})

                    if not nodes:
                        raise RuntimeError("torchview produced empty graph")
                    return {"nodes": nodes, "edges": edges, "strategy": "torchview"}

                # ──────────────────────────────────────────────────────────
                # Strategy 2: torch.fx symbolic_trace + ShapeProp
                # ──────────────────────────────────────────────────────────
                def __viz_strategy_fx():
                    import torch.fx as __viz_fx
                    from torch.fx.passes.shape_prop import ShapeProp
                    gm = __viz_fx.symbolic_trace(__viz_model)
                    try:
                        ShapeProp(gm).propagate(*__viz_args, **__viz_kwargs)
                    except Exception:
                        pass
                    nodes = []
                    edges = []
                    eid = [0]
                    def neid():
                        eid[0] += 1; return "e" + str(eid[0])
                    name_map = {}
                    submods = dict(gm.named_modules())
                    for fxn in gm.graph.nodes:
                        nid = "fx_" + fxn.name
                        name_map[fxn.name] = nid
                        out_sh = None
                        tm = (fxn.meta or {}).get("tensor_meta")
                        if tm is not None:
                            try:
                                if hasattr(tm, "shape"):
                                    out_sh = list(tm.shape)
                                elif isinstance(tm, (list, tuple)):
                                    out_sh = [list(x.shape) for x in tm if hasattr(x, "shape")]
                            except Exception:
                                out_sh = None
                        if fxn.op == "placeholder":
                            t, raw, lbl, params = "input", "placeholder", fxn.name, 0
                        elif fxn.op == "output":
                            out_inputs = []
                            try:
                                out_arg = fxn.args[0] if fxn.args else None
                                if isinstance(out_arg, (list, tuple)):
                                    out_inputs = [x for x in out_arg if hasattr(x, "name")]
                                elif hasattr(out_arg, "name"):
                                    out_inputs = [out_arg]
                            except Exception:
                                out_inputs = list(fxn.all_input_nodes)
                            out_shapes = out_sh if isinstance(out_sh, list) and out_sh and \
                                isinstance(out_sh[0], list) else [out_sh]
                            for i, shp in enumerate(out_shapes):
                                out_id = nid if len(out_shapes) == 1 else nid + "_" + str(i)
                                nodes.append({
                                    "id": out_id,
                                    "label": "Output" if len(out_shapes) == 1 else ("Output " + str(i + 1)),
                                    "node_type": "output",
                                    "raw_op": "output",
                                    "shape_in": shp,
                                    "shape_out": shp,
                                    "param_count": 0,
                                    "depth": 1,
                                    "parent": None,
                                })
                                if i < len(out_inputs) and out_inputs[i].name in name_map:
                                    edges.append({
                                        "id": neid(), "from": name_map[out_inputs[i].name],
                                        "to": out_id, "edge_type": "data",
                                    })
                                elif len(out_inputs) == 1 and out_inputs[0].name in name_map:
                                    edges.append({
                                        "id": neid(), "from": name_map[out_inputs[0].name],
                                        "to": out_id, "edge_type": "data",
                                    })
                            continue
                        elif fxn.op == "call_module":
                            sub = submods.get(str(fxn.target))
                            raw = type(sub).__name__ if sub is not None else str(fxn.target)
                            lbl = raw
                            t = __viz_classify_module(sub) if sub is not None else __viz_classify(raw)
                            params = __viz_total_params(sub) if sub is not None else 0
                        elif fxn.op == "call_function":
                            raw = getattr(fxn.target, "__name__", str(fxn.target))
                            lbl, t, params = raw, __viz_classify(raw), 0
                        elif fxn.op == "call_method":
                            raw = str(fxn.target)
                            lbl, t, params = raw, __viz_classify(raw), 0
                        elif fxn.op == "get_attr":
                            raw = "GetAttr"
                            lbl, t, params = str(fxn.target), "constant", 0
                        else:
                            raw, lbl, t, params = fxn.op, fxn.name, "custom", 0
                        nodes.append({
                            "id": nid, "label": lbl, "node_type": t, "raw_op": raw,
                            "shape_in": None, "shape_out": out_sh,
                            "param_count": params, "depth": 1, "parent": None,
                        })
                        for inp in fxn.all_input_nodes:
                            if inp.name in name_map:
                                edges.append({
                                    "id": neid(), "from": name_map[inp.name],
                                    "to": nid, "edge_type": "data",
                                })
                    if not nodes:
                        raise RuntimeError("fx graph empty")
                    return {"nodes": nodes, "edges": edges, "strategy": "torch_fx"}

                # ──────────────────────────────────────────────────────────
                # Strategy 3: torch.jit.trace
                # ──────────────────────────────────────────────────────────
                def __viz_strategy_jit():
                    if __viz_kwargs:
                        raise RuntimeError("torch.jit.trace keyword-input tracing unavailable")
                    with __viz_torch.no_grad():
                        traced = __viz_torch.jit.trace(
                            __viz_model,
                            __viz_args[0] if len(__viz_args) == 1 else tuple(__viz_args),
                            check_trace=False, strict=False,
                        )
                    g = traced.graph
                    nodes = []
                    edges = []
                    eid = [0]
                    def neid():
                        eid[0] += 1; return "e" + str(eid[0])
                    val_to_node = {}
                    for i, v in enumerate(g.inputs()):
                        nid = "jit_in_" + str(i)
                        nodes.append({
                            "id": nid, "label": "Input " + str(i), "node_type": "input",
                            "raw_op": "input", "shape_in": None,
                            "shape_out": __viz_input_shapes[i] if i < len(__viz_input_shapes) else None,
                            "param_count": 0, "depth": 0, "parent": None,
                        })
                        val_to_node[v.unique()] = nid
                    for idx, n in enumerate(g.nodes()):
                        kind = n.kind()
                        raw = kind.split("::", 1)[-1] if "::" in kind else kind
                        nid = "jit_n_" + str(idx)
                        out_sh = None
                        try:
                            outs = list(n.outputs())
                            if outs:
                                ty = outs[0].type()
                                sizes = ty.sizes() if hasattr(ty, "sizes") else None
                                if sizes:
                                    out_sh = list(sizes)
                        except Exception:
                            pass
                        nodes.append({
                            "id": nid, "label": raw, "node_type": __viz_classify(raw),
                            "raw_op": raw, "shape_in": None, "shape_out": out_sh,
                            "param_count": 0, "depth": 1, "parent": None,
                        })
                        for inp in n.inputs():
                            src = val_to_node.get(inp.unique())
                            if src:
                                edges.append({
                                    "id": neid(), "from": src, "to": nid,
                                    "edge_type": "data",
                                })
                        for out in n.outputs():
                            val_to_node[out.unique()] = nid
                    for i, v in enumerate(g.outputs()):
                        nid = "jit_out_" + str(i)
                        src = val_to_node.get(v.unique())
                        nodes.append({
                            "id": nid, "label": "Output " + str(i), "node_type": "output",
                            "raw_op": "output", "shape_in": None, "shape_out": None,
                            "param_count": 0, "depth": 0, "parent": None,
                        })
                        if src:
                            edges.append({
                                "id": neid(), "from": src, "to": nid,
                                "edge_type": "data",
                            })
                    if not nodes:
                        raise RuntimeError("jit graph empty")
                    return {"nodes": nodes, "edges": edges, "strategy": "torch_jit"}

                # ──────────────────────────────────────────────────────────
                # Strategy 4: torch.onnx.export + onnxsim
                # ──────────────────────────────────────────────────────────
                def __viz_strategy_onnx():
                    if __viz_kwargs:
                        raise RuntimeError("onnx export keyword-input tracing unavailable")
                    import onnx
                    buf = __viz_io.BytesIO()
                    with __viz_torch.no_grad():
                        __viz_torch.onnx.export(
                            __viz_model,
                            __viz_args[0] if len(__viz_args) == 1 else tuple(__viz_args),
                            buf, opset_version=17, do_constant_folding=True,
                            input_names=[
                                str(__viz_input_specs[i].get("name") or ("input_" + str(i)))
                                for i in range(len(__viz_dummies))
                            ],
                            output_names=["output_" + str(i) for i in range(
                                max(1, len(__viz_expected_output_shapes))
                            )],
                        )
                    buf.seek(0)
                    onnx_model = onnx.load_model_from_string(buf.read())

                    # onnxsim simplification (best-effort — already a base dep,
                    # but wrapped so a runtime exception inside simplify() never
                    # downgrades the whole strategy).
                    try:
                        from onnxsim import simplify as __viz_onnxsim
                        simplified, ok = __viz_onnxsim(onnx_model)
                        if ok:
                            onnx_model = simplified
                    except Exception:
                        pass

                    g = onnx_model.graph
                    shape_lookup = {}
                    for vi in list(g.value_info) + list(g.input) + list(g.output):
                        try:
                            dims = []
                            for d in vi.type.tensor_type.shape.dim:
                                dims.append(d.dim_value if d.dim_value > 0 else -1)
                            shape_lookup[vi.name] = dims
                        except Exception:
                            pass
                    nodes = []
                    edges = []
                    eid = [0]
                    def neid():
                        eid[0] += 1; return "e" + str(eid[0])
                    out_to_node = {}
                    for i, vi in enumerate(g.input):
                        nid = "onnx_in_" + str(i)
                        nodes.append({
                            "id": nid, "label": vi.name or ("Input " + str(i)),
                            "node_type": "input", "raw_op": "input",
                            "shape_in": None, "shape_out": shape_lookup.get(vi.name),
                            "param_count": 0, "depth": 0, "parent": None,
                        })
                        out_to_node[vi.name] = nid
                    for idx, n in enumerate(g.node):
                        nid = "onnx_n_" + str(idx)
                        raw = n.op_type
                        out_name = n.output[0] if n.output else ""
                        nodes.append({
                            "id": nid, "label": raw, "node_type": __viz_classify(raw),
                            "raw_op": raw, "shape_in": None,
                            "shape_out": shape_lookup.get(out_name),
                            "param_count": 0, "depth": 1, "parent": None,
                        })
                        for inp in n.input:
                            src = out_to_node.get(inp)
                            if src:
                                edges.append({
                                    "id": neid(), "from": src, "to": nid,
                                    "edge_type": "data",
                                })
                        for out in n.output:
                            out_to_node[out] = nid
                    for i, vi in enumerate(g.output):
                        nid = "onnx_out_" + str(i)
                        src = out_to_node.get(vi.name)
                        nodes.append({
                            "id": nid, "label": vi.name or ("Output " + str(i)),
                            "node_type": "output", "raw_op": "output",
                            "shape_in": shape_lookup.get(vi.name),
                            "shape_out": shape_lookup.get(vi.name),
                            "param_count": 0, "depth": 0, "parent": None,
                        })
                        if src:
                            edges.append({
                                "id": neid(), "from": src, "to": nid,
                                "edge_type": "data",
                            })
                    if not nodes:
                        raise RuntimeError("onnx graph empty")

                    # ── Prune pure plumbing ops (Constant / Shape / Cast /
                    # Gather / Squeeze / Unsqueeze / Identity / Size /
                    # ConstantOfShape / Range).  These are artefacts of how
                    # PyTorch lowers modules into ONNX — never interesting
                    # to visualise.  Edges are rewired so downstream ops
                    # still connect to the last real producer.
                    _NOISE = {"Constant", "Shape", "Cast", "Gather", "Squeeze",
                              "Unsqueeze", "Identity", "Size", "ConstantOfShape",
                              "Range"}
                    drop_ids = {n["id"] for n in nodes if n["raw_op"] in _NOISE}
                    if drop_ids:
                        succ_map = {}
                        for e in edges:
                            succ_map.setdefault(e["from"], []).append(e["to"])
                        pred_map = {}
                        for e in edges:
                            pred_map.setdefault(e["to"], []).append(e["from"])

                        def _walk_back(nid, seen=None):
                            # Find the nearest live (non-dropped) predecessor(s).
                            if seen is None: seen = set()
                            if nid in seen: return []
                            seen.add(nid)
                            out = []
                            for p in pred_map.get(nid, []):
                                if p in drop_ids:
                                    out.extend(_walk_back(p, seen))
                                else:
                                    out.append(p)
                            return out

                        new_edges = []
                        edge_seen = set()
                        for e in edges:
                            if e["from"] in drop_ids or e["to"] in drop_ids:
                                continue
                            key = (e["from"], e["to"])
                            if key in edge_seen: continue
                            edge_seen.add(key)
                            new_edges.append(e)
                        # Re-add bridging edges: for every kept node with a dropped
                        # direct predecessor, connect it to the nearest live source.
                        for n2 in nodes:
                            if n2["id"] in drop_ids: continue
                            for p in pred_map.get(n2["id"], []):
                                if p not in drop_ids: continue
                                for real in _walk_back(p):
                                    key = (real, n2["id"])
                                    if key in edge_seen: continue
                                    edge_seen.add(key)
                                    new_edges.append({
                                        "id": neid(), "from": real,
                                        "to": n2["id"], "edge_type": "data",
                                    })
                        nodes = [n for n in nodes if n["id"] not in drop_ids]
                        edges = new_edges
                    return {"nodes": nodes, "edges": edges, "strategy": "onnx"}

                # ──────────────────────────────────────────────────────────
                # Strategy 5: static + forward hooks (always works)
                # ──────────────────────────────────────────────────────────
                def __viz_strategy_static():
                    trace = []
                    hooks = []
                    restores = []
                    mod_calls = {}
                    op_idx = [0]

                    def __viz_unique_ids(items):
                        out = []
                        seen = set()
                        for x in items:
                            if x is None or x in seen:
                                continue
                            seen.add(x)
                            out.append(x)
                        return out

                    def __viz_shape_inputs(args, kwargs):
                        vals = list(args)
                        if kwargs:
                            vals.extend(kwargs.values())
                        if not vals:
                            return None
                        return __viz_shape_of(vals[0] if len(vals) == 1 else vals)

                    def __viz_record(node_id, label, node_type, raw_op, shape_in, shape_out,
                                     input_ids, output_ids, param_count=0, depth=1, parent=None):
                        out_ids = __viz_unique_ids(output_ids)
                        if not out_ids:
                            return
                        trace.append({
                            "id": node_id,
                            "label": label,
                            "node_type": node_type,
                            "raw_op": raw_op,
                            "shape_in": shape_in,
                            "shape_out": shape_out,
                            "param_count": int(param_count),
                            "depth": depth,
                            "parent": parent,
                            "input_ids": __viz_unique_ids(input_ids),
                            "output_ids": out_ids,
                        })

                    def __viz_patch(obj, attr, raw_op, label=None):
                        orig = getattr(obj, attr, None)
                        if orig is None:
                            return
                        def wrapped(*args, __orig=orig, __raw=raw_op, __label=label, **kwargs):
                            out = __orig(*args, **kwargs)
                            try:
                                in_ids = []
                                for x in args:
                                    in_ids.extend(__viz_tensor_ids(x))
                                for x in kwargs.values():
                                    in_ids.extend(__viz_tensor_ids(x))
                                out_ids = __viz_tensor_ids(out)
                                if in_ids and out_ids:
                                    op_idx[0] += 1
                                    __viz_record(
                                        "__op__" + str(op_idx[0]),
                                        __label or __raw,
                                        __viz_classify(__raw),
                                        __raw,
                                        __viz_shape_inputs(args, kwargs),
                                        __viz_shape_of(out),
                                        in_ids,
                                        out_ids,
                                    )
                            except Exception:
                                pass
                            return out
                        setattr(obj, attr, wrapped)
                        restores.append((obj, attr, orig))

                    def make(name, mod_ref):
                        try:
                            param_count = sum(p.numel() for p in mod_ref.parameters(recurse=False))
                        except Exception:
                            param_count = 0
                        node_type = __viz_classify_module(mod_ref)
                        raw_op = type(mod_ref).__name__
                        depth = name.count(".") + 1
                        parent = name.rsplit(".", 1)[0] if "." in name else None
                        def hook(mod, inp, out):
                            call_no = mod_calls.get(name, 0) + 1
                            mod_calls[name] = call_no
                            node_id = name if call_no == 1 else name + "__call" + str(call_no)
                            __viz_record(
                                node_id,
                                raw_op,
                                node_type,
                                raw_op,
                                __viz_shape_of(inp),
                                __viz_shape_of(out),
                                __viz_tensor_ids(inp),
                                __viz_tensor_ids(out),
                                param_count,
                                depth,
                                parent,
                            )
                        return hook
                    for n_, m_ in __viz_model.named_modules():
                        if n_ == "":
                            continue
                        try:
                            if any(True for _ in m_.children()):
                                continue
                        except Exception:
                            pass
                        try:
                            hooks.append(m_.register_forward_hook(make(n_, m_)))
                        except Exception:
                            pass
                    try:
                        import torch.nn.functional as __viz_F
                    except Exception:
                        __viz_F = None
                    __viz_patch(__viz_torch, "cat", "cat", "Concat")
                    __viz_patch(__viz_torch, "concat", "cat", "Concat")
                    __viz_patch(__viz_torch, "stack", "stack", "Stack")
                    __viz_patch(__viz_torch, "add", "add", "Add")
                    __viz_patch(__viz_torch, "sub", "sub", "Sub")
                    __viz_patch(__viz_torch, "mul", "mul", "Mul")
                    __viz_patch(__viz_torch, "div", "div", "Div")
                    __viz_patch(__viz_torch, "matmul", "matmul", "MatMul")
                    __viz_patch(__viz_torch, "softmax", "softmax", "Softmax")
                    if __viz_F is not None:
                        __viz_patch(__viz_F, "relu", "relu", "ReLU")
                        __viz_patch(__viz_F, "softmax", "softmax", "Softmax")
                        __viz_patch(__viz_F, "gelu", "gelu", "GELU")
                        __viz_patch(__viz_F, "silu", "silu", "SiLU")
                        __viz_patch(__viz_F, "linear", "linear", "Linear")
                        __viz_patch(__viz_F, "layer_norm", "layer_norm", "LayerNorm")
                        __viz_patch(__viz_F, "dropout", "dropout", "Dropout")
                    for attr, raw, label in (
                        ("view", "view", "View"),
                        ("reshape", "reshape", "Reshape"),
                        ("permute", "permute", "Permute"),
                        ("transpose", "transpose", "Transpose"),
                        ("contiguous", "contiguous", "Contiguous"),
                        ("flatten", "flatten", "Flatten"),
                        ("squeeze", "squeeze", "Squeeze"),
                        ("unsqueeze", "unsqueeze", "Unsqueeze"),
                        ("mean", "mean", "Mean"),
                        ("softmax", "softmax", "Softmax"),
                        ("__add__", "add", "Add"),
                        ("__radd__", "add", "Add"),
                        ("__sub__", "sub", "Sub"),
                        ("__rsub__", "sub", "Sub"),
                        ("__mul__", "mul", "Mul"),
                        ("__rmul__", "mul", "Mul"),
                        ("__truediv__", "div", "Div"),
                        ("__rtruediv__", "div", "Div"),
                        ("__matmul__", "matmul", "MatMul"),
                        ("__rmatmul__", "matmul", "MatMul"),
                        ("__neg__", "neg", "Neg"),
                    ):
                        __viz_patch(__viz_torch.Tensor, attr, raw, label)
                    root_in = __viz_input_shapes
                    root_out = None
                    root_out_shapes = []
                    root_out_ids = []
                    forward_ok = True
                    try:
                        with __viz_torch.no_grad():
                            y = __viz_forward_call(__viz_model)
                        root_out = __viz_shape_of(y)
                        root_out_shapes = __viz_tensor_shapes(y)
                        root_out_ids = __viz_tensor_ids(y)
                    except Exception as e:
                        forward_ok = False
                        __viz_result["warnings"].append("forward pass failed: " + str(e))
                    finally:
                        for h in hooks:
                            try:
                                h.remove()
                            except Exception:
                                pass
                        for obj, attr, orig in reversed(restores):
                            try:
                                setattr(obj, attr, orig)
                            except Exception:
                                pass

                    nodes = []
                    edges = []
                    eid = [0]
                    edge_seen = set()
                    def neid():
                        eid[0] += 1; return "e" + str(eid[0])
                    def add_edge(src, dst):
                        if not src or not dst or src == dst:
                            return
                        key = (src, dst)
                        if key in edge_seen:
                            return
                        edge_seen.add(key)
                        edges.append({
                            "id": neid(), "from": src, "to": dst,
                            "edge_type": "data",
                        })

                    input_node_ids = []
                    producer_by_tensor = {}
                    input_tensor_ids = [id(d) for d in __viz_dummies]
                    for i, sh in enumerate(root_in):
                        nid = "__input__" if len(root_in) == 1 else "__input__" + str(i)
                        nodes.append({
                            "id": nid,
                            "label": __viz_input_labels[i] if i < len(__viz_input_labels)
                                else ("Input" if len(root_in) == 1 else ("Input " + str(i + 1))),
                            "node_type": "input",
                            "raw_op": "Input",
                            "shape_in": None,
                            "shape_out": sh,
                            "param_count": 0,
                            "depth": 0,
                            "parent": None,
                        })
                        input_node_ids.append(nid)
                        if i < len(input_tensor_ids):
                            producer_by_tensor[input_tensor_ids[i]] = nid
                    for rec in trace:
                        nodes.append({
                            "id": rec["id"],
                            "label": rec["label"],
                            "node_type": rec["node_type"],
                            "raw_op": rec["raw_op"],
                            "shape_in": rec["shape_in"],
                            "shape_out": rec["shape_out"],
                            "param_count": rec["param_count"],
                            "depth": rec["depth"],
                            "parent": rec["parent"],
                        })
                        for tid in rec["input_ids"]:
                            add_edge(producer_by_tensor.get(tid), rec["id"])
                        for tid in rec["output_ids"]:
                            producer_by_tensor[tid] = rec["id"]

                    output_node_ids = []
                    for i, sh in enumerate(root_out_shapes):
                        nid = "__output__" if len(root_out_shapes) == 1 else "__output__" + str(i)
                        nodes.append({
                            "id": nid,
                            "label": "Output" if len(root_out_shapes) == 1 else ("Output " + str(i + 1)),
                            "node_type": "output",
                            "raw_op": "Output",
                            "shape_in": sh,
                            "shape_out": sh,
                            "param_count": 0,
                            "depth": 0,
                            "parent": None,
                        })
                        output_node_ids.append(nid)
                        if i < len(root_out_ids):
                            add_edge(producer_by_tensor.get(root_out_ids[i]), nid)

                    if not any(e["edge_type"] == "data" for e in edges):
                        leaves = [n["id"] for n in nodes
                                  if n["node_type"] not in ("container", "input", "output")]
                        if leaves and input_node_ids and output_node_ids:
                            add_edge(input_node_ids[0], leaves[0])
                            for a, b in zip(leaves, leaves[1:]):
                                add_edge(a, b)
                            add_edge(leaves[-1], output_node_ids[0])
                        elif input_node_ids and output_node_ids:
                            add_edge(input_node_ids[0], output_node_ids[0])
                    if not output_node_ids:
                        nodes.append({
                            "id": "__output__", "label": "Output", "node_type": "output",
                            "raw_op": "Output", "shape_in": root_out, "shape_out": root_out,
                            "param_count": 0, "depth": 0, "parent": None,
                        })
                        if edges:
                            last_src = edges[-1]["to"]
                            add_edge(last_src, "__output__")
                        elif input_node_ids:
                            add_edge(input_node_ids[0], "__output__")
                    return {"nodes": nodes, "edges": edges, "strategy": "static",
                            "forward_ok": forward_ok}

                # ──────────────────────────────────────────────────────────
                # Block detection (pure Python — no networkx dep)
                # Detects repeating Conv→BN→Act sequences and tags them with
                # block_id so the frontend can collapse a residual stack into
                # a single macro node when requested.
                # ──────────────────────────────────────────────────────────
                def __viz_detect_blocks(graph):
                    n2t = {n["id"]: n["node_type"] for n in graph["nodes"]}
                    succ = {}
                    for e in graph["edges"]:
                        if e["edge_type"] != "data": continue
                        succ.setdefault(e["from"], []).append(e["to"])
                    PATTERN = ("conv", "norm", "activation")
                    block_id = 0
                    for start in list(n2t.keys()):
                        chain = [start]
                        cur = start
                        for _ in range(len(PATTERN) - 1):
                            nxt = succ.get(cur, [])
                            if len(nxt) != 1: break
                            chain.append(nxt[0])
                            cur = nxt[0]
                        if len(chain) == len(PATTERN) and tuple(
                            n2t.get(c, "") for c in chain
                        ) == PATTERN:
                            block_id += 1
                            tag = "B" + str(block_id)
                            for c in chain:
                                for n in graph["nodes"]:
                                    if n["id"] == c:
                                        n["block_id"] = tag
                                        break
                    return graph

                def __viz_sanitize_graph(graph):
                    nodes = list(graph.get("nodes", []) or [])
                    if not nodes:
                        return graph
                    node_ids = {n["id"] for n in nodes}
                    edges = [
                        e for e in (graph.get("edges", []) or [])
                        if e.get("from") in node_ids and e.get("to") in node_ids
                        and e.get("from") != e.get("to")
                    ]
                    data_edges = [e for e in edges if e.get("edge_type") == "data"]
                    if not data_edges:
                        graph["nodes"] = nodes
                        graph["edges"] = edges
                        return graph

                    succ = {}
                    pred = {}
                    indeg = {}
                    outdeg = {}
                    for e in data_edges:
                        succ.setdefault(e["from"], []).append(e["to"])
                        pred.setdefault(e["to"], []).append(e["from"])
                        outdeg[e["from"]] = outdeg.get(e["from"], 0) + 1
                        indeg[e["to"]] = indeg.get(e["to"], 0) + 1

                    inputs = [n["id"] for n in nodes if n.get("node_type") == "input"]
                    outputs = [n["id"] for n in nodes if n.get("node_type") == "output"]
                    if not inputs:
                        inputs = [n["id"] for n in nodes
                                  if indeg.get(n["id"], 0) == 0 and outdeg.get(n["id"], 0) > 0]
                    if not outputs:
                        outputs = [n["id"] for n in nodes
                                   if outdeg.get(n["id"], 0) == 0 and indeg.get(n["id"], 0) > 0]

                    def walk(starts, adj):
                        seen = set()
                        stack = list(starts)
                        while stack:
                            cur = stack.pop()
                            if cur in seen:
                                continue
                            seen.add(cur)
                            stack.extend(adj.get(cur, []))
                        return seen

                    reachable = walk(inputs, succ) if inputs else set(node_ids)
                    co_reachable = walk(outputs, pred) if outputs else set(node_ids)
                    keep = reachable & co_reachable
                    if not keep:
                        keep = {
                            n["id"] for n in nodes
                            if indeg.get(n["id"], 0) > 0 or outdeg.get(n["id"], 0) > 0
                            or n.get("node_type") in ("input", "output")
                        }
                    graph["nodes"] = [n for n in nodes if n["id"] in keep]
                    graph["edges"] = [
                        e for e in edges
                        if e.get("from") in keep and e.get("to") in keep
                    ]
                    return graph

                def __viz_is_low_signal_graph(graph):
                    real = {"linear", "conv", "norm", "activation", "pool",
                            "embedding", "dropout", "attention", "rnn"}
                    low = {"constant", "tensor_op", "arithmetic", "reduce"}
                    leaves = [n for n in graph["nodes"]
                              if n["node_type"] not in ("input", "output", "container")]
                    if not leaves:
                        return False
                    real_count = sum(1 for n in leaves if n["node_type"] in real)
                    low_count = sum(1 for n in leaves if n["node_type"] in low)
                    return real_count == 0 and low_count >= max(3, int(len(leaves) * 0.6))

                # ──────────────────────────────────────────────────────────
                # Orchestrator: try in order, first non-empty wins
                # ──────────────────────────────────────────────────────────
                __viz_strategies = [
                    ("torchview", __viz_strategy_torchview),
                    ("torch_fx",  __viz_strategy_fx),
                    ("torch_jit", __viz_strategy_jit),
                    ("onnx",      __viz_strategy_onnx),
                    ("static",    __viz_strategy_static),
                ]
                __viz_picked = None
                __viz_failures = {}
                try:
                    if __viz_probe_error is not None:
                        __viz_failures["input-check"] = __viz_probe_error[:200]
                    for __viz_sname, __viz_fn in ([] if __viz_probe_error is not None else __viz_strategies):
                        try:
                            __viz_g = __viz_fn()
                        except Exception as __viz_e:
                            __viz_failures[__viz_sname] = (
                                type(__viz_e).__name__ + ": " + str(__viz_e)[:200]
                            )
                            # CUDA OOM → retry on CPU once for this strategy.
                            if "out of memory" in str(__viz_e).lower() and __viz_dev.type != "cpu":
                                try:
                                    __viz_torch.cuda.empty_cache()
                                except Exception:
                                    pass
                                __viz_cpu_dummies = [d.cpu() for d in __viz_dummies]
                                __viz_cpu_model = __viz_model.cpu()
                                __viz_args_save, __viz_kwargs_save = __viz_args, __viz_kwargs
                                __viz_dummies_save = __viz_dummies
                                __viz_dummies[:] = __viz_cpu_dummies
                                __viz_args, __viz_kwargs = __viz_bind_inputs(__viz_dummies)
                                try:
                                    __viz_g = __viz_fn()
                                except Exception as __viz_e2:
                                    __viz_failures[__viz_sname + "(cpu)"] = str(__viz_e2)[:160]
                                    __viz_dummies[:] = __viz_dummies_save
                                    __viz_args, __viz_kwargs = __viz_args_save, __viz_kwargs_save
                                    continue
                                finally:
                                    try: __viz_model.to(__viz_dev)
                                    except Exception: pass
                                    __viz_args, __viz_kwargs = __viz_bind_inputs(__viz_dummies)
                            else:
                                continue
                        if not __viz_g or not __viz_g.get("nodes"):
                            __viz_failures[__viz_sname + "(empty)"] = "produced empty graph"
                            continue
                        __viz_g = __viz_sanitize_graph(__viz_g)
                        if not __viz_g.get("nodes"):
                            __viz_failures[__viz_sname + "(sanitized-empty)"] = "graph disconnected after pruning"
                            continue
                        __viz_graph_inputs = sum(
                            1 for n in __viz_g["nodes"] if n.get("node_type") == "input"
                        )
                        __viz_graph_outputs = sum(
                            1 for n in __viz_g["nodes"] if n.get("node_type") == "output"
                        )
                        if __viz_graph_inputs < len(__viz_input_shapes):
                            __viz_failures[__viz_sname + "(input-arity)"] = "missing input nodes"
                            continue
                        if (__viz_expected_output_shapes and
                                __viz_graph_outputs < len(__viz_expected_output_shapes)):
                            __viz_failures[__viz_sname + "(output-arity)"] = "missing output nodes"
                            continue
                        # If multiple nodes exist but zero data edges, the graph is not
                        # renderable (flat layout, no animation).  Fall through to next strategy.
                        if (len(__viz_g["nodes"]) > 1 and
                                not any(e.get("edge_type") == "data"
                                        for e in __viz_g.get("edges", []))):
                            __viz_failures[__viz_sname + "(no-edges)"] = "no data edges"
                            continue
                        if __viz_sname != "static" and __viz_is_low_signal_graph(__viz_g):
                            __viz_failures[__viz_sname + "(low-signal)"] = "graph dominated by plumbing ops"
                            continue
                        __viz_picked = (__viz_sname, __viz_g)
                        break
                finally:
                    # Restore original train/eval state always.
                    try:
                        if __viz_was_training:
                            __viz_model.train()
                    except Exception:
                        pass

                if __viz_picked is None:
                    if __viz_probe_error is not None:
                        __viz_fail("model forward failed for provided input: " + __viz_probe_error)
                    else:
                        __viz_fail("all extraction strategies failed")
                else:
                    __viz_sname, __viz_g = __viz_picked
                    __viz_g = __viz_detect_blocks(__viz_g)
                    __viz_result["nodes"] = __viz_g["nodes"]
                    __viz_result["edges"] = __viz_g["edges"]
                    __viz_output_shapes = []
                    for __viz_n in __viz_g["nodes"]:
                        if __viz_n.get("node_type") != "output":
                            continue
                        __viz_sh = __viz_n.get("shape_out") or __viz_n.get("shape_in")
                        if __viz_sh is not None:
                            __viz_output_shapes.append(__viz_sh)
                    if len(__viz_output_shapes) == 1:
                        __viz_out_sh = __viz_output_shapes[0]
                    elif len(__viz_output_shapes) > 1:
                        __viz_out_sh = __viz_output_shapes
                    else:
                        __viz_out_sh = None
                    __viz_result["meta"] = {
                        "model_var": __viz_var_name,
                        "model_class": type(__viz_model).__name__,
                        "total_params": __viz_total_params(__viz_model),
                        "total_nodes": len(__viz_g["nodes"]),
                        "input_shapes": __viz_input_shapes,
                        "output_shape": __viz_out_sh,
                        "strategy": __viz_g.get("strategy", __viz_sname),
                        "forward_ok": __viz_g.get("forward_ok", True),
                        "device": str(__viz_dev),
                    }
                    if __viz_sname != "torchview" and "torchview" in __viz_failures:
                        __viz_result["warnings"].insert(0,
                            "Using fallback '" + __viz_sname + "' (torchview unavailable or failed)."
                        )
                    __viz_emit()
"""


def build_extract_code(module_name: str, var_name: str, inputs: Any) -> str:
    """Return Python code that runs in the kernel and prints extraction JSON."""
    payload: Dict[str, Any] = {
        "module_name": module_name,
        "var_name": var_name,
        "inputs": inputs,
    }
    return _TEMPLATE.replace("__VIZ_PAYLOAD_JSON__", repr(json.dumps(payload)))
