"""Generate kernel-side inspect script: emit nn.Module vars from a cell module."""

_TEMPLATE = r"""
import json as __viz_json, sys as __viz_sys
__viz_out = {"models": [], "torch_available": False}
try:
    import torch as __viz_torch
    __viz_out["torch_available"] = True
except Exception:
    print("__MPYNB_VIZ_INSPECT__" + __viz_json.dumps(__viz_out))
else:
    __viz_mod = __viz_sys.modules.get(__MODULE_NAME__)
    if __viz_mod is None:
        __viz_out["error"] = "cell not executed in this kernel session"
    else:
        for __viz_k, __viz_v in list(getattr(__viz_mod, "__dict__", {}).items()):
            if __viz_k.startswith("_"):
                continue
            try:
                if isinstance(__viz_v, __viz_torch.nn.Module):
                    try:
                        __viz_p = sum(p.numel() for p in __viz_v.parameters())
                    except Exception:
                        __viz_p = 0
                    __viz_out["models"].append({
                        "name": __viz_k,
                        "class": type(__viz_v).__name__,
                        "params": int(__viz_p),
                    })
            except Exception:
                continue
    print("__MPYNB_VIZ_INSPECT__" + __viz_json.dumps(__viz_out))
"""


def build_inspect_code(module_name: str) -> str:
    """Return Python code that, when exec'd in the kernel, prints inspect JSON."""
    return _TEMPLATE.replace("__MODULE_NAME__", repr(module_name))
