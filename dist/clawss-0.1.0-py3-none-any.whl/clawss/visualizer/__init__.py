"""mpynb model visualizer — runs inside the live kernel via run_capture.

Two phases:
  inspect_code  → list nn.Module instances in a cell module's namespace
  extract_code  → walk a chosen model, return graph.json (nodes/edges/shapes)
"""
from .inspect_code import build_inspect_code
from .extract_code import build_extract_code

__all__ = ["build_inspect_code", "build_extract_code"]
