import ast
from typing import List, Dict


def analyze_cells(cells: List[dict]) -> List[dict]:
    """
    AST-analyze a list of cells and return dependency graph data.
    Each input cell: {id, filename, source}
    """
    # module name → cell id  (e.g. "data_loader" → "abc-123")
    module_map: Dict[str, str] = {}
    for cell in cells:
        fn = cell["filename"]
        mod = fn[:-3].replace("/", ".").replace("\\", ".") if fn.endswith(".py") else fn.replace("/", ".").replace("\\", ".")
        module_map[mod] = cell["id"]

    results = []
    for cell in cells:
        fn = cell["filename"]
        src = cell.get("source", "")
        mod = fn[:-3].replace("/", ".").replace("\\", ".") if fn.endswith(".py") else fn.replace("/", ".").replace("\\", ".")

        defines: List[str] = []
        cell_deps: List[dict] = []     # imports from other cells
        ext_imports: List[str] = []    # imports from external packages
        seen_ext: set = set()

        try:
            tree = ast.parse(src)
            for node in tree.body:
                # Top-level definitions
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    defines.append(node.name)
                elif isinstance(node, ast.ClassDef):
                    defines.append(node.name)
                elif isinstance(node, ast.Assign):
                    for t in node.targets:
                        if isinstance(t, ast.Name) and not t.id.startswith("_"):
                            defines.append(t.id)
                elif isinstance(node, ast.AnnAssign):
                    if isinstance(node.target, ast.Name) and not node.target.id.startswith("_"):
                        defines.append(node.target.id)

                # Imports
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        if node.module in module_map:
                            cell_deps.append({
                                "module": node.module,
                                "names": [a.name for a in node.names],
                                "cell_id": module_map[node.module],
                            })
                        else:
                            base = node.module.split(".")[0]
                            if base not in seen_ext:
                                ext_imports.append(base)
                                seen_ext.add(base)
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        base = alias.name.split(".")[0]
                        if base not in seen_ext:
                            ext_imports.append(base)
                            seen_ext.add(base)
        except SyntaxError:
            pass

        results.append({
            "id": cell["id"],
            "filename": fn,
            "module": mod,
            "defines": defines,
            "cell_deps": cell_deps,
            "ext_imports": ext_imports,
        })

    return results
