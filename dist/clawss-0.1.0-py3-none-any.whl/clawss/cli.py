"""clawss — CLI for the modular Python notebook environment."""
import argparse
import asyncio
import os
import shutil
import sys
import threading
import time
import webbrowser
from pathlib import Path


def _projects_root() -> Path:
    return Path.home() / ".clawss" / "projects"


def _win_asyncio_fix():
    """Must be called before importing uvicorn on Windows."""
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


def cmd_module(args):
    """Start the notebook server and open browser."""
    _win_asyncio_fix()
    import uvicorn

    os.environ["CLAWSS_WORKSPACE_ROOT"] = str(Path.cwd().resolve())
    port = args.port
    host = str(args.host or "127.0.0.1")
    host_name = host.split(":", 1)[0].strip("[]").casefold()
    if host_name not in {"127.0.0.1", "localhost", "::1"}:
        print("  [warn] Non-local bind enabled. clawss exposes local code execution endpoints; use only on trusted networks.\n")

    if not args.no_browser:
        def open_browser():
            time.sleep(2.5)
            webbrowser.open(f"http://localhost:{port}")
        threading.Thread(target=open_browser, daemon=True).start()

    print(f"\n  clawss running at http://localhost:{port}\n")
    uvicorn.run("clawss.main:app", host=host, port=port)


def cmd_version(args):
    """Print version."""
    from clawss import __version__
    print(f"clawss {__version__}")


def cmd_info(args):
    """Show install info and paths."""
    from clawss import __version__
    notebooks_dir = _projects_root()
    print(f"  clawss {__version__}")
    print(f"  Python:     {sys.executable}")
    print(f"  Platform:   {sys.platform}")
    print(f"  Projects:   {notebooks_dir}")
    print(f"  Exists:     {'yes' if notebooks_dir.exists() else 'no'}")
    if notebooks_dir.exists():
        projects = [d.name for d in notebooks_dir.iterdir() if d.is_dir()]
        print(f"  Count:      {len(projects)}")
        for p in projects[:10]:
            print(f"              - {p}")
        if len(projects) > 10:
            print(f"              ... and {len(projects) - 10} more")


def cmd_list(args):
    """List all projects."""
    notebooks_dir = _projects_root()
    if not notebooks_dir.exists():
        print("  No projects yet. Run 'clawss module' to get started.")
        return
    projects = sorted(d.name for d in notebooks_dir.iterdir() if d.is_dir())
    if not projects:
        print("  No projects yet. Run 'clawss module' to get started.")
        return
    print(f"  {len(projects)} project(s) in {notebooks_dir}\n")
    for p in projects:
        nb_count = len(list((notebooks_dir / p).rglob("*.mpynb")))
        print(f"    {p}  ({nb_count} notebook{'s' if nb_count != 1 else ''})")


def cmd_clean(args):
    """Remove __pycache__, __mpynb__, and .session_registry.json from projects."""
    notebooks_dir = _projects_root()
    if not notebooks_dir.exists():
        print("  Nothing to clean.")
        return
    removed = 0
    for d in notebooks_dir.rglob("__pycache__"):
        if d.is_dir():
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
    for d in notebooks_dir.rglob("__mpynb__"):
        if d.is_dir():
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
    for f in notebooks_dir.rglob(".session_registry.json"):
        f.unlink(missing_ok=True)
        removed += 1
    print(f"  Cleaned {removed} item(s).")


def main():
    parser = argparse.ArgumentParser(
        prog="clawss",
        description="clawss — a modular Python notebook environment",
    )
    sub = parser.add_subparsers(dest="command")

    # clawss module
    p_module = sub.add_parser("module", help="Start the notebook server")
    p_module.add_argument("-p", "--port", type=int, default=8765, help="Server port (default: 8765)")
    p_module.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1)")
    p_module.add_argument("--no-browser", action="store_true", help="Don't open browser automatically")
    p_module.set_defaults(func=cmd_module)

    # clawss version
    p_ver = sub.add_parser("version", help="Show version")
    p_ver.set_defaults(func=cmd_version)

    # clawss info
    p_info = sub.add_parser("info", help="Show install info and paths")
    p_info.set_defaults(func=cmd_info)

    # clawss list
    p_list = sub.add_parser("list", help="List all projects")
    p_list.set_defaults(func=cmd_list)

    # clawss clean
    p_clean = sub.add_parser("clean", help="Remove caches and build artifacts from projects")
    p_clean.set_defaults(func=cmd_clean)

    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
    else:
        args.func(args)


if __name__ == "__main__":
    main()
