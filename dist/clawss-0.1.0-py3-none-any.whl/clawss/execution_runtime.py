from __future__ import annotations

import ipaddress
import os
from typing import Any, Mapping
from urllib.parse import urlparse

from .kernel import KernelSession
from .remote_jupyter import RemoteJupyterSession

DEFAULT_RUNTIME: dict[str, str] = {"kind": "local", "mode": "auto"}


def _validate_runpod_base_url(raw: str) -> str:
    parsed = urlparse(raw)
    scheme = (parsed.scheme or "").lower()
    host = (parsed.hostname or "").strip().lower()
    if not scheme or not host:
        raise ValueError("RunPod runtime requires a valid base_url")
    allow_local = os.environ.get("CLAWSS_ALLOW_LOCAL_REMOTE_RUNTIME", "").strip() == "1"
    if allow_local and host in {"localhost", "127.0.0.1", "::1"} and scheme in {"http", "https"}:
        return raw.rstrip("/")
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None:
        raise ValueError("RunPod runtime must use a RunPod proxy host, not an IP address")
    if scheme != "https" or not host.endswith(".proxy.runpod.net"):
        raise ValueError("RunPod runtime must use an https://*.proxy.runpod.net URL")
    return raw.rstrip("/")


def normalize_runtime_config(raw: Any) -> dict[str, str]:
    if not isinstance(raw, Mapping):
        return dict(DEFAULT_RUNTIME)
    kind = str(raw.get("kind") or "local").strip().lower()
    if kind == "local":
        mode = str(raw.get("mode") or "auto").strip().lower()
        if mode not in {"auto", "cpu"}:
            mode = "auto"
        return {"kind": "local", "mode": mode}
    if kind == "runpod":
        base_url = _validate_runpod_base_url(str(raw.get("base_url") or "").strip())
        pod_id = str(raw.get("pod_id") or "").strip()
        label = str(raw.get("label") or pod_id or "RunPod").strip()
        return {"kind": "runpod", "base_url": base_url, "pod_id": pod_id, "label": label}
    return dict(DEFAULT_RUNTIME)


def runtime_cache_key(runtime: Mapping[str, str]) -> str:
    kind = runtime.get("kind", "local")
    if kind == "local":
        return f"local:{runtime.get('mode', 'auto')}"
    if kind == "runpod":
        return f"runpod:{runtime.get('pod_id') or runtime.get('base_url', '')}"
    return "local:auto"


def build_runtime_session(runtime: Mapping[str, str], working_dir: str, notebook_dir: str):
    kind = runtime.get("kind", "local")
    if kind == "runpod":
        return RemoteJupyterSession(working_dir, notebook_dir, runtime["base_url"])
    kernel_env = None
    if runtime.get("mode") == "cpu":
        kernel_env = {"CUDA_VISIBLE_DEVICES": ""}
    return KernelSession(working_dir, notebook_dir, kernel_env=kernel_env)
