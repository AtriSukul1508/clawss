from clawss.cli import main

main()
