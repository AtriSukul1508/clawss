import ast
import json
import uuid
from pathlib import Path
from typing import Iterable


def new_notebook() -> dict:
    return {
        "cells": [
            {
                "id": str(uuid.uuid4()),
                "filename": "imports.py",
                "type": "code",
                "description": "Global imports and constants available in all cells",
                "source": "# Add global imports here\n",
            }
        ]
    }


def _cell_filename_key(filename: str) -> str:
    return filename.strip().casefold()


def _next_repaired_name(seen: set[str]) -> str:
    n = 1
    while True:
        candidate = f"cell{n}.py"
        key = _cell_filename_key(candidate)
        if key not in seen:
            seen.add(key)
            return candidate
        n += 1


def _commentify_legacy_markdown_source(source: object) -> str:
    text = str(source or "").replace("\r\n", "\n").replace("\r", "\n")
    if not text.strip():
        return "# Legacy markdown cell\n"
    lines = text.split("\n")
    commented = [f"# {line}" if line else "#" for line in lines]
    return "\n".join(commented).rstrip() + "\n"


def _repair_legacy_cell_filenames(cells: Iterable[dict]) -> bool:
    changed = False
    seen: set[str] = set()
    for cell in cells:
        raw_name = str(cell.get("filename") or "").strip()
        kind = str(cell.get("type") or "code").strip().lower()
        key = _cell_filename_key(raw_name) if raw_name else ""
        if kind != "code" or raw_name.lower().endswith(".md"):
            cell["type"] = "code"
            cell["filename"] = _next_repaired_name(seen)
            cell["source"] = _commentify_legacy_markdown_source(cell.get("source"))
            changed = True
            continue
        if raw_name == ".py":
            cell["filename"] = _next_repaired_name(seen)
            changed = True
            continue
        if key:
            seen.add(key)
    return changed


def validate_cell_filename(filename: object, cell_type: object) -> str:
    name = str(filename or "").strip()
    kind = str(cell_type or "code").strip().lower()
    if kind != "code":
        raise ValueError("Only `.py` code cells are supported")
    if not name:
        raise ValueError("Cell filename is required")
    if "/" in name or "\\" in name:
        raise ValueError(f"Cell filename cannot contain path separators: {name}")
    dot = name.rfind(".")
    stem = name[:dot].strip() if dot > 0 else ""
    if not name.endswith(".py"):
        raise ValueError(f"Code cell filename must end with .py: {name}")
    if not stem:
        raise ValueError(f"Code cell filename must have a name before .py: {name}")
    return name


def validate_notebook_cells(cells: Iterable[dict]) -> None:
    seen: dict[str, str] = {}
    for cell in cells:
        name = validate_cell_filename(cell.get("filename"), cell.get("type"))
        key = _cell_filename_key(name)
        if key in seen:
            raise ValueError(f'Duplicate cell filename: "{name}"')
        seen[key] = name


def load_notebook(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        nb = new_notebook()
        save_notebook(path, nb)
        return nb
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Ensure every cell has a unique id and required fields
    changed = False
    for cell in data.get("cells") or []:
        if not cell.get("id"):
            cell["id"] = str(uuid.uuid4())
            changed = True
        cell.setdefault("description", "")
        cell.setdefault("source", "")
        cell.setdefault("type", "code")
        # Drop legacy folder field if present (cells are now flat)
        cell.pop("folder", None)
    if _repair_legacy_cell_filenames(data.get("cells") or []):
        changed = True
    validate_notebook_cells(data.get("cells") or [])
    if changed:
        save_notebook(path, data)
    return data


def save_notebook(path: str, data: dict) -> None:
    validate_notebook_cells(data.get("cells") or [])
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def inject_smart_imports(cell_source: str, imports_source: str) -> str:
    """Inject only the imports from imports.py that are actually used in the cell."""
    if not imports_source or not imports_source.strip():
        return cell_source

    # Collect all names referenced in the cell
    try:
        cell_tree = ast.parse(cell_source)
    except SyntaxError:
        return _inject_all(cell_source, imports_source)

    used_names: set = set()
    for node in ast.walk(cell_tree):
        if isinstance(node, ast.Name):
            used_names.add(node.id)
        elif isinstance(node, ast.Attribute):
            # catch `pd.DataFrame` → `pd`
            root = node
            while isinstance(root, ast.Attribute):
                root = root.value
            if isinstance(root, ast.Name):
                used_names.add(root.id)
        elif isinstance(node, (ast.ImportFrom, ast.Import)):
            # imports already in the cell — don't duplicate
            if isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    used_names.discard(alias.asname or alias.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    used_names.discard(alias.asname or alias.name.split(".")[0])

    # Parse imports.py and collect only relevant lines
    try:
        imp_tree = ast.parse(imports_source)
    except SyntaxError:
        return _inject_all(cell_source, imports_source)

    lines = imports_source.splitlines()
    relevant: list[str] = []

    for node in imp_tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound_name = alias.asname or alias.name.split(".")[0]
                if bound_name in used_names:
                    relevant.extend(lines[node.lineno - 1: node.end_lineno])
                    break
        elif isinstance(node, ast.ImportFrom):
            bound_names = [a.asname or a.name for a in node.names]
            if any(n in used_names for n in bound_names):
                relevant.extend(lines[node.lineno - 1: node.end_lineno])
        elif isinstance(node, ast.Assign):
            # e.g. CONSTANT = 42
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id in used_names:
                    relevant.extend(lines[node.lineno - 1: node.end_lineno])
                    break

    if relevant:
        header = "# Auto-injected from imports.py\n" + "\n".join(relevant) + "\n\n"
        return header + cell_source

    return cell_source


def link_runtime_imports(cell_source: str, imports_source: str) -> str:
    """Link used imports/constants back to the live `imports` module.

    Unlike `inject_smart_imports`, this keeps runtime semantics honest: after a
    kernel restart, dependent cells naturally fail until `imports.py` is run
    again, instead of silently carrying copied imports/constants in synced
    package files.
    """
    names = _imports_names_for_cell(cell_source, imports_source)
    if not names:
        return cell_source
    header = "# Runtime-linked from imports.py\nfrom imports import " + ", ".join(names) + "\n\n"
    return header + cell_source


def make_importable(source: str) -> str:
    """Wrap top-level expression statements (print calls, etc.) in
    `if __name__ == '__main__':` so the synced cell can be imported
    without triggering side effects."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source

    if not any(isinstance(n, ast.Expr) for n in tree.body):
        return source  # nothing to wrap

    lines = source.splitlines()
    had_trailing_newline = source.endswith("\n")

    for node in reversed(tree.body):
        if not isinstance(node, ast.Expr):
            continue
        start = node.lineno - 1
        end = node.end_lineno
        for i in range(start, end):
            lines[i] = "    " + lines[i]
        lines.insert(start, 'if __name__ == "__main__":')

    result = "\n".join(lines)
    if had_trailing_newline or result:
        result += "\n"
    return result


def _inject_all(cell_source: str, imports_source: str) -> str:
    """Fallback: inject all import statements from imports.py."""
    try:
        tree = ast.parse(imports_source)
        lines = imports_source.splitlines()
        import_lines = []
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                import_lines.extend(lines[node.lineno - 1: node.end_lineno])
        if import_lines:
            header = "# Auto-injected from imports.py\n" + "\n".join(import_lines) + "\n\n"
            return header + cell_source
    except SyntaxError:
        pass
    return cell_source


def _imports_names_for_cell(cell_source: str, imports_source: str) -> list[str]:
    if not imports_source or not imports_source.strip():
        return []

    try:
        cell_tree = ast.parse(cell_source)
    except SyntaxError:
        return _all_importable_names(imports_source)

    used_names: set[str] = set()
    for node in ast.walk(cell_tree):
        if isinstance(node, ast.Name):
            used_names.add(node.id)
        elif isinstance(node, ast.Attribute):
            root = node
            while isinstance(root, ast.Attribute):
                root = root.value
            if isinstance(root, ast.Name):
                used_names.add(root.id)
        elif isinstance(node, (ast.ImportFrom, ast.Import)):
            if isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    used_names.discard(alias.asname or alias.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    used_names.discard(alias.asname or alias.name.split(".")[0])

    try:
        imp_tree = ast.parse(imports_source)
    except SyntaxError:
        return _all_importable_names(imports_source)

    relevant: list[str] = []
    seen: set[str] = set()

    def add(name: str) -> None:
        if name not in seen:
            seen.add(name)
            relevant.append(name)

    for node in imp_tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound_name = alias.asname or alias.name.split(".")[0]
                if bound_name in used_names:
                    add(bound_name)
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                bound_name = alias.asname or alias.name
                if bound_name in used_names:
                    add(bound_name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in used_names:
                    add(target.id)
        elif isinstance(node, ast.AnnAssign):
            target = node.target
            if isinstance(target, ast.Name) and target.id in used_names:
                add(target.id)

    return relevant


def _all_importable_names(imports_source: str) -> list[str]:
    try:
        tree = ast.parse(imports_source)
    except SyntaxError:
        return []

    names: list[str] = []
    seen: set[str] = set()

    def add(name: str) -> None:
        if name not in seen:
            seen.add(name)
            names.append(name)

    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                add(alias.asname or alias.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    add(target.id)
        elif isinstance(node, ast.AnnAssign):
            target = node.target
            if isinstance(target, ast.Name):
                add(target.id)
    return names
