import json
import os
import stat
from pathlib import Path
from typing import Literal, Tuple

GPUProvider = Literal["runpod", "lambda", "vast"]
STORAGE_KIND = Literal["keyring", "file", "env", "none"]

SERVICE_NAME = "clawss-gpu"
ENV_VARS = {
    "runpod": "RUNPOD_API_KEY",
    "lambda": "LAMBDA_API_KEY",
    "vast": "VAST_API_KEY",
}


def _config_dir() -> Path:
    return Path.home() / ".clawss"


def _config_file() -> Path:
    return _config_dir() / "gpu_credentials.json"


def _read_config() -> dict:
    path = _config_file()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_config(data: dict) -> None:
    path = _config_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=True, indent=2), encoding="utf-8")
    if os.name != "nt":
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    try:
        tmp.replace(path)
    except PermissionError:
        path.write_text(json.dumps(data, ensure_ascii=True, indent=2), encoding="utf-8")
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
    if os.name != "nt":
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def _get_keyring():
    try:
        import keyring  # type: ignore
        return keyring
    except Exception:
        return None


def _provider_env_var(provider: GPUProvider) -> str:
    if provider not in ENV_VARS:
        raise ValueError("Unsupported provider")
    return ENV_VARS[provider]


def save_provider_key(provider: GPUProvider, api_key: str) -> STORAGE_KIND:
    api_key = (api_key or "").strip()
    if not api_key:
        raise ValueError("API key required")
    keyring = _get_keyring()
    if keyring is not None:
        try:
            keyring.set_password(SERVICE_NAME, provider, api_key)
            return "keyring"
        except Exception:
            pass
    data = _read_config()
    data[provider] = api_key
    _write_config(data)
    return "file"


def get_provider_key(provider: GPUProvider) -> Tuple[str | None, STORAGE_KIND]:
    env_key = (os.getenv(_provider_env_var(provider)) or "").strip()
    if env_key:
        return env_key, "env"
    keyring = _get_keyring()
    if keyring is not None:
        try:
            stored = keyring.get_password(SERVICE_NAME, provider)
            if stored:
                return stored, "keyring"
        except Exception:
            pass
    stored = (_read_config().get(provider) or "").strip()
    if stored:
        return stored, "file"
    return None, "none"


def delete_provider_key(provider: GPUProvider) -> None:
    keyring = _get_keyring()
    if keyring is not None:
        try:
            keyring.delete_password(SERVICE_NAME, provider)
        except Exception:
            pass
    data = _read_config()
    if provider in data:
        del data[provider]
        _write_config(data)


def provider_key_status(provider: GPUProvider) -> dict:
    key, storage = get_provider_key(provider)
    return {
        "provider": provider,
        "has_key": bool(key),
        "storage": storage,
        "from_env": storage == "env",
    }
