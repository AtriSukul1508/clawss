import asyncio
import os
import re
import time
from pathlib import Path
from typing import Awaitable, Callable, List, Optional

import psutil

ANSI_ESCAPE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

CELLS_DIR = "__cells__"   # hidden from file tree
MAX_STREAM_BYTES = 2_000_000  # 2 MB cap per cell execution


class KernelSession:
    def __init__(self, working_dir: str, notebook_dir: Optional[str] = None, kernel_env: Optional[dict[str, str]] = None):
        self.working_dir = Path(working_dir)
        self.notebook_dir = Path(notebook_dir) if notebook_dir else self.working_dir
        self.notebook_dir.mkdir(parents=True, exist_ok=True)
        self.cells_dir = self.notebook_dir / CELLS_DIR
        self.cells_dir.mkdir(parents=True, exist_ok=True)
        self.mpynb_dir = self.working_dir / "__mpynb__"
        self.mpynb_dir.mkdir(exist_ok=True)
        self.kernel_env = kernel_env or None
        self.km = None
        self.kc = None
        self.execution_count = 0
        self._running_cell_id: Optional[str] = None
        self._lock = asyncio.Lock()
        self._current_task: Optional[asyncio.Task] = None
        self._interrupt_event = asyncio.Event()

    async def cancel_current(self):
        """Cancel any in-flight execution."""
        task = self._current_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        self._running_cell_id = None

    async def start(self):
        from jupyter_client.manager import AsyncKernelManager
        self.km = AsyncKernelManager(kernel_name="python3")
        # Disable ipykernel's parent-process monitor so the kernel survives
        # backend restarts without shutting itself down (avoids ECONNRESET cascade)
        await self.km.start_kernel(
            cwd=str(self.notebook_dir),
            extra_arguments=["--IPKernelApp.parent_handle=0"],
            env=self.kernel_env or os.environ.copy(),
        )
        await self._attach_client_and_setup()

    async def _attach_client_and_setup(self):
        if self.kc:
            try:
                self.kc.stop_channels()
            except Exception:
                pass
        self.kc = self.km.client()
        self.kc.start_channels()
        try:
            await asyncio.wait_for(self.kc.wait_for_ready(), timeout=30)
        except asyncio.TimeoutError:
            raise RuntimeError("Kernel did not start within 30s")

        setup = (
            f"import os, sys; "
            f"os.chdir({repr(str(self.notebook_dir))}); "
            f"sys.path.insert(0, {repr(str(self.notebook_dir))}); "
            f"sys.path.insert(0, {repr(str(self.working_dir))}); "
            f"sys.path.insert(0, {repr(str(self.mpynb_dir))})"
        )
        await self._silent(setup)
        await self._silent(self._virtual_cwd_setup())
        await self._silent(self._rich_output_setup())
        await self._silent(self._guard_code())

    def _virtual_cwd_setup(self) -> str:
        """Expose the visible workspace path even if the backing store resolves elsewhere."""
        visible_working_dir = str(self.working_dir).replace("\\", "/")
        real_working_dir = str(self.working_dir.resolve()).replace("\\", "/")
        return (
            f"import os as _os\n"
            f"_clawss_real_getcwd = _os.getcwd\n"
            f"_clawss_real_root = {repr(real_working_dir)}\n"
            f"_clawss_visible_root = {repr(visible_working_dir)}\n"
            f"def _clawss_getcwd():\n"
            f"    _real = _clawss_real_getcwd().replace(chr(92), '/')\n"
            f"    if _real.startswith(_clawss_real_root):\n"
            f"        _rel = _real[len(_clawss_real_root):].lstrip('/')\n"
            f"        return _clawss_visible_root + ('/' + _rel if _rel else '')\n"
            f"    return _real\n"
            f"_os.getcwd = _clawss_getcwd\n"
            f"del _os\n"
        )

    @staticmethod
    def _rich_output_setup() -> str:
        """Python code that enables inline matplotlib plots and PIL image display."""
        return (
            "try:\n"
            "    import matplotlib as _mpl\n"
            "    _mpl.use('agg')\n"
            "    from matplotlib_inline.backend_inline import configure_inline_support as _cis\n"
            "    import IPython as _ip\n"
            "    _shell = _ip.get_ipython()\n"
            "    if _shell:\n"
            "        _cis(_shell, 'inline')\n"
            "        _shell.run_line_magic('matplotlib', 'inline')\n"
            "    _mpl.rcParams['animation.html'] = 'jshtml'\n"
            "    del _mpl, _cis, _ip, _shell\n"
            "except Exception:\n"
            "    pass\n"
            "try:\n"
            "    import plotly.io as _pio\n"
            "    _pio.renderers.default = 'notebook'\n"
            "    del _pio\n"
            "except Exception:\n"
            "    pass\n"
            # ── Animation-aware plt.show() ──
            # Store registry and originals on the matplotlib.animation module
            # so they're accessible from any exec scope (cell namespaces
            # can't see kernel-global closures).
            "try:\n"
            "    import matplotlib.pyplot as _plt\n"
            "    import matplotlib.animation as _manim\n"
            "    from matplotlib.figure import Figure as _Figure\n"
            "    _manim._mpynb_registry = {}\n"
            "    _manim._mpynb_orig_func_init = _manim.FuncAnimation.__init__\n"
            "    def _mpynb_display_static(fig):\n"
            "        from IPython.display import display\n"
            "        try:\n"
            "            fig.canvas.draw_idle()\n"
            "        except Exception:\n"
            "            pass\n"
            "        display(fig)\n"
            "    _manim._mpynb_display_static = _mpynb_display_static\n"
            "    def _patched_func_anim_init(self, fig, *a, **kw):\n"
            "        import matplotlib.animation as _m\n"
            "        _m._mpynb_orig_func_init(self, fig, *a, **kw)\n"
            "        _m._mpynb_registry[id(fig)] = self\n"
            "    _manim.FuncAnimation.__init__ = _patched_func_anim_init\n"
            "    try:\n"
            "        _manim._mpynb_orig_artist_init = _manim.ArtistAnimation.__init__\n"
            "        def _patched_artist_anim_init(self, fig, *a, **kw):\n"
            "            import matplotlib.animation as _m\n"
            "            _m._mpynb_orig_artist_init(self, fig, *a, **kw)\n"
            "            _m._mpynb_registry[id(fig)] = self\n"
            "        _manim.ArtistAnimation.__init__ = _patched_artist_anim_init\n"
            "    except Exception:\n"
            "        pass\n"
            "    _manim._mpynb_orig_plt_show = _plt.show\n"
            "    def _patched_plt_show(*a, **kw):\n"
            "        from IPython.display import display, HTML\n"
            "        import matplotlib.pyplot as plt\n"
            "        import matplotlib.animation as _m\n"
            "        figs = list(plt.get_fignums())\n"
            "        animated_figs = set()\n"
            "        for fnum in figs:\n"
            "            fig = plt.figure(fnum)\n"
            "            fid = id(fig)\n"
            "            if fid in _m._mpynb_registry:\n"
            "                ani = _m._mpynb_registry.pop(fid)\n"
            "                try:\n"
            "                    display(HTML(ani.to_jshtml()))\n"
            "                    animated_figs.add(fnum)\n"
            "                except Exception:\n"
            "                    pass\n"
            "        for fnum in figs:\n"
            "            if fnum in animated_figs:\n"
            "                plt.close(fnum)\n"
            "                continue\n"
            "            fig = plt.figure(fnum)\n"
            "            try:\n"
            "                _m._mpynb_display_static(fig)\n"
            "            finally:\n"
            "                plt.close(fnum)\n"
            "    _plt.show = _patched_plt_show\n"
            "    _manim._mpynb_orig_fig_show = _Figure.show\n"
            "    def _patched_fig_show(self, *a, **kw):\n"
            "        from IPython.display import display, HTML\n"
            "        import matplotlib.animation as _m\n"
            "        import matplotlib.pyplot as plt\n"
            "        fid = id(self)\n"
            "        if fid in _m._mpynb_registry:\n"
            "            ani = _m._mpynb_registry.pop(fid)\n"
            "            try:\n"
            "                display(HTML(ani.to_jshtml()))\n"
            "            finally:\n"
            "                plt.close(self)\n"
            "            return\n"
            "        _m._mpynb_display_static(self)\n"
            "        plt.close(self)\n"
            "    _Figure.show = _patched_fig_show\n"
            "    del _plt, _manim, _Figure, _mpynb_display_static, _patched_func_anim_init, _patched_plt_show, _patched_fig_show\n"
            "except Exception:\n"
            "    pass\n"
            "try:\n"
            "    from PIL import Image as _PILImg\n"
            "    def _repr_png(self):\n"
            "        import io\n"
            "        b = io.BytesIO()\n"
            "        self.save(b, format='PNG' if self.mode != 'CMYK' else 'JPEG')\n"
            "        return b.getvalue()\n"
            "    def _show_inline(self, title=None, **kwargs):\n"
            "        from IPython.display import display\n"
            "        display(self)\n"
            "    _PILImg.Image._repr_png_ = _repr_png\n"
            "    _PILImg.Image.show = _show_inline\n"
            "    del _PILImg, _repr_png, _show_inline\n"
            "except Exception:\n"
            "    pass"
        )

    def _guard_code(self) -> str:
        """Python code that installs a sys.meta_path guard in the kernel.
        Blocks cross-notebook imports unless the source cell has been executed
        this session and hasn't been modified since.
        """
        mpd = repr(str(self.mpynb_dir))
        reg = repr(str(self.mpynb_dir / ".session_registry.json"))
        return f"""
import sys as _sys, json as _json
from pathlib import Path as _P
class _MpynbGuard:
    # Store module refs as class attributes so they survive `del` cleanup
    _s = _sys
    _j = _json
    _p = _P
    _mn = _P({mpd})
    _mr = _P({reg})
    def _read(self):
        try:
            return self._j.loads(self._mr.read_text('utf-8')) if self._mr.exists() else {{}}
        except Exception:
            return {{}}
    def find_spec(self, fullname, path, target=None):
        pts = fullname.split('.')
        if len(pts) < 2:
            return None
        pkg = pts[0]
        if not (self._mn / pkg).is_dir():
            return None
        # ALL imports (same-notebook and cross-notebook) must go through
        # the registry.  No shortcuts — the cell MUST have been executed
        # in this kernel session.
        #
        # The registry is authoritative: entries are added on execution
        # and removed by _sync_notebook_package when the raw source
        # changes.  The guard only checks presence.
        reg = self._read()
        pr = reg.get(pkg, {{}})
        fn = pts[1] + '.py'
        if fn not in pr:
            raise ModuleNotFoundError(
                f"Cannot import '{{fullname}}': '{{fn}}' in notebook '{{pkg}}' "
                "has not been executed this session — run it first."
            )
        return None
_sys.meta_path.insert(0, _MpynbGuard())
del _sys, _json, _P, _MpynbGuard
"""

    async def _silent(self, code: str):
        self.kc.execute(code, silent=True)
        while True:
            try:
                msg = await asyncio.wait_for(self.kc.get_iopub_msg(), timeout=30)
                if (
                    msg["msg_type"] == "status"
                    and msg["content"]["execution_state"] == "idle"
                ):
                    break
            except asyncio.TimeoutError:
                break

    async def execute(
        self,
        cell_id: str,
        filename: str,
        source: str,
        imports_source: Optional[str],
        on_output: Callable,
        on_input_request: Optional[Callable[[dict], Awaitable[str]]] = None,
    ) -> dict:
        self._current_task = asyncio.current_task()
        try:
            async with self._lock:
                self._interrupt_event.clear()
                self._running_cell_id = cell_id
                self.execution_count += 1
                count = self.execution_count

                # Write to hidden __cells__ dir — keeps working dir clean
                cell_file = self.cells_dir / filename
                cell_file.parent.mkdir(parents=True, exist_ok=True)
                cell_file.write_text(source, encoding="utf-8")

                module_name = filename[:-3] if filename.endswith(".py") else filename

                # ── Build isolated execution code ──────────────────────────────
                if filename == "imports.py":
                    # imports.py: run in its own module, store namespace for seeding
                    exec_code = f"""
import types as __t, sys as __s
__mod = __t.ModuleType('imports')
__mod.__file__ = {repr(str(cell_file))}
exec(compile({repr(source)}, 'imports.py', 'exec'), __mod.__dict__)
__s.modules['imports'] = __mod
# Store clean copy — used to seed all other cells
__mpynb_imports_ns__ = {{k: v for k, v in __mod.__dict__.items() if not k.startswith('__')}}
del __t, __s, __mod
"""
                else:
                    # Regular cell: fresh module, seeded with imports.py namespace
                    exec_code = f"""
import types as __t, sys as __s
__mod_name = {repr(module_name)}
__file_path = {repr(str(cell_file))}
# Remove stale cached module
__s.modules.pop(__mod_name, None)
# Fresh isolated namespace — only seeded from imports.py
__mod = __t.ModuleType(__mod_name)
__mod.__file__ = __file_path
__mod.__dict__.update(globals().get('__mpynb_imports_ns__', {{}}))
# Execute cell in its own isolated namespace
exec(compile({repr(source)}, __file_path, 'exec'), __mod.__dict__)
# Register so other cells can: from {module_name} import x
__s.modules[__mod_name] = __mod
del __t, __s, __mod_name, __file_path, __mod
"""

                start_t = time.time()
                start_mem = self._mem()
                status = "success"
                _out_buf: List[dict] = []
                _last_flush = time.monotonic()
                _stream_bytes = 0
                _stream_truncated = False

                # Cells are flat — cwd is always the notebook dir.
                await self._silent(f"import os; os.chdir({repr(str(self.notebook_dir))})")

                # Clear stale cross-notebook package modules so edits in other
                # notebooks are always picked up before this cell runs.
                await self._silent(
                f"import sys as _s, os as _o, importlib as _il\n"
                f"_mpd={repr(str(self.mpynb_dir))}\n"
                f"if _o.path.isdir(_mpd):\n"
                f"    _sk=[k for d in _o.listdir(_mpd) if _o.path.isdir(_o.path.join(_mpd,d)) for k in list(_s.modules) if k==d or k.startswith(d+'.')]\n"
                f"    [_s.modules.pop(k) for k in _sk]\n"
                f"    _il.invalidate_caches()\n"
                f"del _s,_o,_il,_mpd\n"
                )

                self.kc.execute(exec_code, store_history=True, allow_stdin=on_input_request is not None)

                while True:
                    iopub_task = asyncio.create_task(self.kc.get_iopub_msg())
                    stdin_task = (
                        asyncio.create_task(self.kc.get_stdin_msg())
                        if on_input_request is not None
                        else None
                    )
                    wait_tasks = {iopub_task}
                    if stdin_task is not None:
                        wait_tasks.add(stdin_task)
                    done, pending = await asyncio.wait(wait_tasks, return_when=asyncio.FIRST_COMPLETED)
                    for task in pending:
                        task.cancel()
                    if stdin_task is not None and stdin_task in done:
                        msg = stdin_task.result()
                        if msg.get("msg_type") == "input_request":
                            content = msg["content"]
                            if _out_buf:
                                await self._flush_outputs(_out_buf, on_output)
                                _last_flush = time.monotonic()
                            input_task = asyncio.create_task(
                                on_input_request(
                                    {
                                        "prompt": content.get("prompt", ""),
                                        "password": bool(content.get("password", False)),
                                    }
                                )
                            )
                            interrupt_task = asyncio.create_task(self._interrupt_event.wait())
                            input_done, _ = await asyncio.wait(
                                {input_task, interrupt_task},
                                return_when=asyncio.FIRST_COMPLETED,
                            )
                            if interrupt_task in input_done:
                                input_task.cancel()
                                try:
                                    await input_task
                                except (asyncio.CancelledError, Exception):
                                    pass
                                continue
                            interrupt_task.cancel()
                            reply = input_task.result()
                            self.kc.input(reply)
                            continue
                    msg = iopub_task.result()

                    mtype = msg["msg_type"]
                    content = msg["content"]

                    if mtype == "stream":
                        text = content["text"]
                        if not _stream_truncated:
                            remaining = MAX_STREAM_BYTES - _stream_bytes
                            encoded = text.encode("utf-8")
                            if len(encoded) > remaining:
                                if remaining > 0:
                                    _out_buf.append(
                                        {
                                            "type": "stream",
                                            "name": content["name"],
                                            "text": encoded[:remaining].decode("utf-8", errors="ignore"),
                                        }
                                    )
                                    _stream_bytes = MAX_STREAM_BYTES
                                _out_buf.append({
                                    "type": "stream",
                                    "name": "stderr",
                                    "text": "\n[mpynb] Earlier stream output was trimmed to keep this cell responsive.\n",
                                })
                                _stream_truncated = True
                            else:
                                _stream_bytes += len(encoded)
                                _out_buf.append(
                                    {"type": "stream", "name": content["name"], "text": text}
                                )

                    elif mtype in ("display_data", "execute_result"):
                        data = content.get("data", {})
                        _out_buf.append({"type": "display", "data": data})

                    elif mtype == "error":
                        status = "error"
                        tb = [ANSI_ESCAPE.sub("", l) for l in content.get("traceback", [])]
                        tb = self._clean_traceback(tb, filename)
                        _out_buf.append(
                            {
                                "type": "error",
                                "ename": content["ename"],
                                "evalue": content["evalue"],
                                "traceback": tb,
                            }
                        )

                    elif mtype == "status" and content["execution_state"] == "idle":
                        break

                    now = time.monotonic()
                    if now - _last_flush >= 0.03 and _out_buf:
                        await self._flush_outputs(_out_buf, on_output)
                        _last_flush = now

                if _out_buf:
                    await self._flush_outputs(_out_buf, on_output)

                elapsed = (time.time() - start_t) * 1000
                mem_delta = self._mem() - start_mem

                return {
                    "status": status,
                    "execution_count": count,
                    "time_ms": round(elapsed, 1),
                    "memory_delta_mb": round(mem_delta, 2),
                }
        finally:
            self._running_cell_id = None
            self._current_task = None

    @staticmethod
    async def _flush_outputs(buf: List[dict], on_output: Callable):
        """Flush buffered outputs, merging consecutive stream chunks of the same name."""
        merged: List[dict] = []
        for item in buf:
            if (
                merged
                and merged[-1]["type"] == "stream"
                and item["type"] == "stream"
                and merged[-1]["name"] == item["name"]
            ):
                merged[-1] = {**merged[-1], "text": merged[-1]["text"] + item["text"]}
            else:
                merged.append(item)
        for item in merged:
            await on_output(item)
        buf.clear()

    @staticmethod
    def _clean_traceback(tb: List[str], filename: str) -> List[str]:
        """Strip wrapper frames (exec/compile boilerplate) from tracebacks,
        keeping only frames from the user's cell file and the final error."""
        cleaned: List[str] = []
        skip_next_code = False
        for line in tb:
            # Skip the "Cell In[N]" frames that show our exec(compile(...)) wrapper
            if line.lstrip().startswith("Cell In["):
                skip_next_code = True
                continue
            # Skip continuation lines of wrapper frames (the source line)
            if skip_next_code:
                # Continuation lines are indented or start with "--->"
                if line.startswith("    ") or line.lstrip().startswith("--->"):
                    continue
                skip_next_code = False
            # Rewrite __cells__ paths to show just the cell filename
            if "__cells__" in line:
                # "File ~\...\__cells__\dir\cell1.py:37" -> "File cell1.py, line 37"
                line = re.sub(
                    r'File ["\']?.*?__cells__[\\/]',
                    "File ",
                    line,
                )
            cleaned.append(line)
        return cleaned

    def _mem(self) -> float:
        try:
            return psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024
        except Exception:
            return 0.0

    async def run_capture(self, code: str, timeout: float = 60.0) -> str:
        """Execute code in the kernel under the same lock as cell execution.
        Returns concatenated stdout. Raises on kernel error or timeout.
        Used by internal tooling (visualizer) — never exposes UI output."""
        async with self._lock:
            self.kc.execute(code, silent=False, store_history=False, allow_stdin=False)
            out: List[str] = []
            err: Optional[str] = None
            loop = asyncio.get_event_loop()
            deadline = loop.time() + timeout
            while True:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    raise TimeoutError(f"kernel run_capture exceeded {timeout}s")
                try:
                    msg = await asyncio.wait_for(self.kc.get_iopub_msg(), timeout=remaining)
                except asyncio.TimeoutError:
                    raise TimeoutError(f"kernel run_capture exceeded {timeout}s")
                mt = msg["msg_type"]
                content = msg["content"]
                if mt == "stream" and content.get("name") == "stdout":
                    out.append(content.get("text", ""))
                elif mt == "error" and err is None:
                    err = f"{content.get('ename')}: {content.get('evalue')}"
                elif mt == "status" and content.get("execution_state") == "idle":
                    break
            if err is not None:
                raise RuntimeError(err)
            return "".join(out)

    async def interrupt(self):
        self._interrupt_event.set()
        if self.km:
            await self.km.interrupt_kernel()

    async def restart(self):
        if self.km:
            await self.km.restart_kernel()
            await self._attach_client_and_setup()

    async def shutdown(self):
        if self.kc:
            self.kc.stop_channels()
        if self.km:
            await self.km.shutdown_kernel(now=True)

    @property
    def is_running(self) -> bool:
        return self._running_cell_id is not None
