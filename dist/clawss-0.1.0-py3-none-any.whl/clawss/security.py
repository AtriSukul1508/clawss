import hmac
import secrets
from fastapi import HTTPException, Request, Response, WebSocket

SESSION_COOKIE = "clawss_session"
SESSION_HEADER = "x-clawss-token"
SESSION_QUERY = "token"
SESSION_TOKEN = secrets.token_urlsafe(32)


def issue_session_cookie(response: Response) -> None:
    response.set_cookie(
        SESSION_COOKIE,
        SESSION_TOKEN,
        httponly=True,
        samesite="strict",
        secure=False,
        path="/",
    )


def session_cookie_valid(cookie_value: str | None) -> bool:
    return bool(cookie_value) and hmac.compare_digest(cookie_value, SESSION_TOKEN)


def session_header_valid(header_value: str | None) -> bool:
    return bool(header_value) and hmac.compare_digest(header_value, SESSION_TOKEN)


def require_request_session(request: Request) -> None:
    if not session_cookie_valid(request.cookies.get(SESSION_COOKIE)):
        raise HTTPException(401, "Missing session")


def require_request_csrf(request: Request) -> None:
    require_request_session(request)
    if request.method.upper() in {"GET", "HEAD", "OPTIONS"}:
        return
    if not session_header_valid(request.headers.get(SESSION_HEADER)):
        raise HTTPException(403, "Invalid session token")


def websocket_session_valid(websocket: WebSocket) -> bool:
    # WebSocket upgrades behind local dev proxies can legitimately lose the
    # backend-issued cookie even when the caller already holds the session
    # token. For sockets, the query token is the real bearer secret.
    return session_header_valid(websocket.query_params.get(SESSION_QUERY))
