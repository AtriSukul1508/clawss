import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
import hashlib
import httpx
import io
import json
import logging
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import quote, urlparse

if sys.platform == "win32":
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    except Exception:
        pass

import uvicorn
from fastapi import FastAPI, Form, HTTPException, Request, UploadFile, File as FastAPIFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.background import BackgroundTask

from .analysis import analyze_cells
from .execution_runtime import (
    DEFAULT_RUNTIME,
    build_runtime_session,
    normalize_runtime_config,
    runtime_cache_key,
)
from .filesystem import build_tree
from .gpu_runpod import (
    runpod_create_pod,
    runpod_delete_pod,
    runpod_list_gpu_types,
    runpod_list_pods,
    runpod_stop_pod,
    validate_runpod_key,
)
from .gpu_store import (
    delete_provider_key,
    get_provider_key,
    provider_key_status,
    save_provider_key,
)
from .notebook import (
    inject_smart_imports,
    link_runtime_imports,
    load_notebook,
    make_importable,
    save_notebook,
    validate_cell_filename,
)
from .openrouter_store import (
    delete_openrouter_key,
    get_openrouter_key,
    openrouter_key_status,
    save_openrouter_key,
)
from .remote_jupyter import probe_remote_jupyter
from .security import (
    SESSION_COOKIE,
    SESSION_HEADER,
    SESSION_QUERY,
    SESSION_TOKEN,
    issue_session_cookie,
    require_request_csrf,
    session_cookie_valid,
    websocket_session_valid,
)
from .terminal import TerminalManager
from .visualizer import build_inspect_code, build_extract_code

CLIENT_HEADER = "X-Clawss-Client"
CLIENT_QUERY = "client_id"
CLIENT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,128}$")
INTERRUPT_REPLACE_GRACE_S = 0.25

def _allowed_local_origins() -> list[str]:
    origins = {
        "http://127.0.0.1:8765",
        "http://localhost:8765",
        "http://127.0.0.1:5173",
        "http://localhost:5173",
    }
    for raw in os.environ.get("CLAWSS_DEV_ORIGINS", "").split(","):
        value = raw.strip()
        if value:
            origins.add(value.rstrip("/"))
    return sorted(origins)


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(title="mpynb")
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_local_origins(),
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)


# ── Security: CSP header on HTML responses ─────────────────────────────────────
@app.middleware("http")
async def _auth_and_csp(request: Request, call_next):
    client_scope = None
    try:
        if request.url.path.startswith("/api/"):
            client_id = _request_client_id(request)
            if client_id:
                _cancel_pending_browser_close(client_id)
                client_scope = _client_scope(client_id)
                client_scope.__enter__()
        if request.url.path.startswith("/api/") and request.url.path != "/api/auth/bootstrap":
            require_request_csrf(request)
        response = await call_next(request)
    except HTTPException as exc:
        response = JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    finally:
        if client_scope is not None:
            client_scope.__exit__(None, None, None)
    if request.url.path == "/" or request.url.path.startswith("/api/"):
        if not session_cookie_valid(request.cookies.get(SESSION_COOKIE)):
            issue_session_cookie(response)
    ct = response.headers.get("content-type", "")
    if ct.startswith("text/html"):
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data: blob:; "
            "connect-src 'self' ws: wss:; "
            "object-src 'none'; "
            "base-uri 'self'; "
            "frame-ancestors 'none'"
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
    return response

# ── State ──────────────────────────────────────────────────────────────────────
APP_HOME = Path.home() / ".clawss"
ROOT_DIR = APP_HOME / "projects"
ROOT_DIR.mkdir(parents=True, exist_ok=True)
WORKSPACE_ROOT = Path(os.environ.get("CLAWSS_WORKSPACE_ROOT", os.getcwd())).resolve()
WORKSPACE_ROOT.mkdir(parents=True, exist_ok=True)
VISIBLE_PROJECTS_DIR = WORKSPACE_ROOT
VISIBLE_PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
WORKING_DIR = WORKSPACE_ROOT
MPYNB_PACKAGES_DIR = WORKSPACE_ROOT / "__mpynb__"
NOTEBOOK_PATH: Optional[Path] = None


@dataclass
class ClientContext:
    working_dir: Path
    notebook_path: Optional[Path] = None


_client_contexts: Dict[str, ClientContext] = {}
_current_client_id: ContextVar[Optional[str]] = ContextVar("clawss_client_id", default=None)
_SESSIONS_DIR = WORKSPACE_ROOT / ".clawss_sessions"
_SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
_SESSION_FILE = ".mpynb_session.json"
_RUNTIME_DIR = WORKSPACE_ROOT / ".clawss_runtime"
_RUNTIME_MARKER = _RUNTIME_DIR / f"{os.getpid()}.json"
_BROWSER_CLOSE_GRACE_S = 4.0

# Per-notebook execution session pool: abs_path -> local or remote session
kernels: Dict[str, object] = {}
_kernel_runtime_keys: Dict[str, str] = {}
_kernel_locks: Dict[str, asyncio.Lock] = {}
_kernel_last_activity: Dict[str, float] = {}
_kernel_idle_task: Optional[asyncio.Task] = None
_pending_browser_close_tasks: Dict[str, asyncio.Task] = {}

# Incremental sync: abs_nb_path -> {filename -> md5}
_sync_hashes: Dict[str, Dict[str, str]] = {}

# Cross-notebook session registry, scoped by workspace package root:
# registry_file -> {pkg_name -> {filename -> md5_of_source_at_execution}}
_xnb_registry: Dict[str, Dict[str, Dict[str, str]]] = {}
def _xnb_registry_file() -> Path:
    return _packages_dir() / ".session_registry.json"

# Same-notebook staleness: abs_nb_path -> {filename -> md5(source at last successful run)}
_nb_cell_run_hashes: Dict[str, Dict[str, str]] = {}

# Per-notebook save locks — prevents concurrent writes to the same .mpynb file
_save_locks: Dict[str, asyncio.Lock] = {}
_workspace_lock = asyncio.Lock()

terminal_manager = TerminalManager()
logger = logging.getLogger("clawss")
KERNEL_IDLE_TIMEOUT_S = 20 * 60
KERNEL_IDLE_SWEEP_INTERVAL_S = 30
SERVER_INSTANCE_ID = uuid.uuid4().hex
_kernel_ws_clients: Dict[str, set[WebSocket]] = {}


async def _shutdown_all_kernels():
    for ks in list(kernels.values()):
        try:
            await ks.shutdown()
        except Exception:
            pass
    kernels.clear()
    _kernel_runtime_keys.clear()
    _kernel_locks.clear()
    _sync_hashes.clear()
    _nb_cell_run_hashes.clear()
    _save_locks.clear()
    _xnb_registry.clear()


def _clear_all_xnb_registry_files() -> None:
    for reg_file in ROOT_DIR.rglob(".session_registry.json"):
        try:
            reg_file.unlink(missing_ok=True)
        except Exception:
            pass


def _is_within_root(target: Path, root: Path) -> bool:
    try:
        target.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _visible_path(path: Path) -> Path:
    return _context_visible_path(_get_client_context(), path)


def _project_store_dir(name: str) -> Path:
    return (ROOT_DIR / name).resolve()


def _project_visible_dir(name: str) -> Path:
    return VISIBLE_PROJECTS_DIR / name


def _hide_dir_if_supported(path: Path) -> None:
    try:
        if os.name == "nt":
            subprocess.run(
                ["attrib", "+h", str(path)],
                capture_output=True,
                text=True,
                check=False,
            )
        elif sys.platform == "darwin":
            subprocess.run(
                ["chflags", "hidden", str(path)],
                capture_output=True,
                text=True,
                check=False,
            )
    except Exception:
        pass


_hide_dir_if_supported(_SESSIONS_DIR)

_INTERNAL_BLOCKED_PATH_PARTS = {
    "__pycache__",
    "__cells__",
    "__mpynb__",
    ".git",
    ".mpynb_snapshots",
    "node_modules",
    ".venv",
    "venv",
}

MAX_UPLOAD_BYTES = 50 * 1024 * 1024
MAX_TEXT_READ_BYTES = 2 * 1024 * 1024
UPLOAD_CHUNK_BYTES = 1024 * 1024


def _paths_same(a: Path, b: Path) -> bool:
    try:
        return a.resolve() == b.resolve()
    except Exception:
        return False


def _host_header_is_local(host_header: Optional[str]) -> bool:
    if not host_header:
        return False
    return host_header.split(":", 1)[0].strip("[]").casefold() in {"localhost", "127.0.0.1", "::1"}


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _prune_runtime_markers() -> int:
    _RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    live = 0
    for marker in _RUNTIME_DIR.glob("*.json"):
        try:
            pid = int(marker.stem)
        except Exception:
            marker.unlink(missing_ok=True)
            continue
        if _pid_is_running(pid):
            live += 1
        else:
            marker.unlink(missing_ok=True)
    return live


def _register_runtime_marker() -> None:
    _RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    _RUNTIME_MARKER.write_text(
        json.dumps({"pid": os.getpid(), "serverInstanceId": SERVER_INSTANCE_ID}),
        encoding="utf-8",
    )


def _cleanup_workspace_startup_if_safe() -> None:
    if _prune_runtime_markers() == 0:
        _cleanup_workspace_temp_artifacts(force=True)
    _register_runtime_marker()


def _cancel_pending_browser_close(client_id: Optional[str]) -> None:
    if not client_id:
        return
    task = _pending_browser_close_tasks.pop(client_id, None)
    if task and not task.done():
        task.cancel()


def _validate_project_name(name: str) -> str:
    project_name = (name or "").strip()
    if not project_name:
        raise HTTPException(400, "Project name required")
    if (
        project_name in {".", ".."}
        or project_name.startswith(".")
        or "/" in project_name
        or "\\" in project_name
        or Path(project_name).name != project_name
    ):
        raise HTTPException(400, "Invalid project name")
    return project_name


def _create_dir_alias(link: Path, target: Path) -> None:
    link.parent.mkdir(parents=True, exist_ok=True)
    try:
        link.symlink_to(target, target_is_directory=True)
        _hide_dir_if_supported(link)
        return
    except FileExistsError:
        return
    except OSError:
        if os.name != "nt":
            raise
    proc = subprocess.run(
        ["cmd", "/c", "mklink", "/J", str(link), str(target)],
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "Could not create project alias")
    _hide_dir_if_supported(link)


def _ensure_visible_project_dir(name: str) -> Path:
    target = _project_store_dir(name)
    link = _project_visible_dir(name)
    if link.exists() or link.is_symlink():
        if _paths_same(link, target):
            return link
        raise HTTPException(
            409,
            f'Launch directory already contains "{name}". Move or rename it before opening this project.',
        )
    _create_dir_alias(link, target)
    return link


def _remove_visible_project_dir(name: str) -> None:
    link = _project_visible_dir(name)
    if not (link.exists() or link.is_symlink()):
        return
    target = _project_store_dir(name)
    if not _paths_same(link, target):
        return
    try:
        if link.is_symlink():
            link.unlink()
            return
        os.rmdir(link)
        return
    except FileNotFoundError:
        return
    except OSError:
        if os.name == "nt":
            try:
                subprocess.run(
                    ["cmd", "/c", "rmdir", str(link)],
                    capture_output=True,
                    text=True,
                    check=False,
                )
            except Exception:
                pass
        if not (link.exists() or link.is_symlink()):
            return


def _validate_client_id(raw: Optional[str]) -> str:
    value = str(raw or "").strip()
    if not CLIENT_ID_RE.fullmatch(value):
        raise HTTPException(400, "Invalid client id")
    return value


def _context_project_name(ctx: ClientContext) -> Optional[str]:
    try:
        if ctx.working_dir == WORKSPACE_ROOT:
            return None
        if ctx.working_dir.parent == WORKSPACE_ROOT:
            return ctx.working_dir.name
    except Exception:
        return None
    return None


def _contexts_using_project(name: str, *, exclude_client: Optional[str] = None) -> int:
    total = 0
    for client_id, ctx in _client_contexts.items():
        if exclude_client and client_id == exclude_client:
            continue
        if _context_project_name(ctx) == name:
            total += 1
    return total


def _session_file(client_id: Optional[str] = None) -> Optional[Path]:
    cid = client_id or _current_client_id.get()
    if not cid:
        return _working_dir() / _SESSION_FILE
    return _SESSIONS_DIR / f"{cid}.json"


def _read_session_payload(client_id: Optional[str] = None) -> dict:
    f = _session_file(client_id)
    if f is None:
        return {}
    try:
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except Exception:
        return {}


def _context_visible_path(ctx: ClientContext, path: Path) -> Path:
    try:
        rel = path.resolve().relative_to(ctx.working_dir.resolve())
    except Exception:
        return path
    return ctx.working_dir / rel


def _context_session_payload(ctx: ClientContext) -> dict:
    nb_path = None
    if ctx.notebook_path:
        nb_path = str(_context_visible_path(ctx, ctx.notebook_path))
    return {
        "__context__": {
            "project": _context_project_name(ctx),
            "notebook_path": nb_path,
        }
    }


def _write_session_payload(data: dict, *, merge: bool = False, client_id: Optional[str] = None) -> None:
    f = _session_file(client_id)
    if f is None:
        return
    payload = dict(_read_session_payload(client_id)) if merge else {}
    payload.update({k: v for k, v in (data or {}).items() if k != "__context__"})
    cid = client_id or _current_client_id.get()
    ctx = _client_contexts.get(cid) if cid else None
    if ctx is not None:
        payload.update(_context_session_payload(ctx))
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        if f.parent == _SESSIONS_DIR:
            _hide_dir_if_supported(f.parent)
        f.write_text(json.dumps(payload), encoding="utf-8")
    except Exception:
        pass


def _session_projects(exclude_client: Optional[str] = None) -> set[str]:
    projects: set[str] = set()
    for session_file in _SESSIONS_DIR.glob("*.json"):
        client_id = session_file.stem
        if exclude_client and client_id == exclude_client:
            continue
        try:
            payload = json.loads(session_file.read_text(encoding="utf-8"))
        except Exception:
            continue
        raw_project = str((payload.get("__context__") or {}).get("project") or "").strip()
        if not raw_project:
            continue
        try:
            projects.add(_validate_project_name(raw_project))
        except HTTPException:
            continue
    return projects


def _context_has_workspace_state(ctx: ClientContext) -> bool:
    return bool(_context_project_name(ctx) or ctx.notebook_path)


def _session_has_workspace_state(payload: dict) -> bool:
    context = payload.get("__context__") or {}
    if context.get("project") or context.get("notebook_path"):
        return True
    if payload.get("activeNotebookPath"):
        return True
    if payload.get("openNotebooks"):
        return True
    if payload.get("runtimeDisconnectedPaths"):
        return True
    return False


def _cleanup_workspace_temp_artifacts(*, force: bool = False) -> None:
    has_live_workspace_contexts = any(
        _context_has_workspace_state(ctx) for ctx in _client_contexts.values()
    )
    has_session_workspace_state = False
    for session_file in _SESSIONS_DIR.glob("*.json"):
        try:
            payload = json.loads(session_file.read_text(encoding="utf-8"))
        except Exception:
            payload = {}
        if _session_has_workspace_state(payload):
            has_session_workspace_state = True
            break
    if not force and (has_live_workspace_contexts or has_session_workspace_state):
        return

    try:
        for child in WORKSPACE_ROOT.iterdir():
            if child.name in {"__mpynb__", ".clawss_sessions"}:
                continue
            if _paths_same(child, _project_store_dir(child.name)):
                _remove_visible_project_dir(child.name)
    except Exception:
        pass

    packages_dir = WORKSPACE_ROOT / "__mpynb__"
    if packages_dir.exists():
        shutil.rmtree(packages_dir, ignore_errors=True)

    root_session_file = WORKSPACE_ROOT / _SESSION_FILE
    root_session_file.unlink(missing_ok=True)
    for child_session in WORKSPACE_ROOT.glob(f"*/{_SESSION_FILE}"):
        child_session.unlink(missing_ok=True)

    if _SESSIONS_DIR.exists():
        shutil.rmtree(_SESSIONS_DIR, ignore_errors=True)


def _hydrate_client_context(client_id: str) -> ClientContext:
    payload = _read_session_payload(client_id)
    saved = payload.get("__context__") or {}
    raw_project = str(saved.get("project") or "").strip()
    try:
        project = _validate_project_name(raw_project) if raw_project else ""
    except HTTPException:
        project = ""
    if project:
        project_dir = _project_store_dir(project)
        if project_dir.is_dir():
            try:
                working_dir = _ensure_visible_project_dir(project)
            except Exception:
                working_dir = WORKSPACE_ROOT
        else:
            working_dir = WORKSPACE_ROOT
    else:
        working_dir = WORKSPACE_ROOT
    notebook_path: Optional[Path] = None
    raw_nb_path = str(saved.get("notebook_path") or "").strip()
    if raw_nb_path:
        raw = Path(raw_nb_path)
        candidate = raw if raw.is_absolute() else (working_dir / raw)
        try:
            resolved = candidate.resolve()
        except Exception:
            resolved = candidate
        if resolved.suffix == ".mpynb" and _is_within_root(resolved, working_dir) and resolved.exists():
            notebook_path = working_dir / resolved.relative_to(working_dir.resolve())
    if notebook_path is None and working_dir != WORKSPACE_ROOT:
        existing = sorted(working_dir.rglob("*.mpynb"))
        if existing:
            notebook_path = existing[0]
    ctx = ClientContext(working_dir=working_dir, notebook_path=notebook_path)
    _client_contexts[client_id] = ctx
    return ctx


def _get_client_context(client_id: Optional[str] = None) -> ClientContext:
    cid = client_id or _current_client_id.get()
    if not cid:
        return ClientContext(working_dir=WORKING_DIR, notebook_path=NOTEBOOK_PATH)
    ctx = _client_contexts.get(cid)
    if ctx is None:
        ctx = _hydrate_client_context(cid)
    return ctx


def _working_dir() -> Path:
    return _get_client_context().working_dir


def _packages_dir() -> Path:
    path = _working_dir() / "__mpynb__"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _notebook_path() -> Optional[Path]:
    return _get_client_context().notebook_path


def _set_working_dir(path: Path) -> None:
    global WORKING_DIR, MPYNB_PACKAGES_DIR
    cid = _current_client_id.get()
    if not cid:
        WORKING_DIR = path
        MPYNB_PACKAGES_DIR = path / "__mpynb__"
        MPYNB_PACKAGES_DIR.mkdir(parents=True, exist_ok=True)
        return
    _get_client_context(cid).working_dir = path


def _set_notebook_path(path: Optional[Path]) -> None:
    global NOTEBOOK_PATH
    cid = _current_client_id.get()
    if not cid:
        NOTEBOOK_PATH = path
        return
    _get_client_context(cid).notebook_path = path


def _sync_context_session() -> None:
    _write_session_payload({}, merge=True)


def _touch_kernel_activity(nb_path: str) -> None:
    _kernel_last_activity[nb_path] = time.monotonic()


def _looks_like_notebook_path(path: object) -> bool:
    return isinstance(path, str) and path.replace("\\", "/").endswith(".mpynb")


def _runtime_disconnected_paths(payload: Optional[dict]) -> set[str]:
    if not isinstance(payload, dict):
        return set()
    return {
        path for path in payload.get("runtimeDisconnectedPaths") or []
        if _looks_like_notebook_path(path)
    }


def _mark_runtime_disconnected_for_client(client_id: str, notebook_paths: list[str]) -> None:
    if not notebook_paths:
        return
    payload = _read_session_payload(client_id)
    disconnected = _runtime_disconnected_paths(payload)
    disconnected.update(path for path in notebook_paths if _looks_like_notebook_path(path))
    _write_session_payload(
        {"runtimeDisconnectedPaths": sorted(disconnected)},
        merge=True,
        client_id=client_id,
    )


def _clear_runtime_disconnected_for_client(client_id: str, notebook_path: str) -> None:
    if not _looks_like_notebook_path(notebook_path):
        return
    payload = _read_session_payload(client_id)
    disconnected = _runtime_disconnected_paths(payload)
    if notebook_path not in disconnected:
        return
    disconnected.discard(notebook_path)
    _write_session_payload(
        {"runtimeDisconnectedPaths": sorted(disconnected)},
        merge=True,
        client_id=client_id,
    )


def _clear_runtime_disconnected_for_active_client(notebook_path: str) -> None:
    client_id = _current_client_id.get()
    if client_id:
        _clear_runtime_disconnected_for_client(client_id, notebook_path)


def _client_requires_runtime_reconnect(nb_path: str, client_id: Optional[str] = None) -> bool:
    cid = client_id or _current_client_id.get()
    if not cid:
        return False
    return nb_path in _runtime_disconnected_paths(_read_session_payload(cid))


def _session_notebook_paths(client_id: str) -> list[str]:
    payload = _read_session_payload(client_id)
    seen: set[str] = set()
    paths: list[str] = []
    for entry in payload.get("openNotebooks") or []:
        if not isinstance(entry, dict):
            continue
        path = entry.get("path")
        if isinstance(path, str) and _looks_like_notebook_path(path) and path not in seen:
            seen.add(path)
            paths.append(path)
    active = payload.get("activeNotebookPath")
    if isinstance(active, str) and _looks_like_notebook_path(active) and active not in seen:
        paths.append(active)
    return paths


def _register_kernel_ws(client_id: Optional[str], websocket: WebSocket) -> None:
    if not client_id:
        return
    _cancel_pending_browser_close(client_id)
    _kernel_ws_clients.setdefault(client_id, set()).add(websocket)


def _unregister_kernel_ws(client_id: Optional[str], websocket: WebSocket) -> None:
    if not client_id:
        return
    sockets = _kernel_ws_clients.get(client_id)
    if not sockets:
        return
    sockets.discard(websocket)
    if not sockets:
        _kernel_ws_clients.pop(client_id, None)


async def _broadcast_kernel_status(
    nb_path: str,
    status: str,
    *,
    target_clients: Optional[set[str]] = None,
) -> None:
    payload = json.dumps({"type": "kernel_status", "status": status, "notebook_path": nb_path})
    pending: list[tuple[str, WebSocket, asyncio.Task]] = []
    for client_id, sockets in list(_kernel_ws_clients.items()):
        if target_clients is not None and client_id not in target_clients:
            continue
        if nb_path not in _session_notebook_paths(client_id):
            continue
        for socket in list(sockets):
            pending.append((client_id, socket, asyncio.create_task(socket.send_text(payload))))
    if not pending:
        return
    results = await asyncio.gather(*(task for _, _, task in pending), return_exceptions=True)
    for (client_id, socket, _), result in zip(pending, results):
        if isinstance(result, Exception):
            _unregister_kernel_ws(client_id, socket)


def _mark_runtime_disconnected_for_notebook(nb_path: str) -> set[str]:
    affected: set[str] = set()
    for session_file in _SESSIONS_DIR.glob("*.json"):
        client_id = session_file.stem
        if nb_path in _session_notebook_paths(client_id):
            _mark_runtime_disconnected_for_client(client_id, [nb_path])
            affected.add(client_id)
    return affected


async def _disconnect_runtime_for_client(client_id: str) -> None:
    notebook_paths = _session_notebook_paths(client_id)
    if not notebook_paths:
        return
    _mark_runtime_disconnected_for_client(client_id, notebook_paths)
    for nb_path in notebook_paths:
        await _drop_kernel_for_notebook(nb_path)


def _resolve_visible_notebook_context(raw_path: str) -> tuple[Path, Path]:
    text = str(raw_path or "").strip()
    if not text:
        raise HTTPException(400, "Notebook path required")
    candidate = Path(text)
    if not candidate.is_absolute():
        candidate = WORKSPACE_ROOT / candidate
    candidate = Path(os.path.abspath(str(candidate)))
    if candidate.suffix != ".mpynb":
        raise HTTPException(400, "Invalid notebook path")
    try:
        rel = candidate.relative_to(WORKSPACE_ROOT)
    except ValueError as exc:
        raise HTTPException(400, "Invalid notebook path") from exc
    if len(rel.parts) > 1:
        project_name = rel.parts[0]
        working_dir = _ensure_visible_project_dir(project_name)
        target = working_dir.joinpath(*rel.parts[1:])
    else:
        working_dir = WORKSPACE_ROOT
        target = WORKSPACE_ROOT / rel
    if not target.exists() or target.suffix != ".mpynb":
        raise HTTPException(404, "Notebook not found")
    return working_dir, target


@contextmanager
def _client_scope(client_id: str):
    _get_client_context(client_id)
    token = _current_client_id.set(client_id)
    try:
        yield
    finally:
        _current_client_id.reset(token)


def _active_project_name() -> Optional[str]:
    return _context_project_name(_get_client_context())


def _clear_active_visible_project() -> None:
    active_name = _active_project_name()
    if not active_name:
        return
    current_client = _current_client_id.get()
    if _contexts_using_project(active_name, exclude_client=current_client) == 0:
        _remove_visible_project_dir(active_name)


def _touch_project_access(project_dir: Path) -> None:
    try:
        project_dir.touch(exist_ok=True)
    except Exception:
        try:
            now = None
            os.utime(project_dir, times=now)
        except Exception:
            pass


def _reset_workspace_to_root() -> None:
    old_name = _active_project_name()
    _set_working_dir(WORKSPACE_ROOT)
    _packages_dir()
    _set_notebook_path(None)
    if old_name and _contexts_using_project(old_name) == 0:
        _remove_visible_project_dir(old_name)
    _write_session_payload({})


_cleanup_workspace_startup_if_safe()


def _force_rmtree(path: Path) -> None:
    def _retry_remove(func, target, _exc):
        try:
            if os.name == "nt":
                subprocess.run(
                    ["attrib", "-h", "-s", str(target)],
                    capture_output=True,
                    text=True,
                    check=False,
                )
            os.chmod(target, stat.S_IWRITE)
        except Exception:
            pass
        func(target)

    try:
        shutil.rmtree(path, onexc=_retry_remove)
        return
    except Exception:
        if os.name == "nt":
            try:
                subprocess.run(
                    [
                        "cmd",
                        "/c",
                        f'attrib -h -s /s /d "{path}\\*" & rd /s /q "{path}"',
                    ],
                    capture_output=True,
                    text=True,
                    check=False,
                )
            except Exception:
                pass
            if not path.exists():
                return
        raise


def _is_local_host(host: Optional[str]) -> bool:
    if not host:
        return False
    return host.split(":", 1)[0].strip("[]").casefold() in {"localhost", "127.0.0.1", "::1"}


def _parsed_origin_is_local(origin: str) -> bool:
    try:
        parsed = urlparse(origin)
    except Exception:
        return False
    return _is_local_host(parsed.netloc)


def _origin_allowed(origin: Optional[str], host_header: Optional[str]) -> bool:
    if not origin:
        return _host_header_is_local(host_header)
    if _parsed_origin_is_local(origin):
        return True
    parsed = urlparse(origin)
    normalized = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
    if normalized in _allowed_local_origins():
        return True
    origin_host = (parsed.hostname or "").casefold()
    if not host_header:
        return False
    request_host = host_header.split(":", 1)[0].strip("[]").casefold()
    return bool(request_host) and origin_host == request_host


def _bootstrap_origin_allowed(request: Request) -> bool:
    origin = request.headers.get("origin")
    if not origin:
        return _host_header_is_local(request.headers.get("host"))
    if _parsed_origin_is_local(origin):
        return True
    try:
        parsed = urlparse(origin)
    except Exception:
        return False
    normalized = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
    return normalized in _allowed_local_origins()


def _request_client_id(request: Request) -> Optional[str]:
    raw = request.headers.get(CLIENT_HEADER) or request.query_params.get(CLIENT_QUERY)
    if not raw:
        return None
    return _validate_client_id(raw)


def _websocket_client_id(websocket: WebSocket) -> Optional[str]:
    raw = websocket.headers.get(CLIENT_HEADER) or websocket.query_params.get(CLIENT_QUERY)
    if not raw:
        return None
    return _validate_client_id(raw)


def _safe_cell_archive_path(filename: str, default: str = "cell.py") -> str:
    raw = str(filename or default).strip()
    if not raw:
        raw = default
    if "/" in raw or "\\" in raw:
        raise HTTPException(400, "Nested cell filenames are not supported")
    if Path(raw).name != raw or raw in {"", ".", ".."}:
        raise HTTPException(400, "Invalid cell filename")
    dot = raw.rfind(".")
    stem = raw[:dot].strip() if dot > 0 else ""
    if not raw.endswith(".py"):
        raise HTTPException(400, "Only `.py` cell filenames are supported")
    if not stem:
        raise HTTPException(400, "Code cell filename must have a name before .py")
    return raw


def _safe_download_filename(filename: str, default: str = "cell.py") -> str:
    raw = Path(str(filename or default)).name.replace("\r", "").replace("\n", "").replace('"', "")
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", raw).strip("._")
    return safe or default


def _attachment_headers(filename: str) -> dict[str, str]:
    safe = _safe_download_filename(filename)
    return {"Content-Disposition": f'attachment; filename="{safe}"'}


def _cell_module_name(filename: str) -> str:
    return filename[:-3] if filename.endswith(".py") else filename


MAX_PROJECT_ZIP_BYTES = 50 * 1024 * 1024
MAX_PROJECT_ZIP_FILES = 2000
MAX_PROJECT_ZIP_ENTRY_BYTES = 25 * 1024 * 1024
MAX_PROJECT_ZIP_TOTAL_BYTES = 200 * 1024 * 1024


def _validate_project_zip(zf: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    infos = zf.infolist()
    if len(infos) > MAX_PROJECT_ZIP_FILES:
        raise HTTPException(400, "Zip has too many files")
    total_uncompressed = 0
    for info in infos:
        total_uncompressed += max(0, int(info.file_size or 0))
        if info.file_size > MAX_PROJECT_ZIP_ENTRY_BYTES:
            raise HTTPException(400, "Zip contains a file that is too large")
        if total_uncompressed > MAX_PROJECT_ZIP_TOTAL_BYTES:
            raise HTTPException(400, "Zip expands to too much data")
    return infos


async def _guard_websocket_origin(websocket: WebSocket) -> bool:
    host_header = websocket.headers.get("host")
    if _host_header_is_local(host_header):
        logger.info("ws guard allow local host=%r origin=%r path=%r", host_header, websocket.headers.get("origin"), websocket.url.path)
        return True
    if not _origin_allowed(websocket.headers.get("origin"), host_header):
        logger.warning("ws guard reject origin host=%r origin=%r path=%r", host_header, websocket.headers.get("origin"), websocket.url.path)
        await websocket.close(code=4403, reason="Origin not allowed")
        return False
    if websocket_session_valid(websocket):
        logger.info("ws guard allow token host=%r origin=%r path=%r", host_header, websocket.headers.get("origin"), websocket.url.path)
        return True
    logger.warning(
        "ws guard reject session host=%r origin=%r path=%r token_present=%s client_id=%r",
        host_header,
        websocket.headers.get("origin"),
        websocket.url.path,
        bool(websocket.query_params.get(SESSION_QUERY)),
        websocket.query_params.get(CLIENT_QUERY),
    )
    await websocket.close(code=4401, reason="Missing session")
    return False


OPENROUTER_BASE = "https://openrouter.ai/api/v1"
OLLAMA_DEFAULT_BASE = "http://127.0.0.1:11434"


def _openrouter_headers(api_key: str) -> dict:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://clawss.local",
        "X-Title": "clawss",
    }


def _openrouter_key_or_400() -> str:
    api_key, _storage = get_openrouter_key()
    if not api_key:
        raise HTTPException(400, "OpenRouter API key not configured")
    return api_key


def _normalize_ollama_base_url(raw: object) -> str:
    base = str(raw or OLLAMA_DEFAULT_BASE).strip() or OLLAMA_DEFAULT_BASE
    parsed = urlparse(base)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise HTTPException(400, "Ollama base URL must be a full http:// or https:// URL")
    return base.rstrip("/")


def _ollama_timeout_error(base_url: str, exc: Exception) -> HTTPException:
    return HTTPException(
        502,
        f"Could not reach Ollama at {base_url}. Make sure the Ollama server is running. ({exc})",
    )


def _ollama_json_error_message(payload: object, fallback: str) -> str:
    if isinstance(payload, dict):
        text = str(payload.get("error") or "").strip()
        if text:
            return text
    return fallback


def _ollama_chat_payload(data: dict, *, stream: bool) -> tuple[str, dict]:
    payload = dict(data or {})
    base_url = _normalize_ollama_base_url(payload.pop("base_url", None))
    model = str(payload.get("model", "")).strip()
    if not model:
        raise HTTPException(400, "Model required")
    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        raise HTTPException(400, "messages required")
    extras = {
        "temperature": payload.get("temperature"),
        "num_predict": payload.get("max_tokens"),
    }
    options = {k: v for k, v in extras.items() if isinstance(v, (int, float))}
    body = {
        "model": model,
        "messages": messages,
        "stream": stream,
    }
    if options:
        body["options"] = options
    response_format = payload.get("response_format")
    if isinstance(response_format, dict) and response_format.get("type") == "json_object":
        body["format"] = "json"
    return base_url, body


def _ollama_model_entry(model: dict) -> dict:
    details = model.get("details") if isinstance(model, dict) else {}
    name = str((model or {}).get("name") or "").strip()
    display = name
    family = str((details or {}).get("family") or "").strip()
    if family and family.lower() not in name.lower():
        display = f"{name} ({family})"
    return {
        "id": name,
        "name": display or name,
    }


def _http_error_message(response: httpx.Response) -> str:
    text = ""
    try:
        text = response.text[:200]
    except Exception:
        text = ""
    return text or response.reason_phrase or f"HTTP {response.status_code}"


def _gpu_provider_key_or_400(provider: str) -> str:
    api_key, _storage = get_provider_key(provider)  # type: ignore[arg-type]
    if not api_key:
        raise HTTPException(400, f"{provider} API key not configured")
    return api_key


def _safe_path(relative: str) -> Path:
    """Resolve a user-supplied path and ensure it stays inside the active client workspace."""
    working_dir = _working_dir()
    working_root = working_dir.resolve()
    raw = Path(relative)
    target = raw if raw.is_absolute() else (working_dir / raw)
    resolved = target.resolve()
    if not (_is_within_root(resolved, working_dir) or _is_within_root(resolved, working_root)):
        raise HTTPException(400, "Invalid path")
    try:
        rel_parts = resolved.relative_to(working_root).parts
    except Exception:
        try:
            rel_parts = resolved.relative_to(working_dir.resolve()).parts
        except Exception as exc:
            raise HTTPException(400, "Invalid path") from exc
    if any(part.startswith(".") or part in _INTERNAL_BLOCKED_PATH_PARTS for part in rel_parts):
        raise HTTPException(400, "Hidden or internal paths are not accessible")
    return _context_visible_path(_get_client_context(), resolved)


async def _write_upload_file_limited(file: UploadFile, dest: Path, max_bytes: int) -> None:
    temp = dest.with_name(f".{dest.name}.upload-{uuid.uuid4().hex}.tmp")
    total = 0
    try:
        with open(temp, "wb") as handle:
            while True:
                chunk = await file.read(UPLOAD_CHUNK_BYTES)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise HTTPException(413, f"Upload exceeds {max_bytes // (1024 * 1024)}MB limit")
                handle.write(chunk)
        os.replace(str(temp), str(dest))
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _read_text_file_limited(target: Path, limit: int = MAX_TEXT_READ_BYTES) -> tuple[str, int]:
    size = target.stat().st_size
    if size > limit:
        raise HTTPException(413, f"File too large to read in the browser ({limit // (1024 * 1024)}MB limit)")
    return target.read_text(encoding="utf-8", errors="replace"), size


def _safe_terminal_cwd(raw_cwd: Optional[str]) -> Path:
    working_dir = _working_dir()
    if not raw_cwd:
        return working_dir
    raw = Path(raw_cwd)
    target = raw if raw.is_absolute() else (working_dir / raw)
    resolved = target.resolve()
    if not _is_within_root(resolved, working_dir) or not resolved.exists() or not resolved.is_dir():
        raise HTTPException(400, "Invalid terminal cwd")
    return _context_visible_path(_get_client_context(), resolved)


def _default_nb_path() -> str:
    current = _notebook_path()
    return str(current) if current else "__default__"


def _load_notebook_or_400(path: str) -> dict:
    try:
        return load_notebook(path)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


def _save_notebook_or_400(path: str, data: dict) -> None:
    try:
        save_notebook(path, data)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


def _normalize_notebook_path(
    raw_path: Optional[str],
    *,
    allow_default: bool = True,
    require_exists: bool = False,
) -> str:
    """Accept only notebook-shaped paths inside the active workspace."""
    text = str(raw_path or "").strip()
    if not text:
        if allow_default:
            return _default_nb_path()
        raise HTTPException(400, "notebook_path required")
    raw = Path(text)
    working_dir = _working_dir()
    candidate = raw if raw.is_absolute() else (working_dir / raw)
    try:
        resolved = candidate.resolve()
    except Exception:
        resolved = candidate
    if resolved.suffix != ".mpynb" or not _is_within_root(resolved, working_dir):
        try:
            restored_working_dir, restored_target = _resolve_visible_notebook_context(text)
        except HTTPException as exc:
            if exc.status_code == 404:
                raise
            raise HTTPException(400, "Invalid notebook path") from exc
        _set_working_dir(restored_working_dir)
        _packages_dir()
        _set_notebook_path(restored_target)
        _sync_context_session()
        if require_exists and not restored_target.exists():
            raise HTTPException(404, "Notebook not found")
        return str(_visible_path(restored_target))
    if require_exists and not resolved.exists():
        raise HTTPException(404, "Notebook not found")
    return str(_context_visible_path(_get_client_context(), resolved))


def _notebook_cells_dir(nb_path: str | Path) -> Path:
    return _notebook_workspace_dir(str(nb_path)) / "__cells__"


def _spawn_background_task(coro, *, label: str) -> asyncio.Task:
    task = asyncio.create_task(coro)

    def _done(done_task: asyncio.Task) -> None:
        try:
            done_task.result()
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.warning("Background task failed: %s", label, exc_info=True)

    task.add_done_callback(_done)
    return task


def _prewarm_kernel(nb_path: str) -> None:
    _spawn_background_task(
        _get_or_create_kernel(nb_path),
        label=f"prewarm kernel for {nb_path}",
    )


async def _kernel_idle_sweeper() -> None:
    while True:
        await asyncio.sleep(KERNEL_IDLE_SWEEP_INTERVAL_S)
        now = time.monotonic()
        for nb_path, ks in list(kernels.items()):
            if getattr(ks, "is_running", False):
                _touch_kernel_activity(nb_path)
                continue
            last = _kernel_last_activity.get(nb_path)
            if last is None:
                _touch_kernel_activity(nb_path)
                continue
            if now - last < KERNEL_IDLE_TIMEOUT_S:
                continue
            await _drop_kernel_for_notebook(nb_path)
            affected_clients = _mark_runtime_disconnected_for_notebook(nb_path)
            await _broadcast_kernel_status(nb_path, "disconnected", target_clients=affected_clients)


def _get_notebook_runtime(nb_path: str) -> dict[str, str]:
    session = _read_session_payload()
    runtimes = session.get("notebookRuntimes") or {}
    try:
        return normalize_runtime_config(runtimes.get(nb_path))
    except Exception:
        return dict(DEFAULT_RUNTIME)


async def _drop_kernel_for_notebook(nb_path: str) -> None:
    ks = kernels.pop(nb_path, None)
    _kernel_runtime_keys.pop(nb_path, None)
    _kernel_locks.pop(nb_path, None)
    _kernel_last_activity.pop(nb_path, None)
    _sync_hashes.pop(nb_path, None)
    _nb_cell_run_hashes.pop(nb_path, None)
    _save_locks.pop(nb_path, None)
    _xnb_clear_notebook(nb_path)
    if ks is None:
        return
    try:
        await ks.shutdown()
    except Exception:
        pass


async def _shutdown_project_kernels(project_dir: Path) -> None:
    try:
        root = project_dir.resolve()
    except Exception:
        root = project_dir
    to_close = []
    for nb_path in list(kernels.keys()):
        try:
            Path(nb_path).resolve().relative_to(root)
        except Exception:
            continue
        to_close.append(nb_path)
    for nb_path in to_close:
        await _drop_kernel_for_notebook(nb_path)


def _notebook_workspace_dir(nb_path: str) -> Path:
    """Per-notebook cwd: WORKING_DIR/<rel_path_no_ext>/.

    The Project sidebar shows the notebook as a folder of the same name (the
    "exported package" view), so the kernel cwd matches that folder. Files
    uploaded into the notebook's folder structure are reachable from cells
    via natural relative paths. Falls back to WORKING_DIR if the path can't
    be resolved safely.
    """
    working_dir = _working_dir()
    try:
        p = Path(nb_path)
        rel = p.resolve().relative_to(working_dir.resolve()) if p.is_absolute() else p
        nb_dir = working_dir / rel.with_suffix("")
        if not _is_within_root(nb_dir.resolve(), working_dir):
            return working_dir
        return _context_visible_path(_get_client_context(), nb_dir)
    except (ValueError, OSError):
        return working_dir


async def _get_or_create_kernel(nb_path: str):
    """Return existing execution session or start a new one for the given notebook path."""
    _kernel_locks.setdefault(nb_path, asyncio.Lock())
    async with _kernel_locks[nb_path]:
        runtime = _get_notebook_runtime(nb_path)
        runtime_key = runtime_cache_key(runtime)
        if nb_path in kernels and _kernel_runtime_keys.get(nb_path) != runtime_key:
            await _drop_kernel_for_notebook(nb_path)
        if nb_path not in kernels:
            working_dir = _working_dir()
            nb_dir = _notebook_workspace_dir(nb_path) if nb_path != "__default__" else working_dir
            ks = build_runtime_session(runtime, str(working_dir), str(nb_dir))
            await ks.start()
            kernels[nb_path] = ks
            _kernel_runtime_keys[nb_path] = runtime_key
        _touch_kernel_activity(nb_path)
    return kernels[nb_path]


def _md5(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


def _file_hash(path: Path) -> Optional[str]:
    try:
        return hashlib.md5(path.read_bytes()).hexdigest()
    except Exception:
        return None


def _nb_pkg_name(nb_path: str) -> str:
    raw = Path(nb_path).stem
    name = re.sub(r"[^a-zA-Z0-9_]", "_", raw).strip("_") or "notebook"
    return ("_" + name) if name[0].isdigit() else name


def _nb_pkg_dir(nb_path: str) -> Optional[Path]:
    try:
        p = Path(nb_path)
        working_dir = _working_dir()
        rel_dir = p.relative_to(working_dir).parent
        d = _packages_dir() / rel_dir / _nb_pkg_name(nb_path)
        return d if d.exists() else None
    except Exception:
        return None


def _xnb_registry_bucket() -> dict[str, dict[str, str]]:
    key = str(_xnb_registry_file())
    return _xnb_registry.setdefault(key, {})


def _xnb_write():
    reg_file = _xnb_registry_file()
    payload = json.dumps(_xnb_registry_bucket())
    tmp = reg_file.with_suffix(".tmp")
    for attempt in range(5):
        try:
            tmp.write_text(payload, encoding="utf-8")
            tmp.replace(reg_file)  # atomic on same filesystem
            return
        except OSError:
            time.sleep(0.02 * (2 ** attempt))
        except Exception:
            return
    try:
        if tmp.exists():
            tmp.unlink(missing_ok=True)
    except Exception:
        pass


def _xnb_mark_executed(nb_path: str, filename: str, source: str = "", imports_source: str = ""):
    """Record that a cell was successfully executed — allows imports.

    Stores the MD5 of the *raw* source code (not the processed/synced file).
    _sync_notebook_package will invalidate this entry when the raw source
    changes, enforcing the "run before import" rule.
    """
    if nb_path == "__default__":
        return
    pkg_dir = _nb_pkg_dir(nb_path)
    if not pkg_dir:
        nb_p = Path(nb_path)
        if nb_p.exists():
            try:
                _sync_notebook_package(nb_p)
            except Exception:
                pass
            pkg_dir = _nb_pkg_dir(nb_path)
        if not pkg_dir:
            return
    # Ensure the synced file exists so the package is importable
    synced = pkg_dir / filename
    synced.parent.mkdir(parents=True, exist_ok=True)
    if not synced.exists() and source:
        try:
            content = link_runtime_imports(source, imports_source)
            content = make_importable(content)
            synced.write_text(content, encoding="utf-8")
        except Exception:
            pass
    # Store hash of raw source — NOT the processed file
    h = _md5(source) if source else None
    if h:
        _xnb_registry_bucket().setdefault(_nb_pkg_name(nb_path), {})[filename] = h
        _xnb_write()


def _xnb_clear_notebook(nb_path: str):
    """Remove all registry entries for a notebook (called on kernel restart)."""
    _xnb_registry_bucket().pop(_nb_pkg_name(nb_path), None)
    _xnb_write()
    _nb_cell_run_hashes.pop(nb_path, None)


def _find_stale_same_nb_modules(nb_path: str, executing_filename: str) -> list:
    """Return module names (without .py) of same-notebook cells that the executing
    cell (transitively) imports from, and whose source has since changed on disk —
    indicating a potential stale import."""
    if nb_path == "__default__":
        return []
    run_hashes = _nb_cell_run_hashes.get(nb_path, {})
    if not run_hashes:
        return []
    try:
        nb = load_notebook(nb_path)
    except Exception:
        return []

    cells = nb.get("cells", [])
    # Build AST dependency graph, then do a BFS from the executing cell over cell_deps.
    analyses = analyze_cells(cells)
    analysis_by_id = {a["id"]: a for a in analyses}
    cells_by_id = {c["id"]: c for c in cells}

    start_id = None
    for c in cells:
        if c.get("filename", "") == executing_filename:
            start_id = c.get("id")
            break
    if start_id is None or start_id not in analysis_by_id:
        return []

    visited: set = set()
    queue = [start_id]
    while queue:
        cur = queue.pop()
        a = analysis_by_id.get(cur)
        if not a:
            continue
        for dep in a.get("cell_deps", []):
            dep_id = dep.get("cell_id")
            if dep_id and dep_id not in visited and dep_id != start_id:
                visited.add(dep_id)
                queue.append(dep_id)

    stale = []
    for dep_id in visited:
        cell = cells_by_id.get(dep_id)
        if not cell:
            continue
        fname = cell.get("filename", "")
        if fname == "imports.py" or not fname.endswith(".py"):
            continue
        if fname in run_hashes:
            if _md5(cell.get("source", "") or "") != run_hashes[fname]:
                stale.append(fname[:-3])
    return stale


def _sync_notebook_package(nb_path: Path) -> None:
    """Materialize a notebook's cells as a Python package, mirroring directory structure.

    Root:      train.mpynb            →  __mpynb__/train/
    Nested:    data/loader.mpynb      →  __mpynb__/data/loader/
               models/cnn.mpynb       →  __mpynb__/models/cnn/

    Imports:
        from train.cell1 import x
        from data.loader.cell1 import df
        from models.cnn.cell1 import Model
    """
    try:
        nb = load_notebook(str(nb_path))
    except Exception:
        return
    cells = nb.get("cells", [])

    # Derive a valid Python identifier from the notebook stem
    raw = nb_path.stem
    pkg_name = re.sub(r"[^a-zA-Z0-9_]", "_", raw).strip("_") or "notebook"
    if pkg_name[0].isdigit():
        pkg_name = "_" + pkg_name

    working_dir = _working_dir()
    packages_dir = _packages_dir()

    # Mirror directory structure relative to the active workspace
    # e.g. data/loader.mpynb → __mpynb__/data/loader/
    rel_dir = nb_path.relative_to(working_dir).parent
    pkg_dir = packages_dir / rel_dir / pkg_name
    pkg_dir.mkdir(parents=True, exist_ok=True)

    # Ensure __init__.py exists at every intermediate namespace directory
    current_dir = packages_dir
    for part in rel_dir.parts:
        current_dir = current_dir / part
        current_dir.mkdir(exist_ok=True)
        ns_init = current_dir / "__init__.py"
        if not ns_init.exists():
            ns_init.write_text("# mpynb namespace package\n", encoding="utf-8")

    # Marker file — presence means this directory is mpynb-managed
    (pkg_dir / ".mpynb_sync").write_text(nb_path.name, encoding="utf-8")

    imports_cell = next((c for c in cells if c.get("filename") == "imports.py"), None)
    imports_source = (imports_cell or {}).get("source", "") or ""

    # __init__.py — plain package marker, no sys.path manipulation.
    # Intra-package imports use relative imports (from .cell import x) so
    # the package directory never needs to be on sys.path directly.
    init = f'"""Auto-synced from {nb_path.name} by mpynb — do not edit manually"""\n'
    (pkg_dir / "__init__.py").write_text(init, encoding="utf-8")

    # All cell module names (for rewriting bare imports to relative)
    cell_modules = set()
    for cell in cells:
        raw_fname = cell.get("filename", "")
        if not raw_fname.endswith(".py") or raw_fname == "imports.py":
            continue
        try:
            cell_modules.add(_cell_module_name(_safe_cell_archive_path(raw_fname)))
        except HTTPException:
            continue

    # Incremental sync: only rewrite files whose content changed
    nb_key = str(nb_path)
    hashes = _sync_hashes.setdefault(nb_key, {})

    current: set = set()
    registry_dirty = False
    for cell in cells:
        raw_fname = cell.get("filename", "")
        try:
            fname = _safe_cell_archive_path(raw_fname)
        except HTTPException:
            continue
        if not fname.endswith(".py"):
            continue
        source = cell.get("source", "") or ""
        current.add(fname)
        if fname == "imports.py":
            content = source
        else:
            synced = link_runtime_imports(source, imports_source)
            # Rewrite bare intra-package imports to relative so the package
            # __init__.py doesn't need to add itself to sys.path
            content = _rewrite_cell_imports(make_importable(synced), cell_modules)
        new_hash = _md5(content)
        if hashes.get(fname) != new_hash:
            target = pkg_dir / fname
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            hashes[fname] = new_hash

        # ── Invalidate registry if raw source changed since execution ──
        # The registry stores md5(raw_source) at execution time.  If the
        # user edited the cell, md5(source) will differ → remove the entry
        # so the guard blocks imports until the cell is re-run.
        pkg_reg = _xnb_registry_bucket().get(pkg_name)
        if pkg_reg and fname in pkg_reg:
            if pkg_reg[fname] != _md5(source):
                del pkg_reg[fname]
                registry_dirty = True

    # Remove .py files for cells that were deleted (search recursively)
    for f in pkg_dir.glob("*.py"):
        if f.name == "__init__.py":
            continue
        rel = f.relative_to(pkg_dir).as_posix()
        if rel not in current:
            f.unlink(missing_ok=True)
            hashes.pop(rel, None)
            # Also remove deleted cells from registry
            pkg_reg = _xnb_registry_bucket().get(pkg_name)
            if pkg_reg and rel in pkg_reg:
                del pkg_reg[rel]
                registry_dirty = True

    if registry_dirty:
        _xnb_write()


@app.on_event("startup")
async def startup():
    global _kernel_idle_task
    # Clean up any orphaned cell files from previous sessions
    for cells_dir in ROOT_DIR.rglob("__cells__"):
        if cells_dir.is_dir():
            for f in cells_dir.glob("*.py"):
                try:
                    f.unlink(missing_ok=True)
                except OSError:
                    pass
    # Always start with a clean session registry — no cells have been executed
    # in the fresh kernel, so stale entries from a previous session must not
    # allow imports to bypass the "run before import" guard.
    _xnb_registry.clear()
    _clear_all_xnb_registry_files()
    _kernel_idle_task = _spawn_background_task(_kernel_idle_sweeper(), label="kernel idle sweeper")


@app.on_event("shutdown")
async def shutdown():
    global _kernel_idle_task
    if _kernel_idle_task and not _kernel_idle_task.done():
      _kernel_idle_task.cancel()
    _kernel_idle_task = None
    for task in list(_pending_browser_close_tasks.values()):
        task.cancel()
    _pending_browser_close_tasks.clear()
    for ks in list(kernels.values()):
        try:
            await ks.shutdown()
        except Exception:
            pass
    for session_id in list(terminal_manager.sessions.keys()):
        try:
            terminal_manager.close(session_id)
        except Exception:
            pass
    # Clear session registry — no kernel means no executed cells
    _xnb_registry.clear()
    _client_contexts.clear()
    _RUNTIME_MARKER.unlink(missing_ok=True)
    if _prune_runtime_markers() == 0:
        _cleanup_workspace_temp_artifacts(force=True)
    _clear_all_xnb_registry_files()


# ── Notebook ───────────────────────────────────────────────────────────────────
def _nb_meta() -> dict:
    current_nb = _notebook_path()
    if current_nb is None:
        return {}
    path = _visible_path(current_nb)
    return {"path": str(path), "name": path.name}


@app.get("/api/auth/bootstrap")
async def auth_bootstrap(request: Request):
    if not _bootstrap_origin_allowed(request):
        raise HTTPException(403, "Origin not allowed for bootstrap")
    response = JSONResponse(
        {
            "token": SESSION_TOKEN,
            "header": SESSION_HEADER,
            "query": SESSION_QUERY,
            "server_instance_id": SERVER_INSTANCE_ID,
        }
    )
    issue_session_cookie(response)
    return response


@app.get("/api/openrouter/key/status")
async def openrouter_key_status_route():
    return openrouter_key_status()


@app.get("/api/ollama/status")
async def ollama_status(base_url: str | None = None):
    target = _normalize_ollama_base_url(base_url)
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.get(f"{target}/api/version")
    except Exception as exc:
        raise _ollama_timeout_error(target, exc) from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    payload = response.json()
    return {
        "ok": True,
        "base_url": target,
        "version": payload.get("version"),
    }


@app.get("/api/gpu/providers/{provider}/key/status")
async def gpu_provider_key_status_route(provider: str):
    if provider != "runpod":
        raise HTTPException(404, "Provider not supported yet")
    return provider_key_status("runpod")


@app.post("/api/gpu/providers/{provider}/key")
async def gpu_provider_key_save(provider: str, data: dict):
    if provider != "runpod":
        raise HTTPException(404, "Provider not supported yet")
    api_key = str((data or {}).get("api_key", "")).strip()
    if not api_key:
        raise HTTPException(400, "API key required")
    try:
        await validate_runpod_key(api_key)
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, _http_error_message(exc.response)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not validate RunPod key: {exc}") from exc
    storage = save_provider_key("runpod", api_key)
    return {"status": "ok", "storage": storage}


@app.delete("/api/gpu/providers/{provider}/key")
async def gpu_provider_key_delete(provider: str):
    if provider != "runpod":
        raise HTTPException(404, "Provider not supported yet")
    delete_provider_key("runpod")
    return {"status": "ok"}


@app.get("/api/gpu/runpod/gpu-types")
async def gpu_runpod_gpu_types():
    api_key = _gpu_provider_key_or_400("runpod")
    try:
        return {"items": await runpod_list_gpu_types(api_key)}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, _http_error_message(exc.response)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not reach RunPod: {exc}") from exc


@app.get("/api/gpu/runpod/pods")
async def gpu_runpod_pods():
    api_key = _gpu_provider_key_or_400("runpod")
    try:
        return {"items": await runpod_list_pods(api_key)}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, _http_error_message(exc.response)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not reach RunPod: {exc}") from exc


@app.post("/api/gpu/runpod/pods")
async def gpu_runpod_create_pod(data: dict):
    api_key = _gpu_provider_key_or_400("runpod")
    name = str((data or {}).get("name", "")).strip()
    gpu_type_id = str((data or {}).get("gpuTypeId", "")).strip()
    image_name = str((data or {}).get("imageName", "")).strip()
    if not name or not gpu_type_id or not image_name:
        raise HTTPException(400, "name, gpuTypeId, and imageName are required")
    try:
        pod = await runpod_create_pod(api_key, data)
        return {"status": "ok", "pod": pod}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, _http_error_message(exc.response)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not create RunPod pod: {exc}") from exc


@app.post("/api/gpu/runpod/pods/{pod_id}/stop")
async def gpu_runpod_stop_pod_route(pod_id: str):
    api_key = _gpu_provider_key_or_400("runpod")
    try:
        result = await runpod_stop_pod(api_key, pod_id)
        return {"status": "ok", "pod": result}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, _http_error_message(exc.response)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not stop RunPod pod: {exc}") from exc


@app.delete("/api/gpu/runpod/pods/{pod_id}")
async def gpu_runpod_delete_pod_route(pod_id: str):
    api_key = _gpu_provider_key_or_400("runpod")
    try:
        await runpod_delete_pod(api_key, pod_id)
        return {"status": "ok"}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, _http_error_message(exc.response)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not delete RunPod pod: {exc}") from exc


@app.post("/api/openrouter/key")
async def openrouter_key_save(data: dict):
    api_key = str((data or {}).get("api_key", "")).strip()
    if not api_key:
        raise HTTPException(400, "API key required")
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.get(
                f"{OPENROUTER_BASE}/key",
                headers=_openrouter_headers(api_key),
            )
    except Exception as exc:
        raise HTTPException(502, f"Could not validate OpenRouter key: {exc}") from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    storage = save_openrouter_key(api_key)
    return {"status": "ok", "storage": storage}


@app.delete("/api/openrouter/key")
async def openrouter_key_delete_route():
    delete_openrouter_key()
    return {"status": "ok"}


@app.get("/api/openrouter/models")
async def openrouter_models():
    api_key = _openrouter_key_or_400()
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.get(
                f"{OPENROUTER_BASE}/models",
                headers={"Authorization": f"Bearer {api_key}"},
            )
    except Exception as exc:
        raise HTTPException(502, f"Could not reach OpenRouter: {exc}") from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    return response.json()


@app.get("/api/ollama/models")
async def ollama_models(base_url: str | None = None):
    target = _normalize_ollama_base_url(base_url)
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(f"{target}/api/tags")
    except Exception as exc:
        raise _ollama_timeout_error(target, exc) from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    payload = response.json()
    models = payload.get("models") if isinstance(payload, dict) else []
    if not isinstance(models, list):
        models = []
    return {
        "data": [
            _ollama_model_entry(model)
            for model in models
            if isinstance(model, dict) and str(model.get("name") or "").strip()
        ]
    }


@app.get("/api/openrouter/key-info")
async def openrouter_key_info():
    api_key = _openrouter_key_or_400()
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{OPENROUTER_BASE}/key",
                headers=_openrouter_headers(api_key),
            )
    except Exception as exc:
        raise HTTPException(502, f"Could not reach OpenRouter: {exc}") from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    return response.json()


@app.get("/api/openrouter/credits")
async def openrouter_credits():
    api_key = _openrouter_key_or_400()
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{OPENROUTER_BASE}/credits",
                headers=_openrouter_headers(api_key),
            )
    except Exception as exc:
        raise HTTPException(502, f"Could not reach OpenRouter: {exc}") from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    return response.json()


@app.post("/api/openrouter/chat")
async def openrouter_chat(data: dict):
    api_key = _openrouter_key_or_400()
    payload = dict(data or {})
    payload["stream"] = False
    try:
        async with httpx.AsyncClient(timeout=180) as client:
            response = await client.post(
                f"{OPENROUTER_BASE}/chat/completions",
                headers=_openrouter_headers(api_key),
                json=payload,
            )
    except Exception as exc:
        raise HTTPException(502, f"Could not reach OpenRouter: {exc}") from exc
    if response.status_code >= 400:
        raise HTTPException(response.status_code, _http_error_message(response))
    return response.json()


@app.post("/api/ollama/chat")
async def ollama_chat(data: dict):
    target, payload = _ollama_chat_payload(data, stream=False)
    try:
        async with httpx.AsyncClient(timeout=240) as client:
            response = await client.post(f"{target}/api/chat", json=payload)
    except Exception as exc:
        raise _ollama_timeout_error(target, exc) from exc
    try:
        body = response.json()
    except Exception as exc:
        raise HTTPException(502, f"Ollama returned an invalid response: {exc}") from exc
    if response.status_code >= 400:
        raise HTTPException(
            response.status_code,
            _ollama_json_error_message(body, _http_error_message(response)),
        )
    content = ""
    if isinstance(body, dict):
        message = body.get("message")
        if isinstance(message, dict):
            content = str(message.get("content") or "")
    if not content.strip():
        raise HTTPException(502, "Ollama returned an empty response")
    return {"choices": [{"message": {"content": content}}]}


@app.post("/api/openrouter/chat/stream")
async def openrouter_chat_stream(data: dict):
    api_key = _openrouter_key_or_400()
    payload = dict(data or {})
    payload["stream"] = True
    client = httpx.AsyncClient(timeout=None)
    stream_ctx = client.stream(
        "POST",
        f"{OPENROUTER_BASE}/chat/completions",
        headers=_openrouter_headers(api_key),
        json=payload,
    )
    try:
        response = await stream_ctx.__aenter__()
    except Exception as exc:
        await client.aclose()
        raise HTTPException(502, f"Could not reach OpenRouter: {exc}") from exc
    if response.status_code >= 400:
        message = _http_error_message(response)
        await stream_ctx.__aexit__(None, None, None)
        await client.aclose()
        raise HTTPException(response.status_code, message)

    async def body():
        try:
            async for chunk in response.aiter_bytes():
                if chunk:
                    yield chunk
        finally:
            await stream_ctx.__aexit__(None, None, None)
            await client.aclose()

    return StreamingResponse(body(), media_type="text/event-stream")


@app.post("/api/ollama/chat/stream")
async def ollama_chat_stream(data: dict):
    target, payload = _ollama_chat_payload(data, stream=True)
    client = httpx.AsyncClient(timeout=None)
    stream_ctx = client.stream("POST", f"{target}/api/chat", json=payload)
    try:
        response = await stream_ctx.__aenter__()
    except Exception as exc:
        await client.aclose()
        raise _ollama_timeout_error(target, exc) from exc
    if response.status_code >= 400:
        message = _http_error_message(response)
        try:
            body = await response.aread()
            decoded = json.loads(body.decode("utf-8"))
            message = _ollama_json_error_message(decoded, message)
        except Exception:
            pass
        await stream_ctx.__aexit__(None, None, None)
        await client.aclose()
        raise HTTPException(response.status_code, message)

    async def body():
        pending = ""
        try:
            async for chunk in response.aiter_text():
                if not chunk:
                    continue
                pending += chunk
                lines = pending.splitlines(keepends=False)
                if pending and not pending.endswith(("\n", "\r")):
                    pending = lines.pop() if lines else pending
                else:
                    pending = ""
                for raw_line in lines:
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        item = json.loads(line)
                    except Exception:
                        continue
                    message = item.get("message") if isinstance(item, dict) else None
                    content = str((message or {}).get("content") or "") if isinstance(message, dict) else ""
                    if content:
                        delta = {"choices": [{"delta": {"content": content}}]}
                        yield f"data: {json.dumps(delta, ensure_ascii=True)}\n\n".encode("utf-8")
                    if isinstance(item, dict) and item.get("done"):
                        yield b"data: [DONE]\n\n"
                        return
            if pending.strip():
                try:
                    item = json.loads(pending.strip())
                except Exception:
                    item = None
                if isinstance(item, dict):
                    message = item.get("message")
                    content = str((message or {}).get("content") or "") if isinstance(message, dict) else ""
                    if content:
                        delta = {"choices": [{"delta": {"content": content}}]}
                        yield f"data: {json.dumps(delta, ensure_ascii=True)}\n\n".encode("utf-8")
            yield b"data: [DONE]\n\n"
        finally:
            await stream_ctx.__aexit__(None, None, None)
            await client.aclose()

    return StreamingResponse(body(), media_type="text/event-stream")


@app.get("/api/notebook")
async def get_notebook():
    current_nb = _notebook_path()
    if current_nb is None or not current_nb.exists():
        return {"cells": None}
    working_dir = _working_dir()
    project = working_dir.name if working_dir != WORKSPACE_ROOT else None
    return {**_load_notebook_or_400(str(current_nb)), **_nb_meta(), "project": project}


@app.post("/api/notebook/new")
async def new_notebook_endpoint(data: dict):
    async with _workspace_lock:
        name = data.get("name", "notebook").strip()
        overwrite = data.get("overwrite", False)
        if not name:
            name = "notebook"
        if not name.endswith(".mpynb"):
            name += ".mpynb"
        target = _safe_path(name)
        if target.exists() and not overwrite:
            return {"status": "conflict", "name": name}
        _set_notebook_path(target)
        from .notebook import new_notebook
        nb = new_notebook()
        await asyncio.to_thread(save_notebook, str(target), nb)
        await asyncio.to_thread(_sync_notebook_package, target)
        _sync_context_session()
        _prewarm_kernel(str(target))
        _clear_runtime_disconnected_for_active_client(str(target))
        return {**nb, **_nb_meta()}


@app.post("/api/notebook")
async def post_notebook(data: dict):
    client_path = data.get("_path")
    if client_path is not None:
        nb_path = Path(_normalize_notebook_path(client_path, allow_default=False, require_exists=True))
    else:
        current_nb = _notebook_path()
        if current_nb is None:
            raise HTTPException(400, "No notebook loaded")
        nb_path = current_nb
    # Strip client-side metadata before writing to disk
    save_data = {k: v for k, v in data.items() if k not in ("_path", "path", "name")}
    # Delete .py files from __cells__/ for cells that were removed
    cells_dir = _notebook_cells_dir(nb_path)
    if cells_dir.exists():
        current_filenames = {c["filename"] for c in save_data.get("cells", [])}
        for py_file in cells_dir.glob("*.py"):
            if py_file.name not in current_filenames:
                try:
                    py_file.unlink(missing_ok=True)
                except OSError:
                    pass
    nb_path_str = str(nb_path)
    _save_locks.setdefault(nb_path_str, asyncio.Lock())
    async with _save_locks[nb_path_str]:
        await asyncio.to_thread(_save_notebook_or_400, nb_path_str, save_data)
        await asyncio.to_thread(_sync_notebook_package, nb_path)
    return {"status": "ok"}


# ── Filesystem ─────────────────────────────────────────────────────────────────
@app.get("/api/fs/tree")
async def fs_tree():
    working_dir = _working_dir()
    if working_dir != WORKSPACE_ROOT:
        await asyncio.to_thread(_repair_project_notebook_pairs, working_dir)
    tree = await asyncio.to_thread(build_tree, working_dir)
    return {"tree": tree}


@app.post("/api/fs/mkdir")
async def fs_mkdir(data: dict):
    rel = str(data.get("path") or "").strip().strip("/\\")
    if not rel:
        raise HTTPException(400, "Folder name required")
    target = _safe_path(rel)
    if target.suffix.lower() == ".mpynb":
        raise HTTPException(400, "Folder name cannot end with .mpynb")
    notebook = target.with_suffix(".mpynb")
    if target.exists() or notebook.exists():
        return {"status": "conflict", "name": target.name}
    target.mkdir(parents=True, exist_ok=False)
    from .notebook import new_notebook
    nb = new_notebook()
    await asyncio.to_thread(save_notebook, str(notebook), nb)
    await asyncio.to_thread(_sync_notebook_package, notebook)
    return {"status": "ok", "notebook": str(notebook.relative_to(_working_dir())).replace("\\", "/")}


async def _delete_notebook_bundle(notebook: Path) -> None:
    raw_path_str = str(notebook)
    resolved_path_str = str(notebook.resolve())
    key_variants = {raw_path_str, resolved_path_str}
    try:
        key_variants.add(str(_context_visible_path(_get_client_context(), notebook.resolve())))
    except Exception:
        pass

    sessions = []
    for key in key_variants:
        ks = kernels.pop(key, None)
        if ks:
            sessions.append(ks)
        _kernel_locks.pop(key, None)
        _sync_hashes.pop(key, None)
        _nb_cell_run_hashes.pop(key, None)
        _save_locks.pop(key, None)
        _xnb_clear_notebook(key)
    for ks in sessions:
        try:
            await ks.shutdown()
        except Exception:
            pass
    notebook.unlink(missing_ok=True)
    companion = notebook.parent / notebook.stem
    if companion.is_dir():
        _force_rmtree(companion)
    try:
        pkg_dir = _packages_dir() / notebook.parent.relative_to(_working_dir()) / _nb_pkg_name(resolved_path_str)
        if pkg_dir.is_dir():
            _force_rmtree(pkg_dir)
    except Exception:
        pass


@app.delete("/api/fs/file")
async def fs_delete(path: str):
    import shutil
    target = _safe_path(path)
    if not target.exists() and target.with_suffix(".mpynb").is_file():
        await _delete_notebook_bundle(target.with_suffix(".mpynb"))
        return {"status": "ok"}
    if target.is_file() and target.suffix == ".mpynb":
        await _delete_notebook_bundle(target)
        return {"status": "ok"}
    if target.is_dir() and target.with_suffix(".mpynb").is_file():
        await _delete_notebook_bundle(target.with_suffix(".mpynb"))
        return {"status": "ok"}
    if target.is_file():
        if target.suffix == ".mpynb":
            nb_path_str = str(target.resolve())
            # Shut down kernel first — releases cwd lock on companion dir (critical on Windows)
            ks = kernels.pop(nb_path_str, None)
            _kernel_locks.pop(nb_path_str, None)
            _sync_hashes.pop(nb_path_str, None)
            _nb_cell_run_hashes.pop(nb_path_str, None)
            _save_locks.pop(nb_path_str, None)
            _xnb_clear_notebook(nb_path_str)
            if ks:
                try:
                    await ks.shutdown()
                except Exception:
                    pass
            target.unlink(missing_ok=True)
            # Delete companion workspace dir (kernel cwd / upload destination)
            companion = target.parent / target.stem
            if companion.is_dir():
                try:
                    shutil.rmtree(companion)
                except Exception:
                    pass
            # Delete __mpynb__ package dir for this notebook
            try:
                pkg_dir = _packages_dir() / target.parent.relative_to(_working_dir()) / _nb_pkg_name(nb_path_str)
                if pkg_dir.is_dir():
                    shutil.rmtree(pkg_dir)
            except Exception:
                pass
        else:
            target.unlink(missing_ok=True)
    elif target.is_dir():
        shutil.rmtree(target)
    return {"status": "ok"}


@app.post("/api/fs/file")
async def fs_create_file(data: dict):
    path = str(data.get("path") or "").strip().strip("/\\")
    if not path:
        raise HTTPException(400, "Filename required")
    name = Path(path).name
    if "." not in name or name in {".", ".."}:
        raise HTTPException(400, "Filename must include an extension")
    target = _safe_path(path)
    if target.exists():
        return {"status": "conflict", "name": target.name}
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("", encoding="utf-8")
    return {"status": "ok", "path": str(target.relative_to(_working_dir())).replace("\\", "/")}


@app.post("/api/fs/upload")
async def fs_upload(
    file: UploadFile = FastAPIFile(...),
    path: str = Form(""),
    overwrite: str = Form("false"),
):
    safe_name = Path(file.filename or "").name
    if not safe_name:
        raise HTTPException(400, "Filename required")
    folder = path.strip().strip("/\\")
    dest = _safe_path(f"{folder}/{safe_name}" if folder else safe_name)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and overwrite != "true":
        return {"status": "conflict", "name": safe_name}
    await _write_upload_file_limited(file, dest, MAX_UPLOAD_BYTES)
    return {"status": "ok", "path": str(dest.relative_to(_working_dir())).replace("\\", "/")}


@app.get("/api/fs/download/{path:path}")
async def fs_download(path: str):
    target = _safe_path(path)
    if not target.exists():
        raise HTTPException(404, "Not found")
    return FileResponse(str(target), filename=target.name)


@app.get("/api/fs/preview/{path:path}")
async def fs_preview(path: str):
    target = _safe_path(path)
    if not target.exists():
        raise HTTPException(404, "Not found")
    if target.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".pdf"}:
        return FileResponse(str(target))
    try:
        content, size = _read_text_file_limited(target)
        return {"content": content, "size": size}
    except HTTPException:
        raise
    except Exception:
        return {"content": None, "size": target.stat().st_size, "binary": True}


@app.get("/api/fs/read")
async def fs_read_file(path: str):
    target = _safe_path(path)
    if not target.exists():
        raise HTTPException(404, "Not found")
    try:
        content, _size = _read_text_file_limited(target)
        return {"content": content}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(400, "Cannot read binary file")


@app.post("/api/fs/write")
async def fs_write_file(data: dict):
    path = data.get("path", "")
    content = data.get("content", "")
    target = _safe_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return {"status": "ok"}


# ── Load an existing .mpynb already on disk ────────────────────────────────────
@app.post("/api/notebook/load")
async def load_notebook_by_path(data: dict):
    async with _workspace_lock:
        rel = data.get("path", "")
        target = _safe_path(rel)
        if not target.exists() or target.suffix != ".mpynb":
            raise HTTPException(404, "Notebook not found")
        _set_notebook_path(target)
        nb = await asyncio.to_thread(_load_notebook_or_400, str(target))
        # Note: imports.py is no longer force-injected on load.  Users may delete
        # it deliberately — re-injecting would undo that every time the notebook
        # is reopened.  `new_notebook()` still seeds a fresh imports.py for
        # freshly-created notebooks.
        await asyncio.to_thread(_sync_notebook_package, target)
        _sync_context_session()
        _prewarm_kernel(str(target))
        _clear_runtime_disconnected_for_active_client(str(target))
        return {**nb, **_nb_meta()}


# ── Open uploaded .mpynb file ──────────────────────────────────────────────────
@app.post("/api/notebook/open")
async def open_notebook(file: UploadFile = FastAPIFile(...)):
    async with _workspace_lock:
        safe_name = Path(file.filename or "").name
        if not safe_name or Path(safe_name).suffix != ".mpynb":
            raise HTTPException(400, "Expected .mpynb file")
        dest = _safe_path(safe_name)
        await _write_upload_file_limited(file, dest, MAX_UPLOAD_BYTES)
        _set_notebook_path(dest)
        data = await asyncio.to_thread(_load_notebook_or_400, str(dest))
        # imports.py is preserved as-is (no auto-inject) — see load path above.
        await asyncio.to_thread(_sync_notebook_package, dest)
        _sync_context_session()
        _prewarm_kernel(str(dest))
        _clear_runtime_disconnected_for_active_client(str(dest))
        return {**data, **_nb_meta()}


# ── Notebooks list ─────────────────────────────────────────────────────────────
@app.post("/api/notebook/rename")
async def rename_notebook(data: dict):
    """Rename a .mpynb file on disk and move all associated in-memory state.

    Body: {"old_path": <absolute or working-dir-relative>, "new_name": "foo" or "foo.mpynb"}
    Returns: {"status": "ok", "new_path": str, "new_name": str} or {"status": "conflict"}.
    """
    old_raw = (data.get("old_path") or "").strip()
    new_name = (data.get("new_name") or "").strip()
    if not old_raw or not new_name:
        raise HTTPException(400, "old_path and new_name are required")
    if not new_name.endswith(".mpynb"):
        new_name += ".mpynb"
    # Basic name sanity — no path separators
    if "/" in new_name or "\\" in new_name or new_name in (".mpynb", ""):
        raise HTTPException(400, "Invalid name")

    # Resolve old path (accept absolute or working-dir-relative)
    working_dir = _working_dir()
    op = Path(old_raw)
    old_path = op if op.is_absolute() else (working_dir / old_raw).resolve()
    if old_path.suffix != ".mpynb" or not old_path.exists():
        raise HTTPException(404, "Notebook not found")
    # Enforce it stays inside WORKING_DIR
    if not _is_within_root(old_path, working_dir):
        raise HTTPException(400, "Invalid path")

    new_path = old_path.with_name(new_name)
    if new_path.exists() and new_path != old_path:
        return {"status": "conflict", "name": new_name}
    if new_path == old_path:
        return {"status": "ok", "new_path": str(old_path), "new_name": old_path.name}

    old_path_str = str(old_path)
    new_path_str = str(new_path)
    old_pkg = _nb_pkg_name(old_path_str)
    new_pkg = _nb_pkg_name(new_path_str)
    old_pkg_dir = _nb_pkg_dir(old_path_str)

    # Rename the file on disk. On Windows, use os.replace which is atomic and
    # tolerates the destination existing (we already checked it doesn't).
    try:
        await asyncio.to_thread(os.replace, str(old_path), str(new_path))
    except OSError as e:
        raise HTTPException(500, f"Could not rename file: {e}")

    # Rename the __mpynb__ package dir if it exists
    if old_pkg_dir and old_pkg_dir.exists():
        new_pkg_dir = old_pkg_dir.with_name(new_pkg)
        if new_pkg_dir.exists() and new_pkg_dir != old_pkg_dir:
            raise HTTPException(409, "Target package directory already exists")
        if new_pkg_dir != old_pkg_dir:
            try:
                await asyncio.to_thread(os.replace, str(old_pkg_dir), str(new_pkg_dir))
            except OSError as e:
                raise HTTPException(500, f"Could not rename package dir: {e}")
            # Update the sync marker file inside the renamed package
            marker = new_pkg_dir / ".mpynb_sync"
            try:
                marker.write_text(new_path.name, encoding="utf-8")
            except Exception:
                pass

    # Rename the notebook workspace directory (sibling folder = kernel cwd /
    # upload destination) so the Project sidebar shows the new name.
    # On Windows a directory that is a process's cwd cannot be moved, so we
    # must switch the kernel's cwd away from the old dir BEFORE renaming it.
    old_ws_dir = _notebook_workspace_dir(old_path_str)
    new_ws_dir = _notebook_workspace_dir(new_path_str)

    # Move in-memory state keyed by old path (must happen before kernel update
    # so the kernel is found under new_path_str)
    for d in (kernels, _kernel_locks, _sync_hashes, _nb_cell_run_hashes, _save_locks):
        if old_path_str in d:
            d[new_path_str] = d.pop(old_path_str)

    # Release the kernel's cwd lock on the old workspace dir
    if new_path_str in kernels and old_ws_dir != new_ws_dir:
        ks = kernels[new_path_str]
        old_nb_dir_str = str(ks.notebook_dir)
        ks.notebook_dir = new_ws_dir
        new_ws_dir.mkdir(parents=True, exist_ok=True)
        try:
            await ks._silent(
                f"import os, sys; "
                f"os.chdir({repr(str(new_ws_dir))}); "
                f"sys.path[:] = [{repr(str(new_ws_dir))} if p == {repr(old_nb_dir_str)} else p for p in sys.path]"
            )
        except Exception:
            pass

    # Now that no process holds a cwd lock, rename the old workspace dir
    try:
        if old_ws_dir != new_ws_dir and old_ws_dir.exists():
            import shutil
            if new_ws_dir.exists():
                for item in old_ws_dir.iterdir():
                    dest = new_ws_dir / item.name
                    if not dest.exists():
                        shutil.move(str(item), str(dest))
                shutil.rmtree(old_ws_dir, ignore_errors=True)
            else:
                shutil.move(str(old_ws_dir), str(new_ws_dir))
    except Exception:
        pass

    # Move cross-notebook registry keyed by pkg name
    registry = _xnb_registry_bucket()
    if old_pkg in registry and old_pkg != new_pkg:
        registry[new_pkg] = registry.pop(old_pkg)
        _xnb_write()

    # Update global NOTEBOOK_PATH if matching
    current_nb = _notebook_path()
    if current_nb and current_nb.resolve() == old_path.resolve():
        _set_notebook_path(new_path)
        _sync_context_session()

    # Re-sync to refresh the package directory with the new name context
    try:
        await asyncio.to_thread(_sync_notebook_package, new_path)
    except Exception:
        pass

    return {"status": "ok", "new_path": new_path_str, "new_name": new_path.name}


@app.get("/api/notebooks/list")
async def list_notebooks():
    notebooks = []
    working_dir = _working_dir()
    for nb_file in sorted(working_dir.rglob("*.mpynb")):
        rel = nb_file.relative_to(working_dir)
        notebooks.append({
            "name": nb_file.name,
            "path": str(rel).replace("\\", "/"),
            "mtime": nb_file.stat().st_mtime,
        })
    return {"notebooks": notebooks}


# ── Projects ──────────────────────────────────────────────────────────────────
HIDDEN_DIRS = {"__mpynb__", "__pycache__", "__cells__", ".git", "node_modules", ".venv"}

@app.get("/api/workdir")
async def get_workdir():
    """Return the current working directory for terminal cwd."""
    return {"path": str(_working_dir())}


@app.get("/api/projects/list")
async def list_projects():
    """List all project directories under ROOT_DIR."""
    projects = []
    for d in ROOT_DIR.iterdir():
        try:
            if d.resolve() == WORKSPACE_ROOT.resolve():
                continue
        except Exception:
            pass
        if not d.is_dir() or d.name.startswith(".") or d.name in HIDDEN_DIRS:
            continue
        nb_count = len(list(d.rglob("*.mpynb")))
        py_count = len(list(d.rglob("*.py")))
        projects.append({
            "name": d.name,
            "path": str(d.relative_to(ROOT_DIR)).replace("\\", "/"),
            "mtime": d.stat().st_mtime,
            "nb_count": nb_count,
            "py_count": py_count,
        })
    projects.sort(key=lambda p: p["mtime"], reverse=True)
    return {"projects": projects}


@app.delete("/api/project")
async def delete_project(name: str):
    async with _workspace_lock:
        project_name = _validate_project_name(name)
        project_dir = _project_store_dir(project_name)
        visible_project_dir = _project_visible_dir(project_name)
        if not _is_within_root(project_dir, ROOT_DIR):
            raise HTTPException(400, "Invalid path")
        if not project_dir.exists() and not (visible_project_dir.exists() or visible_project_dir.is_symlink()):
            raise HTTPException(404, "Project not found")
        current_client = _current_client_id.get()
        if _contexts_using_project(project_name, exclude_client=current_client) > 0:
            raise HTTPException(409, "Project is open in another tab")
        if _paths_same(_working_dir(), visible_project_dir):
            await _shutdown_project_kernels(project_dir)
            _reset_workspace_to_root()
        _remove_visible_project_dir(project_name)
        if project_dir.exists():
            await asyncio.to_thread(_force_rmtree, project_dir)
        return {"status": "ok", "project": project_name}


@app.post("/api/project/close")
async def close_project():
    async with _workspace_lock:
        _reset_workspace_to_root()
        _cleanup_workspace_temp_artifacts()
        return {"status": "ok"}


@app.post("/api/project/create")
async def create_project(data: dict):
    async with _workspace_lock:
        name = data.get("name", "").strip()
        if not name:
            raise HTTPException(400, "Project name required")
        safe_name = re.sub(r"[^\w\-. ]", "_", name).strip()
        safe_name = _validate_project_name(safe_name)
        project_dir = _project_store_dir(safe_name)
        if project_dir.exists():
            return {"status": "conflict", "name": safe_name}
        _clear_active_visible_project()
        project_dir.mkdir(parents=True, exist_ok=True)
        _touch_project_access(project_dir)
        visible_project_dir = _ensure_visible_project_dir(safe_name)
        _set_working_dir(visible_project_dir)
        _packages_dir()
        nb_name = "notebook.mpynb"
        target = visible_project_dir / nb_name
        _set_notebook_path(target)
        from .notebook import new_notebook
        nb = new_notebook()
        await asyncio.to_thread(save_notebook, str(target), nb)
        await asyncio.to_thread(_sync_notebook_package, target)
        _sync_context_session()
        await _get_or_create_kernel(str(target))
        _clear_runtime_disconnected_for_active_client(str(target))
        tree = await asyncio.to_thread(build_tree, visible_project_dir)
        return {"status": "ok", "project": safe_name, "tree": tree, **nb, **_nb_meta()}


@app.post("/api/project/open")
async def open_project(data: dict):
    async with _workspace_lock:
        name = _validate_project_name(data.get("name", ""))
        project_dir = _project_store_dir(name)
        if not _is_within_root(project_dir, ROOT_DIR):
            raise HTTPException(400, "Invalid path")
        if not project_dir.is_dir():
            raise HTTPException(404, "Project not found")
        _clear_active_visible_project()
        _touch_project_access(project_dir)
        visible_project_dir = _ensure_visible_project_dir(name)
        _set_working_dir(visible_project_dir)
        _packages_dir()
        nb_files = list(visible_project_dir.rglob("*.mpynb"))
        if nb_files:
            target = nb_files[0]
            _set_notebook_path(target)
            nb = await asyncio.to_thread(_load_notebook_or_400, str(target))
        else:
            target = visible_project_dir / "notebook.mpynb"
            _set_notebook_path(target)
            from .notebook import new_notebook
            nb = new_notebook()
            await asyncio.to_thread(save_notebook, str(target), nb)
        await asyncio.to_thread(_sync_notebook_package, target)
        _sync_context_session()
        await _get_or_create_kernel(str(target))
        _clear_runtime_disconnected_for_active_client(str(target))
        tree = await asyncio.to_thread(build_tree, visible_project_dir)
        return {"status": "ok", "project": name, "tree": tree, **nb, **_nb_meta()}


@app.post("/api/project/upload")
async def upload_project(
    file: UploadFile = FastAPIFile(...),
    name: str = Form(""),
):
    raise HTTPException(404, "Project upload has been removed. Upload a .mpynb notebook instead.")
    """Upload a .zip archive and convert it into a new mpynb project.

    Top-level .py files in the archive become cells in {project}.mpynb (cells
    are flat — no nested folders). An `imports.py` at the archive root is used
    as the imports cell. Nested .py files and all non-.py files are written
    to disk preserving their relative paths."""
    async with _workspace_lock:
        if not file.filename or not file.filename.lower().endswith(".zip"):
            raise HTTPException(400, "Expected a .zip file")

        raw_name = (name or "").strip() or Path(file.filename).stem
        safe_name = re.sub(r"[^\w\-. ]", "_", raw_name).strip()
        if not safe_name:
            raise HTTPException(400, "Invalid project name")

        project_dir = _project_store_dir(safe_name)
        if project_dir.exists():
            return {"status": "conflict", "name": safe_name}

        data = await file.read()
        if len(data) > MAX_PROJECT_ZIP_BYTES:
            raise HTTPException(400, "Zip is too large")
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise HTTPException(400, "Invalid zip archive")
        infos = _validate_project_zip(zf)

        # Collect entries, skipping dirs, hidden files, and traversal attempts
        entries: list = []
        for info in infos:
            if info.is_dir():
                continue
            rel = info.filename.replace("\\", "/").lstrip("/")
            if ".." in Path(rel).parts:
                continue
            parts = Path(rel).parts
            if any(p.startswith(".") or p in HIDDEN_DIRS for p in parts):
                continue
            entries.append((rel, info))

        if not entries:
            raise HTTPException(400, "Zip is empty")
        _clear_active_visible_project()

        # Strip a common single top-level directory if present
        tops = {Path(rel).parts[0] for rel, _ in entries if len(Path(rel).parts) > 1}
        only_top = None
        if len(tops) == 1:
            t = next(iter(tops))
            if all(Path(rel).parts[0] == t for rel, _ in entries):
                only_top = t
        def _strip_top(rel: str) -> str:
            if only_top and rel.startswith(only_top + "/"):
                return rel[len(only_top) + 1 :]
            return rel

        # Create project and materialize files
        project_dir.mkdir(parents=True, exist_ok=True)
        _touch_project_access(project_dir)
        visible_project_dir = _ensure_visible_project_dir(safe_name)
        cells: list = []
        imports_source = ""
        py_entries: list = []

        for rel, info in entries:
            stripped = _strip_top(rel)
            if not stripped:
                continue
            target = (visible_project_dir / stripped).resolve()
            if not _is_within_root(target, project_dir):
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                content = zf.read(info)
            except Exception:
                continue
            # Only top-level .py files become cells. Nested .py files (and all
            # non-.py files) are written to disk and surface as uploaded files.
            if stripped.endswith(".py") and "/" not in stripped:
                py_entries.append((stripped, content))
            else:
                with open(target, "wb") as out:
                    out.write(content)

        # Build cells from top-level .py entries (filenames must be unique).
        used_names: set[str] = set()
        for stripped, content in sorted(py_entries, key=lambda x: x[0]):
            try:
                source = content.decode("utf-8")
            except UnicodeDecodeError:
                source = content.decode("utf-8", errors="replace")
            fname = validate_cell_filename(Path(stripped).name, "code")
            if fname == "imports.py":
                imports_source = source
                continue
            key = fname.casefold()
            if key in used_names:
                continue
            used_names.add(key)
            cells.append({
                "id": str(uuid.uuid4()),
                "filename": fname,
                "type": "code",
                "description": "",
                "source": source,
            })

        # Always put imports.py first
        imports_cell = {
            "id": str(uuid.uuid4()),
            "filename": "imports.py",
            "type": "code",
            "description": "Global imports and constants available in all cells",
            "source": imports_source or "# Add global imports here\n",
        }
        nb = {"cells": [imports_cell] + cells}

        _set_working_dir(visible_project_dir)
        _packages_dir()
        target = visible_project_dir / "notebook.mpynb"
        _set_notebook_path(target)
        await asyncio.to_thread(_save_notebook_or_400, str(target), nb)
        await asyncio.to_thread(_sync_notebook_package, target)
        _sync_context_session()
        await _get_or_create_kernel(str(target))
        _clear_runtime_disconnected_for_active_client(str(target))
        tree = await asyncio.to_thread(build_tree, visible_project_dir)
        return {"status": "ok", "project": safe_name, "tree": tree, **nb, **_nb_meta()}


# ── Session (open tabs) ────────────────────────────────────────────────────────
@app.get("/api/session")
async def get_session():
    payload = dict(_read_session_payload())
    payload.pop("__context__", None)
    return payload

@app.post("/api/session")
async def post_session(data: dict):
    payload = dict(data or {})
    payload["serverInstanceId"] = SERVER_INSTANCE_ID
    _write_session_payload(payload, merge=True)
    return {"status": "ok"}


@app.post("/api/session/restore-notebook")
async def restore_session_notebook(data: dict):
    async with _workspace_lock:
        _clear_active_visible_project()
        working_dir, target = _resolve_visible_notebook_context(data.get("path", ""))
        _set_working_dir(working_dir)
        _packages_dir()
        _set_notebook_path(target)
        nb = await asyncio.to_thread(_load_notebook_or_400, str(target))
        await asyncio.to_thread(_sync_notebook_package, target)
        _sync_context_session()
        project = working_dir.name if working_dir != WORKSPACE_ROOT else None
        return {**nb, **_nb_meta(), "project": project}


@app.post("/api/session/browser-closing")
async def post_session_browser_closing():
    client_id = _current_client_id.get()
    if client_id:
        _cancel_pending_browser_close(client_id)

        async def _finalize_browser_close(target_client_id: str) -> None:
            try:
                await asyncio.sleep(_BROWSER_CLOSE_GRACE_S)
                closing_project = _context_project_name(_get_client_context(target_client_id))
                await _disconnect_runtime_for_client(target_client_id)
                _client_contexts.pop(target_client_id, None)
                try:
                    _session_file(target_client_id).unlink(missing_ok=True)
                except Exception:
                    pass
                if (
                    closing_project
                    and _contexts_using_project(closing_project) == 0
                    and closing_project not in _session_projects()
                ):
                    _remove_visible_project_dir(closing_project)
                _cleanup_workspace_temp_artifacts()
            except asyncio.CancelledError:
                return
            finally:
                current = _pending_browser_close_tasks.get(target_client_id)
                if current is task:
                    _pending_browser_close_tasks.pop(target_client_id, None)

        task = asyncio.create_task(_finalize_browser_close(client_id))
        _pending_browser_close_tasks[client_id] = task
    return {"status": "ok"}


@app.get("/api/notebook/runtime")
async def get_notebook_runtime(path: str):
    nb_path = _normalize_notebook_path(path, allow_default=False, require_exists=True)
    return {"runtime": _get_notebook_runtime(nb_path)}


@app.post("/api/notebook/runtime")
async def set_notebook_runtime(data: dict):
    nb_path = _normalize_notebook_path(
        str(data.get("notebook_path") or "").strip(),
        allow_default=False,
        require_exists=True,
    )
    try:
        runtime = normalize_runtime_config(data.get("runtime"))
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc
    if runtime.get("kind") == "runpod":
        try:
            probe = await probe_remote_jupyter(runtime["base_url"])
        except httpx.HTTPStatusError as exc:
            raise HTTPException(
                502,
                f"Remote runtime is not ready at {runtime['base_url']}: {_http_error_message(exc.response)}",
            ) from exc
        except Exception as exc:
            raise HTTPException(
                502,
                f"Remote runtime is not ready at {runtime['base_url']}: {exc}",
            ) from exc
        runtime = {**runtime, "ready": "true", "kernel": probe.get("default_kernel", "")}
    payload = _read_session_payload()
    runtimes = dict(payload.get("notebookRuntimes") or {})
    runtimes[nb_path] = runtime
    payload["notebookRuntimes"] = runtimes
    _write_session_payload(payload)
    await _drop_kernel_for_notebook(nb_path)
    return {"status": "ok", "runtime": runtime}


# ── Dependency graph analysis ──────────────────────────────────────────────────
@app.post("/api/analysis/graph")
async def analysis_graph(data: dict):
    cells = data.get("cells", [])
    analyses = analyze_cells(cells)
    return {"analyses": analyses}


@app.post("/api/notebook/run-order")
async def notebook_run_order(data: dict):
    cells = data.get("cells", [])
    analyses = analyze_cells(cells)

    # Build graph: dep_id -> [cell_ids that depend on it]
    cell_ids = [a["id"] for a in analyses]
    graph = {cid: [] for cid in cell_ids}
    in_degree = {cid: 0 for cid in cell_ids}

    for a in analyses:
        for dep in a["cell_deps"]:
            dep_id = dep["cell_id"]
            if dep_id in graph:
                graph[dep_id].append(a["id"])
                in_degree[a["id"]] += 1

    # Kahn's algorithm
    queue = [cid for cid in cell_ids if in_degree[cid] == 0]
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(order) != len(cell_ids):
        # Nodes never dequeued are the cyclic ones
        cyclic_ids = [cid for cid in cell_ids if cid not in set(order)]
        id_to_filename = {a["id"]: a["filename"] for a in analyses}
        cyclic_filenames = [id_to_filename[cid] for cid in cyclic_ids if cid in id_to_filename]
        return {
            "order": [],
            "error": "cycle",
            "cyclic": cyclic_filenames,
        }
    return {"order": order}


# ── Notebook export ────────────────────────────────────────────────────────────
def _rewrite_cell_imports(source: str, cell_module_names: set) -> str:
    """Rewrite cross-cell absolute imports to relative imports for package use."""
    if not cell_module_names:
        return source
    pattern = "|".join(re.escape(n) for n in sorted(cell_module_names, key=len, reverse=True))
    lines = source.splitlines(keepends=True)
    result = []
    for line in lines:
        stripped = line.rstrip("\n\r")
        m = re.match(r"^(from\s+)(" + pattern + r")(\s+import\s+.+)$", stripped)
        if m:
            result.append(f"from .{m.group(2)}{m.group(3)}\n")
            continue
        m = re.match(r"^(import\s+)(" + pattern + r")((?:\s+as\s+\w+)?)(\s*)$", stripped)
        if m:
            module_name = m.group(2)
            alias = m.group(3) or ""
            result.append(f"from . import {module_name}{alias}\n")
            continue
        result.append(line)
    return "".join(result)


@app.get("/api/notebook/export/mpynb")
async def export_mpynb():
    current_nb = _notebook_path()
    if current_nb is None or not current_nb.exists():
        raise HTTPException(400, "No notebook loaded")
    return FileResponse(
        str(current_nb),
        filename=current_nb.name,
        media_type="application/octet-stream",
    )


def _is_empty_source(src: str) -> bool:
    """True if source has no executable code — only whitespace/comments."""
    for line in (src or "").splitlines():
        s = line.strip()
        if s and not s.startswith("#"):
            return False
    return True


_PROJECT_EXPORT_SKIP_DIRS = {
    "__pycache__",
    "__cells__",
    "__mpynb__",
    ".git",
    ".mpynb_snapshots",
    "node_modules",
    ".venv",
    "venv",
}
_PROJECT_EXPORT_SKIP_FILES = {".session_registry.json"}


def _safe_package_name(name: str, default: str = "package") -> str:
    safe = re.sub(r"[^a-zA-Z0-9_]", "_", str(name or "")).lstrip("_") or default
    if safe[0].isdigit():
        safe = "_" + safe
    return safe


def _project_dir_or_404(name: str) -> Path:
    project_name = _validate_project_name(name)
    project_dir = _project_store_dir(project_name)
    if not _is_within_root(project_dir, ROOT_DIR):
        raise HTTPException(400, "Invalid path")
    if not project_dir.is_dir():
        raise HTTPException(404, "Project not found")
    return project_dir


def _repair_project_notebook_pairs(project_dir: Path) -> None:
    for nb in project_dir.glob("*.mpynb"):
        companion = nb.with_suffix("")
        if not companion.exists():
            try:
                companion.mkdir()
            except OSError:
                pass
    for child in project_dir.iterdir():
        if child.name in _PROJECT_EXPORT_SKIP_DIRS or not child.is_dir():
            continue
        if child.with_suffix(".mpynb").is_file():
            continue
        try:
            child.rmdir()
        except OSError:
            pass


def _iter_project_notebooks(project_dir: Path):
    for src in sorted(project_dir.rglob("*.mpynb"), key=lambda p: str(p).lower()):
        rel = src.relative_to(project_dir)
        if any(part in _PROJECT_EXPORT_SKIP_DIRS for part in rel.parts[:-1]):
            continue
        yield rel, src


def _write_notebook_folder_zip(zf: zipfile.ZipFile, folder_root: str, nb_path: Path) -> None:
    zf.writestr(f"{folder_root}/", "")
    nb = _load_notebook_or_400(str(nb_path))
    cells = nb.get("cells", [])
    imports_cell = next((c for c in cells if c.get("filename") == "imports.py"), None)
    imports_source = imports_cell.get("source", "") if imports_cell else ""
    skip_imports = _is_empty_source(imports_source)
    cell_filenames: set[str] = set()

    for cell in cells:
        fname = _safe_cell_archive_path(cell.get("filename", "cell.py"))
        cell_filenames.add(fname)
        source = cell.get("source", "") or ""
        if fname == "imports.py":
            if skip_imports:
                continue
            zf.writestr(f"{folder_root}/{fname}", source)
        else:
            zf.writestr(f"{folder_root}/{fname}", inject_smart_imports(source, imports_source))

    companion = nb_path.with_suffix("")
    if not companion.is_dir():
        return
    for src in sorted(companion.rglob("*"), key=lambda p: str(p).lower()):
        if not src.is_file():
            continue
        rel = src.relative_to(companion)
        if any(part in _PROJECT_EXPORT_SKIP_DIRS for part in rel.parts[:-1]):
            continue
        if rel.name in _PROJECT_EXPORT_SKIP_FILES:
            continue
        rel_posix = rel.as_posix()
        if rel_posix in cell_filenames:
            continue
        zf.write(src, f"{folder_root}/{rel_posix}")


def _write_notebook_package_zip(
    zf: zipfile.ZipFile,
    pkg_root: str,
    cells: list[dict],
    companion_dir: Path | None = None,
) -> None:
    imports_cell = next((c for c in cells if c.get("filename") == "imports.py"), None)
    imports_source = imports_cell.get("source", "") if imports_cell else ""
    cell_modules = {
        _cell_module_name(_safe_cell_archive_path(c["filename"]))
        for c in cells
        if c.get("filename", "").endswith(".py") and c.get("filename") != "imports.py"
    }

    if not _is_empty_source(imports_source):
        zf.writestr(f"{pkg_root}/imports.py", imports_source)

    non_imports_modules = []
    cell_filenames: set[str] = set()
    for cell in cells:
        fname = _safe_cell_archive_path(cell.get("filename", "cell.py"))
        cell_filenames.add(fname)
        if fname == "imports.py" or not fname.endswith(".py"):
            continue
        source = cell.get("source", "") or ""
        module_name = _cell_module_name(fname)
        non_imports_modules.append(module_name)
        combined = inject_smart_imports(source, imports_source)
        combined = _rewrite_cell_imports(combined, cell_modules)
        zf.writestr(f"{pkg_root}/{fname}", combined)

    init_lines = [f"# {pkg_root} - auto-generated by clawss\n"]
    for mod in non_imports_modules:
        init_lines.append(f"from .{mod} import *\n")
    zf.writestr(f"{pkg_root}/__init__.py", "".join(init_lines))

    if companion_dir and companion_dir.is_dir():
        for src in sorted(companion_dir.rglob("*"), key=lambda p: str(p).lower()):
            if not src.is_file():
                continue
            rel = src.relative_to(companion_dir)
            if any(part in _PROJECT_EXPORT_SKIP_DIRS for part in rel.parts[:-1]):
                continue
            if rel.name in _PROJECT_EXPORT_SKIP_FILES:
                continue
            rel_posix = rel.as_posix()
            if rel_posix in cell_filenames:
                continue
            zf.write(src, f"{pkg_root}/{rel_posix}")


def _build_project_export_zip(project_dir: Path) -> str:
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    tmp.close()
    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel, src in _iter_project_notebooks(project_dir):
            _write_notebook_folder_zip(zf, rel.with_suffix("").as_posix(), src)
    return tmp.name


def _build_project_export_package(project_dir: Path, project_name: str) -> str:
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    tmp.close()
    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel, src in _iter_project_notebooks(project_dir):
            nb = _load_notebook_or_400(str(src))
            notebook_pkg = _safe_package_name(rel.with_suffix("").as_posix(), "notebook")
            _write_notebook_package_zip(zf, notebook_pkg, nb.get("cells", []), src.with_suffix(""))

        pyproject = (
            f'[build-system]\n'
            f'requires = ["setuptools>=61"]\n'
            f'build-backend = "setuptools.build_meta"\n\n'
            f'[project]\n'
            f'name = "{project_name}"\n'
            f'version = "0.1.0"\n'
            f'description = "Project export from clawss"\n'
            f'requires-python = ">=3.8"\n\n'
            f'[tool.setuptools]\n'
            f'include-package-data = true\n\n'
            f'[tool.setuptools.packages.find]\n'
            f'where = ["."]\n'
        )
        zf.writestr("pyproject.toml", pyproject)
    return tmp.name


@app.get("/api/project/export/zip")
async def export_project_zip(name: str = ""):
    project_dir = _project_dir_or_404(name)
    tmp_name = await asyncio.to_thread(_build_project_export_zip, project_dir)
    return FileResponse(
        tmp_name,
        filename=f"{_safe_download_filename(project_dir.name, 'project')}.zip",
        media_type="application/zip",
        background=BackgroundTask(os.unlink, tmp_name),
    )


@app.get("/api/project/export/package")
async def export_project_package(name: str = ""):
    project_dir = _project_dir_or_404(name)
    project_name = _safe_package_name(project_dir.name, "project")
    tmp_name = await asyncio.to_thread(_build_project_export_package, project_dir, project_name)
    return FileResponse(
        tmp_name,
        filename=f"{_safe_download_filename(project_dir.name, 'project')}_package.zip",
        media_type="application/zip",
        background=BackgroundTask(os.unlink, tmp_name),
    )


# ── Cell download with injected imports ────────────────────────────────────────
@app.post("/api/cell/download")
async def cell_download(data: dict):
    filename = _safe_download_filename(data.get("filename", "cell.py"))
    source = data.get("source", "")
    imports_source = data.get("imports_source", "")
    combined = inject_smart_imports(source, imports_source)
    from fastapi.responses import Response
    return Response(
        content=combined.encode("utf-8"),
        media_type="text/x-python",
        headers=_attachment_headers(filename),
    )


# ── Kernel ─────────────────────────────────────────────────────────────────────
@app.get("/api/kernel/status")
async def kernel_status(notebook_path: str = ""):
    nb_path = _normalize_notebook_path(notebook_path)
    ks = kernels.get(nb_path)
    if _client_requires_runtime_reconnect(nb_path):
        if ks:
            _clear_runtime_disconnected_for_active_client(nb_path)
        else:
            return {"status": "disconnected"}
    if not ks:
        return {"status": "idle"}
    return {"status": "busy" if ks.is_running else "idle"}


@app.post("/api/kernel/connect")
async def kernel_connect(data: dict):
    nb_path = _normalize_notebook_path(data.get("notebook_path", ""), allow_default=False)
    client_id = _current_client_id.get()
    await _drop_kernel_for_notebook(nb_path)
    await _get_or_create_kernel(nb_path)
    if client_id:
        _clear_runtime_disconnected_for_client(client_id, nb_path)
    _touch_kernel_activity(nb_path)
    return {"status": "ok"}


@app.post("/api/kernel/restart")
async def kernel_restart(data: dict = {}):
    nb_path = _normalize_notebook_path((data or {}).get("notebook_path"))
    _xnb_clear_notebook(nb_path)
    ks = kernels.get(nb_path)
    if ks:
        await ks.restart()
        _touch_kernel_activity(nb_path)
    client_id = _current_client_id.get()
    if client_id:
        _clear_runtime_disconnected_for_client(client_id, nb_path)
    return {"status": "ok"}


@app.post("/api/kernel/shutdown")
async def kernel_shutdown(data: dict):
    nb_path = _normalize_notebook_path(data.get("notebook_path", ""), allow_default=False)
    await _drop_kernel_for_notebook(nb_path)
    client_id = _current_client_id.get()
    if client_id:
        _mark_runtime_disconnected_for_client(client_id, [nb_path])
    return {"status": "ok"}


# ── Visualizer ─────────────────────────────────────────────────────────────────
def _viz_module_name(filename: str) -> str:
    """Map cell filename to the kernel module name (matches kernel.py exec wrapper)."""
    return filename[:-3] if filename.endswith(".py") else filename


def _viz_parse_marker(out: str, marker: str) -> Optional[dict]:
    for line in reversed(out.splitlines()):
        if line.startswith(marker):
            try:
                return json.loads(line[len(marker):])
            except json.JSONDecodeError:
                return None
    return None


@app.post("/api/visualize/inspect")
async def visualize_inspect(data: dict):
    """List nn.Module instances in a cell module's namespace.

    Body: {notebook_path, filename}
    Returns: {models: [{name, class, params}], torch_available: bool, kernel: bool}
    """
    nb_path = _normalize_notebook_path(data.get("notebook_path"))
    fname = data.get("filename", "")
    try:
        fname = validate_cell_filename(fname, "code")
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    ks = kernels.get(nb_path)
    if not ks:
        return {"models": [], "torch_available": False, "kernel": False}
    code = build_inspect_code(_viz_module_name(fname))
    try:
        out = await ks.run_capture(code, timeout=15)
    except Exception as e:
        return {"models": [], "torch_available": False, "kernel": True, "error": str(e)}
    parsed = _viz_parse_marker(out, "__MPYNB_VIZ_INSPECT__")
    if parsed is None:
        return {"models": [], "torch_available": False, "kernel": True,
                "error": "could not parse kernel output"}
    parsed["kernel"] = True
    return parsed


@app.post("/api/visualize/extract")
async def visualize_extract(data: dict):
    """Walk a model and return graph.json.

    Body: {notebook_path, filename, var_name, inputs: [{dtype, shape}]}
    """
    nb_path = _normalize_notebook_path(data.get("notebook_path"))
    fname = data.get("filename", "")
    var_name = data.get("var_name", "")
    inputs = data.get("inputs") or []
    try:
        fname = validate_cell_filename(fname, "code")
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if not var_name:
        raise HTTPException(400, "var_name required")
    if not isinstance(inputs, list) or not inputs:
        raise HTTPException(400, "at least one input required")
    normalized_inputs = []
    for i, spec in enumerate(inputs):
        if not isinstance(spec, dict):
            raise HTTPException(400, f"input {i + 1}: invalid spec")
        dtype = str(spec.get("dtype", "float32")).strip() or "float32"
        shape = spec.get("shape")
        if not isinstance(shape, list) or not shape:
            raise HTTPException(400, f"input {i + 1}: shape required")
        dims = []
        for dim in shape:
            try:
                dim = int(dim)
            except Exception as exc:
                raise HTTPException(400, f"input {i + 1}: shape must be integers") from exc
            if dim <= 0:
                raise HTTPException(400, f"input {i + 1}: shape must be positive")
            dims.append(dim)
        normalized = {"dtype": dtype, "shape": dims}
        name = str(spec.get("name", "")).strip()
        if name:
            normalized["name"] = name
        if spec.get("high") is not None:
            try:
                normalized["high"] = max(2, int(spec["high"]))
            except Exception as exc:
                raise HTTPException(400, f"input {i + 1}: invalid vocab high") from exc
        normalized_inputs.append(normalized)
    ks = kernels.get(nb_path)
    if not ks:
        raise HTTPException(400, "kernel not running — run the cell first")
    code = build_extract_code(_viz_module_name(fname), var_name, normalized_inputs)
    try:
        out = await ks.run_capture(code, timeout=180)
    except Exception as e:
        raise HTTPException(500, f"extraction failed: {e}")
    parsed = _viz_parse_marker(out, "__MPYNB_VIZ_EXTRACT__")
    if parsed is None:
        raise HTTPException(500, "could not parse extraction output")
    return parsed


# ── Kernel WebSocket ────────────────────────────────────────────────────────────
async def _ws_kernel_dynamic(websocket: WebSocket, client_id: Optional[str]):
    client_token = _current_client_id.set(client_id) if client_id else None
    if client_id:
        _get_client_context(client_id)
    await websocket.accept()
    _register_kernel_ws(client_id, websocket)

    exec_tasks: Dict[tuple[str, str, str], asyncio.Task] = {}
    input_futures: Dict[str, dict] = {}
    run_states: Dict[tuple[str, str, str], dict] = {}
    active_runs: Dict[tuple[str, str], tuple[str, str, str]] = {}
    notebook_runs: Dict[str, set[tuple[str, str, str]]] = {}
    notebook_generations: Dict[str, int] = {}
    interrupt_recovery_tasks: Dict[str, asyncio.Task] = {}

    def _run_key(nb_path: str, cell_id: str, execution_id: str) -> tuple[str, str, str]:
        return (nb_path, cell_id, execution_id)

    def _current_generation(nb_path: str) -> int:
        return notebook_generations.get(nb_path, 0)

    def _set_generation(nb_path: str, generation: int) -> int:
        current = notebook_generations.get(nb_path, 0)
        notebook_generations[nb_path] = max(current, generation)
        return notebook_generations[nb_path]

    def _is_current_run(state: dict) -> bool:
        return active_runs.get((state["notebook_path"], state["cell_id"])) == state["key"]

    def _finish_state(state: dict) -> None:
        if _is_current_run(state):
            active_runs.pop((state["notebook_path"], state["cell_id"]), None)
        notebook_runs.get(state["notebook_path"], set()).discard(state["key"])
        state["phase"] = "finished"

    async def _send_json(payload: dict) -> None:
        try:
            await websocket.send_text(json.dumps(payload))
        except Exception:
            pass

    async def _send_output(state: dict, output: dict) -> None:
        if not _is_current_run(state) or state["phase"] == "abandoned":
            return
        if output.get("type") == "error" and output.get("ename") == "KeyboardInterrupt":
            state["keyboard_interrupt_sent"] = True
            if state["phase"] == "cancelling":
                state["phase"] = "finalizing"
        await _send_json(
            {
                "type": "output",
                "cell_id": state["cell_id"],
                "execution_id": state["execution_id"],
                "generation": state["generation"],
                "output": output,
            }
        )

    async def _send_status(state: dict, status: str) -> None:
        if not _is_current_run(state) or state["phase"] == "abandoned":
            return
        await _send_json(
            {
                "type": "cell_status",
                "cell_id": state["cell_id"],
                "execution_id": state["execution_id"],
                "generation": state["generation"],
                "status": status,
                "notebook_path": state["notebook_path"],
            }
        )

    async def _send_stats(state: dict, result: dict) -> None:
        if not _is_current_run(state) or state["phase"] == "abandoned":
            return
        await _send_json(
            {
                "type": "execution_stats",
                "cell_id": state["cell_id"],
                "execution_id": state["execution_id"],
                "generation": state["generation"],
                "count": result["execution_count"],
                "time_ms": result["time_ms"],
                "memory_delta_mb": result["memory_delta_mb"],
            }
        )

    async def _finalize_interrupted_run(state: dict, result: Optional[dict] = None) -> None:
        if state["phase"] in {"finished", "abandoned"} or not _is_current_run(state):
            return
        if not state["keyboard_interrupt_sent"]:
            await _send_output(
                state,
                {
                    "type": "error",
                    "ename": "KeyboardInterrupt",
                    "evalue": "Execution interrupted",
                    "traceback": ["KeyboardInterrupt: Execution interrupted"],
                },
            )
        if result is not None:
            await _send_stats(state, result)
        await _send_status(state, "error")
        _finish_state(state)

    async def _finalize_result(state: dict, result: dict, filename: str, source: str, imports_source: Optional[str]) -> None:
        if state["phase"] in {"finished", "abandoned"}:
            return
        if state["phase"] in {"cancelling", "finalizing"}:
            if result["status"] != "error" or not state["keyboard_interrupt_sent"]:
                await _finalize_interrupted_run(state, result)
                return
            await _send_stats(state, result)
            await _send_status(state, "error")
            _finish_state(state)
            return

        if not _is_current_run(state):
            state["phase"] = "abandoned"
            _finish_state(state)
            return

        if result["status"] == "success":
            _nb_cell_run_hashes.setdefault(state["notebook_path"], {})[filename] = _md5(source)
            _xnb_mark_executed(state["notebook_path"], filename, source, imports_source or "")

        await _send_stats(state, result)
        await _send_status(state, result["status"])
        _finish_state(state)

    async def _ensure_interrupt_recovery(nb_path: str, target_generation: int, expected_kernel) -> None:
        await asyncio.sleep(INTERRUPT_REPLACE_GRACE_S)
        if _current_generation(nb_path) != target_generation:
            return

        current_kernel = kernels.get(nb_path)
        for key in list(notebook_runs.get(nb_path, set())):
            state = run_states.get(key)
            if not state or state["generation"] >= target_generation:
                continue
            if _is_current_run(state) and state["phase"] in {"active", "cancelling", "finalizing"}:
                await _finalize_interrupted_run(state)
            else:
                state["phase"] = "abandoned"
                _finish_state(state)

        if current_kernel is not expected_kernel or not current_kernel or not getattr(current_kernel, "is_running", False):
            return

        await _send_json(
            {
                "type": "kernel_status",
                "status": "restarting",
                "notebook_path": nb_path,
                "reason": "interrupt_recovery",
            }
        )
        try:
            await _drop_kernel_for_notebook(nb_path)
            await _get_or_create_kernel(nb_path)
            await _send_json({"type": "kernel_status", "status": "idle", "notebook_path": nb_path})
        except Exception:
            await _send_json({"type": "kernel_status", "status": "dead", "notebook_path": nb_path})

    async def run_cell(state: dict, source: str, imports_source: Optional[str]):
        key = state["key"]
        cell_id = state["cell_id"]
        nb_path = state["notebook_path"]
        filename = state["filename"]

        try:
            if (
                state["phase"] != "active"
                or state["generation"] < _current_generation(nb_path)
                or not _is_current_run(state)
            ):
                state["phase"] = "abandoned"
                _finish_state(state)
                return

            await _send_status(state, "running")

            try:
                if state.get("force_fresh_kernel"):
                    await _drop_kernel_for_notebook(nb_path)
                ks = await _get_or_create_kernel(nb_path)
                if state.get("force_fresh_kernel") and client_id:
                    _clear_runtime_disconnected_for_client(client_id, nb_path)
                    state["force_fresh_kernel"] = False
            except Exception:
                await _send_output(
                    state,
                    {
                        "type": "error",
                        "ename": "KernelStartError",
                        "evalue": "Kernel could not start",
                        "traceback": ["KernelStartError: Kernel could not start"],
                    },
                )
                await _send_status(state, "error")
                _finish_state(state)
                return

            if (
                state["phase"] != "active"
                or state["generation"] < _current_generation(nb_path)
                or not _is_current_run(state)
            ):
                state["phase"] = "abandoned"
                _finish_state(state)
                return

            async def send_output(output):
                await _send_output(state, output)

            async def request_input(payload: dict) -> str:
                if not _is_current_run(state) or state["phase"] != "active":
                    return ""
                request_id = uuid.uuid4().hex
                fut: asyncio.Future[str] = asyncio.get_running_loop().create_future()
                input_futures[request_id] = {"future": fut, "key": key}
                try:
                    await _send_json(
                        {
                            "type": "input_request",
                            "cell_id": cell_id,
                            "execution_id": state["execution_id"],
                            "generation": state["generation"],
                            "request_id": request_id,
                            "prompt": payload.get("prompt", ""),
                            "password": bool(payload.get("password", False)),
                        }
                    )
                    return await fut
                finally:
                    input_futures.pop(request_id, None)

            stale = await asyncio.to_thread(_find_stale_same_nb_modules, nb_path, filename)
            if stale:
                noun = "it" if len(stale) == 1 else "them"
                names = ", ".join(f"{m}.py" for m in stale)
                await send_output(
                    {
                        "type": "stream",
                        "name": "stderr",
                        "text": f"[mpynb] Warning: {names} changed since last run â€” re-run {noun} first.\n",
                    }
                )

            try:
                result = await ks.execute(
                    cell_id, filename, source, imports_source, send_output, request_input,
                )
            except asyncio.CancelledError:
                if state["phase"] == "abandoned":
                    _finish_state(state)
                return
            except Exception:
                result = {
                    "status": "error",
                    "execution_count": 0,
                    "time_ms": 0,
                    "memory_delta_mb": 0,
                }

            await _finalize_result(state, result, filename, source, imports_source)
        finally:
            exec_tasks.pop(key, None)
            run_states.pop(key, None)

    try:
        while True:
            raw = await websocket.receive_text()
            msg = json.loads(raw)

            if msg["type"] == "execute":
                cell_id = msg["cell_id"]
                fname = msg.get("filename", "")
                execution_id = str(msg.get("execution_id", "")).strip()
                try:
                    generation = int(msg.get("generation", 0))
                except Exception:
                    generation = 0
                try:
                    fname = validate_cell_filename(fname, "code")
                except ValueError as exc:
                    await _send_json({
                        "type": "output",
                        "cell_id": cell_id,
                        "execution_id": execution_id,
                        "generation": generation,
                        "output": {
                            "type": "error",
                            "ename": "ValueError",
                            "evalue": str(exc),
                            "traceback": [f"ValueError: {exc}"],
                        },
                    })
                    await _send_json({
                        "type": "cell_status",
                        "cell_id": cell_id,
                        "execution_id": execution_id,
                        "generation": generation,
                        "status": "error",
                    })
                    continue
                try:
                    nb_path = _normalize_notebook_path(msg.get("notebook_path"))
                except HTTPException as exc:
                    await _send_json({
                        "type": "output",
                        "cell_id": cell_id,
                        "execution_id": execution_id,
                        "generation": generation,
                        "output": {
                            "type": "error",
                            "ename": "ValueError",
                            "evalue": exc.detail,
                            "traceback": [f"ValueError: {exc.detail}"],
                        },
                    })
                    await _send_json({
                        "type": "cell_status",
                        "cell_id": cell_id,
                        "execution_id": execution_id,
                        "generation": generation,
                        "status": "error",
                    })
                    continue
                if not execution_id:
                    continue
                current_generation = _set_generation(nb_path, generation)
                if generation < current_generation:
                    continue
                prior_key = active_runs.get((nb_path, cell_id))
                if prior_key:
                    prior_state = run_states.get(prior_key)
                    if prior_state:
                        prior_state["phase"] = "abandoned"
                    prior_task = exec_tasks.get(prior_key)
                    if prior_task and not prior_task.done():
                        prior_task.cancel()
                key = _run_key(nb_path, cell_id, execution_id)
                state = {
                    "key": key,
                    "cell_id": cell_id,
                    "execution_id": execution_id,
                    "generation": generation,
                    "notebook_path": nb_path,
                    "filename": fname,
                    "phase": "active",
                    "keyboard_interrupt_sent": False,
                    "force_fresh_kernel": bool(msg.get("force_fresh_kernel"))
                    or bool(client_id and _client_requires_runtime_reconnect(nb_path, client_id)),
                }
                run_states[key] = state
                notebook_runs.setdefault(nb_path, set()).add(key)
                active_runs[(nb_path, cell_id)] = key
                task = asyncio.create_task(run_cell(state, msg["source"], msg.get("imports_source")))
                exec_tasks[key] = task

            elif msg["type"] == "interrupt":
                try:
                    nb_path = _normalize_notebook_path(msg.get("notebook_path"))
                except HTTPException:
                    continue
                try:
                    next_generation = int(msg.get("next_generation", _current_generation(nb_path) + 1))
                except Exception:
                    next_generation = _current_generation(nb_path) + 1
                if next_generation <= _current_generation(nb_path):
                    next_generation = _current_generation(nb_path) + 1
                _set_generation(nb_path, next_generation)
                for key in list(notebook_runs.get(nb_path, set())):
                    state = run_states.get(key)
                    if not state or state["phase"] in {"finished", "abandoned"}:
                        continue
                    if state["generation"] < next_generation:
                        state["phase"] = "cancelling"
                ks = kernels.get(nb_path)
                if ks:
                    try:
                        await ks.interrupt()
                        _touch_kernel_activity(nb_path)
                    except Exception:
                        pass
                    prior_recovery = interrupt_recovery_tasks.get(nb_path)
                    if prior_recovery and not prior_recovery.done():
                        prior_recovery.cancel()
                    interrupt_recovery_tasks[nb_path] = asyncio.create_task(
                        _ensure_interrupt_recovery(nb_path, next_generation, ks)
                    )
                else:
                    for key in list(notebook_runs.get(nb_path, set())):
                        state = run_states.get(key)
                        if not state or state["generation"] >= next_generation:
                            continue
                        if _is_current_run(state):
                            await _finalize_interrupted_run(state)
                        else:
                            state["phase"] = "abandoned"
                            _finish_state(state)

            elif msg["type"] == "restart":
                try:
                    nb_path = _normalize_notebook_path(msg.get("notebook_path"))
                except HTTPException as exc:
                    await _send_json({"type": "kernel_status", "status": "dead", "error": exc.detail})
                    continue
                _xnb_clear_notebook(nb_path)
                try:
                    await _send_json(
                        {
                            "type": "kernel_status",
                            "status": "restarting",
                            "notebook_path": nb_path,
                            "reason": "manual",
                        }
                    )
                    ks = await _get_or_create_kernel(nb_path)
                    await ks.restart()
                    _touch_kernel_activity(nb_path)
                    if client_id:
                        _clear_runtime_disconnected_for_client(client_id, nb_path)
                    await _send_json({"type": "kernel_status", "status": "idle", "notebook_path": nb_path})
                except Exception:
                    await _send_json({"type": "kernel_status", "status": "dead", "notebook_path": nb_path})

            elif msg["type"] == "input_reply":
                request_id = str(msg.get("request_id", "")).strip()
                entry = input_futures.get(request_id)
                if not entry:
                    continue
                fut = entry["future"]
                state = run_states.get(entry["key"])
                if fut and not fut.done() and state and _is_current_run(state) and state["phase"] == "active":
                    _touch_kernel_activity(state["notebook_path"])
                    fut.set_result(str(msg.get("value", "")))

    except WebSocketDisconnect:
        pass
    finally:
        _unregister_kernel_ws(client_id, websocket)
        for task in list(exec_tasks.values()):
            if not task.done():
                task.cancel()
        for task in list(interrupt_recovery_tasks.values()):
            if not task.done():
                task.cancel()
        for fut in list(input_futures.values()):
            future = fut["future"]
            if not future.done():
                future.cancel()
        if client_token is not None:
            _current_client_id.reset(client_token)
    return
    """

@app.websocket("/ws/kernel")
async def ws_kernel(websocket: WebSocket):
    if not await _guard_websocket_origin(websocket):
        return
    try:
        client_id = _websocket_client_id(websocket)
    except HTTPException:
        await websocket.close(code=4400, reason="Invalid client id")
        return
    return await _ws_kernel_dynamic(websocket, client_id)
    """
    client_token = _current_client_id.set(client_id) if client_id else None
    if client_id:
        _get_client_context(client_id)
    await websocket.accept()
    # Track in-flight cell tasks: cell_id -> Task
    exec_tasks: Dict[str, asyncio.Task] = {}
    input_futures: Dict[str, asyncio.Future[str]] = {}

    async def run_cell(cell_id: str, nb_path: str, filename: str, source: str, imports_source):
        try:
            await websocket.send_text(
                json.dumps({"type": "cell_status", "cell_id": cell_id, "status": "running", "notebook_path": nb_path})
            )
        except Exception:
            exec_tasks.pop(cell_id, None)
            return

        try:
            ks = await _get_or_create_kernel(nb_path)
        except Exception:
            try:
                await websocket.send_text(
                    json.dumps({
                        "type": "output",
                        "cell_id": cell_id,
                        "output": {
                            "type": "error",
                            "ename": "KernelStartError",
                            "evalue": "Kernel could not start",
                            "traceback": ["KernelStartError: Kernel could not start"],
                        },
                    })
                )
                await websocket.send_text(
                    json.dumps({"type": "cell_status", "cell_id": cell_id, "status": "error"})
                )
            except Exception:
                pass
            exec_tasks.pop(cell_id, None)
            return

        async def send_output(output, _cid=cell_id):
            try:
                await websocket.send_text(
                    json.dumps({"type": "output", "cell_id": _cid, "output": output})
                )
            except Exception:
                pass

        async def request_input(payload: dict, _cid=cell_id) -> str:
            request_id = uuid.uuid4().hex
            fut: asyncio.Future[str] = asyncio.get_running_loop().create_future()
            input_futures[request_id] = fut
            try:
                await websocket.send_text(
                    json.dumps(
                        {
                            "type": "input_request",
                            "cell_id": _cid,
                            "request_id": request_id,
                            "prompt": payload.get("prompt", ""),
                            "password": bool(payload.get("password", False)),
                        }
                    )
                )
                return await fut
            finally:
                input_futures.pop(request_id, None)

        # Warn if any same-notebook cells changed since they were last run
        stale = await asyncio.to_thread(_find_stale_same_nb_modules, nb_path, filename)
        if stale:
            noun = "it" if len(stale) == 1 else "them"
            names = ", ".join(f"{m}.py" for m in stale)
            await send_output({
                "type": "stream", "name": "stderr",
                "text": f"[mpynb] Warning: {names} changed since last run — re-run {noun} first.\n",
            })

        try:
            result = await ks.execute(
                cell_id, filename, source, imports_source, send_output, request_input,
            )
        except asyncio.CancelledError:
            exec_tasks.pop(cell_id, None)
            return
        except Exception:
            result = {
                "status": "error",
                "execution_count": 0,
                "time_ms": 0,
                "memory_delta_mb": 0,
            }

        # Register in cross-notebook session registry so other notebooks can import this cell.
        # Also record source hash for same-notebook staleness detection.
        if result["status"] == "success":
            _nb_cell_run_hashes.setdefault(nb_path, {})[filename] = _md5(source)
            _xnb_mark_executed(nb_path, filename, source, imports_source or "")

        try:
            await websocket.send_text(
                json.dumps({"type": "cell_status", "cell_id": cell_id, "status": result["status"], "notebook_path": nb_path})
            )
            await websocket.send_text(
                json.dumps({
                    "type": "execution_stats",
                    "cell_id": cell_id,
                    "count": result["execution_count"],
                    "time_ms": result["time_ms"],
                    "memory_delta_mb": result["memory_delta_mb"],
                })
            )
        except Exception:
            pass
        finally:
            exec_tasks.pop(cell_id, None)

    try:
        while True:
            raw = await websocket.receive_text()
            msg = json.loads(raw)

            if msg["type"] == "execute":
                cell_id = msg["cell_id"]
                fname = msg.get("filename", "")
                try:
                    fname = validate_cell_filename(fname, "code")
                except ValueError as exc:
                    await websocket.send_text(json.dumps({
                        "type": "output", "cell_id": cell_id,
                        "output": {"type": "error", "ename": "ValueError",
                                   "evalue": str(exc),
                                   "traceback": [f"ValueError: {exc}"]},
                    }))
                    await websocket.send_text(json.dumps({
                        "type": "cell_status", "cell_id": cell_id, "status": "error",
                    }))
                    continue
                try:
                    nb_path = _normalize_notebook_path(msg.get("notebook_path"))
                except HTTPException as exc:
                    await websocket.send_text(json.dumps({
                        "type": "output", "cell_id": cell_id,
                        "output": {"type": "error", "ename": "ValueError",
                                   "evalue": exc.detail,
                                   "traceback": [f"ValueError: {exc.detail}"]},
                    }))
                    await websocket.send_text(json.dumps({
                        "type": "cell_status", "cell_id": cell_id, "status": "error",
                    }))
                    continue
                # Cancel any prior task for this cell
                prior = exec_tasks.get(cell_id)
                if prior and not prior.done():
                    prior.cancel()
                task = asyncio.create_task(
                    run_cell(cell_id, nb_path, fname, msg["source"], msg.get("imports_source"))
                )
                exec_tasks[cell_id] = task

            elif msg["type"] == "interrupt":
                try:
                    nb_path = _normalize_notebook_path(msg.get("notebook_path"))
                except HTTPException:
                    continue
                ks = kernels.get(nb_path)
                if ks:
                    try:
                        await ks.interrupt()
                    except Exception:
                        pass

            elif msg["type"] == "restart":
                try:
                    nb_path = _normalize_notebook_path(msg.get("notebook_path"))
                except HTTPException as exc:
                    await websocket.send_text(
                        json.dumps({"type": "kernel_status", "status": "dead", "error": exc.detail})
                    )
                    continue
                # Clear session registry for this notebook — all cells need to be re-run
                _xnb_clear_notebook(nb_path)
                try:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "kernel_status",
                                "status": "restarting",
                                "notebook_path": nb_path,
                                "reason": "manual",
                            }
                        )
                    )
                    ks = await _get_or_create_kernel(nb_path)
                    await ks.restart()
                    await websocket.send_text(
                        json.dumps({"type": "kernel_status", "status": "idle", "notebook_path": nb_path})
                    )
                except Exception:
                    await websocket.send_text(
                        json.dumps({"type": "kernel_status", "status": "dead"})
                    )

            elif msg["type"] == "input_reply":
                request_id = str(msg.get("request_id", "")).strip()
                fut = input_futures.get(request_id)
                if fut and not fut.done():
                    fut.set_result(str(msg.get("value", "")))

    except WebSocketDisconnect:
        pass
    finally:
        for task in list(exec_tasks.values()):
            if not task.done():
                task.cancel()
        for fut in list(input_futures.values()):
            if not fut.done():
                fut.cancel()
        if client_token is not None:
            _current_client_id.reset(client_token)


# ── Terminal WebSocket ──────────────────────────────────────────────────────────
@app.websocket("/ws/kernel")
async def ws_kernel(websocket: WebSocket):
    if not await _guard_websocket_origin(websocket):
        return
    try:
        client_id = _websocket_client_id(websocket)
    except HTTPException:
        await websocket.close(code=4400, reason="Invalid client id")
        return
    return await _ws_kernel_dynamic(websocket, client_id)


@app.websocket("/ws/terminal/{session_id}")
async def ws_terminal(websocket: WebSocket, session_id: str):
    if not await _guard_websocket_origin(websocket):
        return
    try:
        client_id = _websocket_client_id(websocket)
    except HTTPException:
        await websocket.close(code=4400, reason="Invalid client id")
        return
    client_token = _current_client_id.set(client_id) if client_id else None
    if client_id:
        _get_client_context(client_id)
    try:
        cwd = str(_safe_terminal_cwd(websocket.query_params.get("cwd", str(_working_dir()))))
    except HTTPException:
        await websocket.close(code=4400, reason="Invalid cwd")
        if client_token is not None:
            _current_client_id.reset(client_token)
        return
    await websocket.accept()
    session = await terminal_manager.create(session_id, cwd)

    # Read loop: PTY → WebSocket (sends ALL output including initial PS prompt)
    async def read_loop():
        while True:
            data = await session.read()
            if data is not None:
                try:
                    await websocket.send_bytes(data)
                except Exception:
                    break
            else:
                await asyncio.sleep(0.05)

    read_task = asyncio.create_task(read_loop())
    # Setup commands after 500ms delay — Clear-Host wipes initial noise on frontend
    setup_task = asyncio.create_task(session.send_setup_after_delay())

    # Write loop: WebSocket → PTY
    try:
        while True:
            msg = await websocket.receive()
            if msg["type"] == "websocket.disconnect":
                break
            raw = msg.get("bytes") or msg.get("text", "").encode("utf-8")
            try:
                ctrl = json.loads(raw)
                if ctrl.get("type") == "resize":
                    session.resize(ctrl["cols"], ctrl["rows"])
                    continue
            except (json.JSONDecodeError, KeyError):
                pass
            await session.write(raw)
    except WebSocketDisconnect:
        pass
    finally:
        read_task.cancel()
        setup_task.cancel()
        terminal_manager.close(session_id)
        if client_token is not None:
            _current_client_id.reset(client_token)


# ── Filesystem watch WebSocket ──────────────────────────────────────────────────
@app.websocket("/ws/fs")
async def ws_fs(websocket: WebSocket):
    if not await _guard_websocket_origin(websocket):
        return
    try:
        client_id = _websocket_client_id(websocket)
    except HTTPException:
        await websocket.close(code=4400, reason="Invalid client id")
        return
    client_token = _current_client_id.set(client_id) if client_id else None
    if client_id:
        _get_client_context(client_id)
    await websocket.accept()
    try:
        from watchfiles import awatch
        watched_root = _working_dir()
        async for _ in awatch(str(watched_root)):
            tree = await asyncio.to_thread(build_tree, watched_root)
            await websocket.send_text(json.dumps({"type": "fs_update", "tree": tree}))
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        if client_token is not None:
            _current_client_id.reset(client_token)


# ── Serve built frontend ────────────────────────────────────────────────────────
_dist = Path(__file__).parent / "static"
if _dist.exists():
    _dist = _dist.resolve()
    _assets = _dist / "assets"
    _index = _dist / "index.html"

    if _assets.exists():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="static-assets")

    @app.get("/", include_in_schema=False)
    async def spa_index():
        return FileResponse(str(_index))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str):
        requested = (_dist / full_path).resolve()
        if full_path and _is_within_root(requested, _dist) and requested.is_file():
            return FileResponse(str(requested))
        return FileResponse(str(_index))


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8765, reload=False)
