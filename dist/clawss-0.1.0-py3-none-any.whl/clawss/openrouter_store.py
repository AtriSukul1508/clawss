import json
import os
import stat
from pathlib import Path
from typing import Literal, Tuple

STORAGE_KIND = Literal["keyring", "file", "env", "none"]
SERVICE_NAME = "clawss"
USERNAME = "openrouter"
ENV_VAR = "OPENROUTER_API_KEY"


def _config_dir() -> Path:
    return Path.home() / ".clawss"


def _config_file() -> Path:
    return _config_dir() / "config.json"


def _read_config() -> dict:
    path = _config_file()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_config(data: dict) -> None:
    path = _config_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=True, indent=2), encoding="utf-8")
    if os.name != "nt":
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    try:
        tmp.replace(path)
    except PermissionError:
        path.write_text(json.dumps(data, ensure_ascii=True, indent=2), encoding="utf-8")
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
    if os.name != "nt":
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def _get_keyring():
    try:
        import keyring  # type: ignore
        return keyring
    except Exception:
        return None


def save_openrouter_key(api_key: str) -> STORAGE_KIND:
    api_key = (api_key or "").strip()
    if not api_key:
        raise ValueError("API key required")
    keyring = _get_keyring()
    if keyring is not None:
        try:
            keyring.set_password(SERVICE_NAME, USERNAME, api_key)
            return "keyring"
        except Exception:
            pass
    data = _read_config()
    data["openrouter_api_key"] = api_key
    _write_config(data)
    return "file"


def get_openrouter_key() -> Tuple[str | None, STORAGE_KIND]:
    env_key = (os.getenv(ENV_VAR) or "").strip()
    if env_key:
        return env_key, "env"
    keyring = _get_keyring()
    if keyring is not None:
        try:
            stored = keyring.get_password(SERVICE_NAME, USERNAME)
            if stored:
                return stored, "keyring"
        except Exception:
            pass
    stored = (_read_config().get("openrouter_api_key") or "").strip()
    if stored:
        return stored, "file"
    return None, "none"


def delete_openrouter_key() -> None:
    keyring = _get_keyring()
    if keyring is not None:
        try:
            keyring.delete_password(SERVICE_NAME, USERNAME)
        except Exception:
            pass
    data = _read_config()
    if "openrouter_api_key" in data:
        del data["openrouter_api_key"]
        _write_config(data)


def openrouter_key_status() -> dict:
    key, storage = get_openrouter_key()
    return {
        "has_key": bool(key),
        "storage": storage,
        "from_env": storage == "env",
    }
