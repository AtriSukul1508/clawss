from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import time
import uuid
from pathlib import Path
from typing import Callable, List, Optional
from urllib.parse import parse_qsl, quote, urlencode, urlparse, urlunparse

import httpx
import websockets

from .kernel import ANSI_ESCAPE, CELLS_DIR, MAX_STREAM_BYTES, KernelSession

REMOTE_SYNC_SKIPPED_DIRS = {
    "__pycache__",
    CELLS_DIR,
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "node_modules",
}
REMOTE_SYNC_SKIPPED_FILES = {
    ".mpynb_session.json",
    ".env",
    ".env.local",
    ".env.development",
    ".env.production",
    ".env.test",
}
REMOTE_SYNC_SKIPPED_SUFFIXES = {
    ".pem",
    ".key",
    ".crt",
    ".cer",
    ".der",
    ".p12",
    ".pfx",
    ".kdbx",
}


def _url_with_path(base_url: str, path: str) -> str:
    parsed = urlparse(base_url)
    base_path = parsed.path.rstrip("/")
    merged = f"{base_path}{path}"
    return urlunparse(parsed._replace(path=merged))


def _ws_url(base_url: str, path: str, extra_query: Optional[dict[str, str]] = None) -> str:
    parsed = urlparse(_url_with_path(base_url, path))
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if extra_query:
        query.update(extra_query)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse(parsed._replace(scheme=scheme, query=urlencode(query)))


def _should_sync_remote_path(path: Path, working_dir: Path) -> bool:
    try:
        rel = path.relative_to(working_dir)
    except Exception:
        return False
    if any(part in REMOTE_SYNC_SKIPPED_DIRS for part in rel.parts[:-1]):
        return False
    if any(part.startswith(".") for part in rel.parts):
        return False
    name = path.name
    if name in REMOTE_SYNC_SKIPPED_FILES or name.startswith(".env."):
        return False
    if path.suffix.lower() in REMOTE_SYNC_SKIPPED_SUFFIXES:
        return False
    return True


async def probe_remote_jupyter(base_url: str) -> dict:
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        api_res = await client.get(_url_with_path(base_url, "/api"))
        api_res.raise_for_status()
        kernelspecs_res = await client.get(_url_with_path(base_url, "/api/kernelspecs"))
        kernelspecs_res.raise_for_status()
    try:
        api_payload = api_res.json()
        kernelspecs_payload = kernelspecs_res.json()
    except Exception as exc:
        raise RuntimeError("Remote runtime did not return valid Jupyter JSON") from exc
    if not isinstance(api_payload, dict) or not isinstance(kernelspecs_payload, dict):
        raise RuntimeError("Remote runtime returned an unexpected Jupyter response")
    if "kernelspecs" not in kernelspecs_payload:
        raise RuntimeError("Remote runtime did not expose Jupyter kernelspecs")
    return {
        "api": str(api_payload.get("version") or api_payload.get("message") or "ok"),
        "default_kernel": str(kernelspecs_payload.get("default") or ""),
    }


class RemoteJupyterSession(KernelSession):
    REMOTE_ROOT = "/workspace/clawss_project"

    def __init__(self, working_dir: str, notebook_dir: Optional[str], base_url: str):
        super().__init__(working_dir, notebook_dir)
        self.base_url = base_url.rstrip("/")
        self.remote_root = self.REMOTE_ROOT
        self.remote_notebook_dir = self._remote_notebook_dir()
        self.remote_cells_dir = f"{self.remote_root}/{CELLS_DIR}"
        self.remote_mpynb_dir = f"{self.remote_root}/__mpynb__"
        self.kernel_id: Optional[str] = None
        self.http: Optional[httpx.AsyncClient] = None
        self._synced_hashes: dict[str, str] = {}

    def _remote_notebook_dir(self) -> str:
        rel = "."
        try:
            rel = str(self.notebook_dir.resolve().relative_to(self.working_dir.resolve())).replace("\\", "/")
        except Exception:
            rel = "."
        return self.remote_root if rel in {"", "."} else f"{self.remote_root}/{rel}"

    async def start(self):
        self.http = httpx.AsyncClient(timeout=60, follow_redirects=True)
        await self._ensure_kernel()
        await self._sync_project()
        await self._silent(self._remote_setup_code())
        await self._silent(self._remote_virtual_cwd_setup())
        await self._silent(self._rich_output_setup())
        await self._silent(self._remote_guard_code())

    def _remote_setup_code(self) -> str:
        return (
            f"import os, sys; "
            f"os.makedirs({repr(self.remote_notebook_dir)}, exist_ok=True); "
            f"os.chdir({repr(self.remote_notebook_dir)}); "
            f"sys.path.insert(0, {repr(self.remote_notebook_dir)}); "
            f"sys.path.insert(0, {repr(self.remote_root)}); "
            f"sys.path.insert(0, {repr(self.remote_mpynb_dir)})"
        )

    def _remote_virtual_cwd_setup(self) -> str:
        visible_working_dir = str(self.working_dir).replace("\\", "/")
        return (
            f"import os as _os\n"
            f"_clawss_real_getcwd = _os.getcwd\n"
            f"_clawss_real_root = {repr(self.remote_root)}\n"
            f"_clawss_visible_root = {repr(visible_working_dir)}\n"
            f"def _clawss_getcwd():\n"
            f"    _real = _clawss_real_getcwd().replace(chr(92), '/')\n"
            f"    if _real.startswith(_clawss_real_root):\n"
            f"        _rel = _real[len(_clawss_real_root):].lstrip('/')\n"
            f"        return _clawss_visible_root + ('/' + _rel if _rel else '')\n"
            f"    return _real\n"
            f"_os.getcwd = _clawss_getcwd\n"
            f"del _os\n"
        )

    def _remote_guard_code(self) -> str:
        mpd = repr(self.remote_mpynb_dir)
        reg = repr(f"{self.remote_mpynb_dir}/.session_registry.json")
        return f"""
import sys as _sys, json as _json
from pathlib import Path as _P
class _MpynbGuard:
    _s = _sys
    _j = _json
    _p = _P
    _mn = _P({mpd})
    _mr = _P({reg})
    def _read(self):
        try:
            return self._j.loads(self._mr.read_text('utf-8')) if self._mr.exists() else {{}}
        except Exception:
            return {{}}
    def find_spec(self, fullname, path, target=None):
        pts = fullname.split('.')
        if len(pts) < 2:
            return None
        pkg = pts[0]
        if not (self._mn / pkg).is_dir():
            return None
        reg = self._read()
        pr = reg.get(pkg, {{}})
        fn = '/'.join(pts[1:]) + '.py'
        if fn not in pr:
            prefix = '/'.join(pts[1:]) + '/'
            is_pkg = any(k.startswith(prefix) for k in pr) if len(pts) >= 2 else False
            if not is_pkg:
                raise ModuleNotFoundError(
                    f"Cannot import '{{fullname}}': '{{fn}}' in notebook '{{pkg}}' "
                    "has not been executed this session — run it first."
                )
        return None
_sys.meta_path.insert(0, _MpynbGuard())
del _sys, _json, _P, _MpynbGuard
"""

    async def _request(self, method: str, path: str, **kwargs):
        if self.http is None:
            raise RuntimeError("Remote session not started")
        response = await self.http.request(method, _url_with_path(self.base_url, path), **kwargs)
        response.raise_for_status()
        return response

    async def _ensure_kernel(self):
        if self.kernel_id:
            return
        await self._request("GET", "/api")
        response = await self._request("POST", "/api/kernels", json={"name": "python3"})
        self.kernel_id = (response.json() or {}).get("id")
        if not self.kernel_id:
            raise RuntimeError("Remote Jupyter server did not return a kernel id")

    async def _ensure_remote_dir(self, path: str):
        await self._request(
            "PUT",
            f"/api/contents/{quote(path, safe='/')}",
            json={"type": "directory"},
        )

    async def _upload_remote_file(self, rel_path: str, local_path: Path):
        remote_path = f"{self.remote_root}/{rel_path.replace('\\', '/')}"
        parent = str(Path(remote_path).parent).replace("\\", "/")
        await self._ensure_remote_dir(parent)
        data = local_path.read_bytes()
        try:
            payload = {"type": "file", "format": "text", "content": data.decode("utf-8")}
        except UnicodeDecodeError:
            payload = {
                "type": "file",
                "format": "base64",
                "content": base64.b64encode(data).decode("ascii"),
            }
        await self._request("PUT", f"/api/contents/{quote(remote_path, safe='/')}", json=payload)

    def _iter_local_files(self) -> List[tuple[str, Path]]:
        rows: List[tuple[str, Path]] = []
        for path in self.working_dir.rglob("*"):
            if not path.is_file():
                continue
            if not _should_sync_remote_path(path, self.working_dir):
                continue
            rel = str(path.relative_to(self.working_dir)).replace("\\", "/")
            rows.append((rel, path))
        return rows

    async def _sync_project(self):
        await self._ensure_remote_dir(self.remote_root)
        await self._ensure_remote_dir(self.remote_notebook_dir)
        local_hashes: dict[str, str] = {}
        for rel, path in self._iter_local_files():
            digest = hashlib.md5(path.read_bytes()).hexdigest()
            local_hashes[rel] = digest
            if self._synced_hashes.get(rel) == digest:
                continue
            await self._upload_remote_file(rel, path)
        for stale in sorted(set(self._synced_hashes) - set(local_hashes), reverse=True):
            remote_path = f"{self.remote_root}/{stale}"
            try:
                await self._request("DELETE", f"/api/contents/{quote(remote_path, safe='/')}")
            except Exception:
                pass
        self._synced_hashes = local_hashes

    async def _execute_remote(
        self,
        code: str,
        *,
        store_history: bool,
        on_output: Optional[Callable] = None,
        timeout: float = 300.0,
        stream_limit: Optional[int] = None,
    ) -> tuple[str, int]:
        await self._ensure_kernel()
        ws_url = _ws_url(
            self.base_url,
            f"/api/kernels/{self.kernel_id}/channels",
            {"session_id": str(uuid.uuid4())},
        )
        msg_id = uuid.uuid4().hex
        header = {
            "msg_id": msg_id,
            "username": "clawss",
            "session": uuid.uuid4().hex,
            "msg_type": "execute_request",
            "version": "5.3",
            "date": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        payload = {
            "channel": "shell",
            "header": header,
            "parent_header": {},
            "metadata": {},
            "content": {
                "code": code,
                "silent": False,
                "store_history": store_history,
                "allow_stdin": False,
                "stop_on_error": True,
            },
            "buffers": [],
        }
        out: List[str] = []
        err: Optional[str] = None
        count = self.execution_count
        buffered: List[dict] = []
        stream_bytes = 0
        truncated = False
        loop = asyncio.get_event_loop()
        deadline = loop.time() + timeout
        async with websockets.connect(ws_url, max_size=20 * 1024 * 1024, ping_interval=None) as ws:
            await ws.send(json.dumps(payload))
            while True:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    raise TimeoutError(f"remote kernel execution exceeded {timeout}s")
                raw = await asyncio.wait_for(ws.recv(), timeout=remaining)
                msg = json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
                parent = (msg.get("parent_header") or {}).get("msg_id")
                if parent != msg_id:
                    continue
                mt = msg.get("msg_type")
                content = msg.get("content") or {}
                if mt == "stream":
                    text = content.get("text", "")
                    if stream_limit is not None:
                        encoded = text.encode("utf-8")
                        remaining_bytes = stream_limit - stream_bytes
                        if truncated:
                            continue
                        if len(encoded) > remaining_bytes:
                            if remaining_bytes > 0:
                                text = encoded[:remaining_bytes].decode("utf-8", errors="ignore")
                                if on_output:
                                    buffered.append({"type": "stream", "name": content.get("name", "stdout"), "text": text})
                                else:
                                    out.append(text)
                            if on_output:
                                buffered.append({
                                    "type": "stream",
                                    "name": "stderr",
                                    "text": f"\n[clawss] Output truncated — exceeded {stream_limit // 1000} KB limit.\n",
                                })
                            truncated = True
                            stream_bytes = stream_limit
                            continue
                        stream_bytes += len(encoded)
                    if on_output:
                        buffered.append({"type": "stream", "name": content.get("name", "stdout"), "text": text})
                    elif content.get("name") == "stdout":
                        out.append(text)
                elif mt in {"display_data", "execute_result"} and on_output:
                    buffered.append({"type": "display", "data": content.get("data", {})})
                elif mt == "error":
                    err = f"{content.get('ename')}: {content.get('evalue')}"
                    if on_output:
                        tb = [ANSI_ESCAPE.sub("", line) for line in content.get("traceback", [])]
                        buffered.append({
                            "type": "error",
                            "ename": content.get("ename", "Error"),
                            "evalue": content.get("evalue", ""),
                            "traceback": KernelSession._clean_traceback(tb, ""),
                        })
                elif mt in {"execute_input", "execute_reply"}:
                    count = int(content.get("execution_count") or count)
                elif mt == "status" and content.get("execution_state") == "idle":
                    break
            if on_output and buffered:
                await KernelSession._flush_outputs(buffered, on_output)
        if err is not None and not on_output:
            raise RuntimeError(err)
        if err is not None and on_output:
            return "error", count
        return "".join(out), count

    async def _silent(self, code: str):
        await self._execute_remote(code, store_history=False, timeout=60.0)

    async def execute(
        self,
        cell_id: str,
        filename: str,
        source: str,
        imports_source: Optional[str],
        on_output: Callable,
    ) -> dict:
        self._current_task = asyncio.current_task()
        async with self._lock:
            self._running_cell_id = cell_id
            self.execution_count += 1
            count = self.execution_count
            await self._sync_project()
            remote_cell_path = f"{self.remote_cells_dir}/{filename.replace('\\', '/')}"
            await self._ensure_remote_dir(str(Path(remote_cell_path).parent).replace("\\", "/"))
            parts = filename[:-3].replace("/", ".").replace("\\", ".").split(".")
            module_name = ".".join(parts)
            parent_pkg_code = ""
            if len(parts) > 1:
                for i in range(1, len(parts)):
                    parent = ".".join(parts[:i])
                    parent_pkg_code += f"""
if {repr(parent)} not in __s.modules:
    __pkg = __t.ModuleType({repr(parent)})
    __pkg.__path__ = []
    __pkg.__package__ = {repr(parent)}
    __s.modules[{repr(parent)}] = __pkg
"""
            exec_code = f"""
import os as __o, types as __t, sys as __s
__o.makedirs({repr(str(Path(remote_cell_path).parent).replace('\\', '/'))}, exist_ok=True)
with open({repr(remote_cell_path)}, 'w', encoding='utf-8') as __f:
    __f.write({repr(source)})
__mod_name = {repr(module_name)}
__file_path = {repr(remote_cell_path)}
{parent_pkg_code}
"""
            if filename == "imports.py":
                exec_code += f"""
__mod = __t.ModuleType('imports')
__mod.__file__ = {repr(remote_cell_path)}
exec(compile({repr(source)}, 'imports.py', 'exec'), __mod.__dict__)
__s.modules['imports'] = __mod
__mpynb_imports_ns__ = {{k: v for k, v in __mod.__dict__.items() if not k.startswith('__')}}
del __t, __s, __o, __mod
"""
            else:
                exec_code += f"""
__s.modules.pop(__mod_name, None)
__mod = __t.ModuleType(__mod_name)
__mod.__file__ = __file_path
__mod.__dict__.update(globals().get('__mpynb_imports_ns__', {{}}))
exec(compile({repr(source)}, __file_path, 'exec'), __mod.__dict__)
__s.modules[__mod_name] = __mod
del __t, __s, __o, __mod_name, __file_path, __mod
"""
            start_t = time.time()
            status, remote_count = await self._execute_remote(
                exec_code,
                store_history=True,
                on_output=on_output,
                timeout=300.0,
                stream_limit=MAX_STREAM_BYTES,
            )
            elapsed = (time.time() - start_t) * 1000
            self._running_cell_id = None
            self._current_task = None
            return {
                "status": status,
                "execution_count": remote_count or count,
                "time_ms": round(elapsed, 1),
                "memory_delta_mb": 0.0,
            }

    async def run_capture(self, code: str, timeout: float = 60.0) -> str:
        async with self._lock:
            await self._sync_project()
            out, _count = await self._execute_remote(code, store_history=False, timeout=timeout)
            return out

    async def interrupt(self):
        if not self.kernel_id:
            return
        await self._request("POST", f"/api/kernels/{self.kernel_id}/interrupt")

    async def restart(self):
        await self._ensure_kernel()
        await self._request("POST", f"/api/kernels/{self.kernel_id}/restart")
        await asyncio.sleep(2)
        await self._sync_project()
        await self._silent(self._remote_setup_code())
        await self._silent(self._remote_virtual_cwd_setup())
        await self._silent(self._rich_output_setup())
        await self._silent(self._remote_guard_code())

    async def shutdown(self):
        if self.kernel_id:
            try:
                await self._request("DELETE", f"/api/kernels/{self.kernel_id}")
            except Exception:
                pass
            self.kernel_id = None
        if self.http is not None:
            await self.http.aclose()
            self.http = None
