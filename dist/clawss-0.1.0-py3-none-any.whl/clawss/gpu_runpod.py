from __future__ import annotations

from typing import Any, Dict, List

import httpx

RUNPOD_REST_BASE = "https://rest.runpod.io/v1"
RUNPOD_GRAPHQL_BASE = "https://api.runpod.io/graphql"


def _headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

def _error_text(response: httpx.Response) -> str:
    try:
        text = response.text.strip()
        if text:
            return text[:240]
    except Exception:
        pass
    return response.reason_phrase or f"HTTP {response.status_code}"


async def validate_runpod_key(api_key: str) -> None:
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(
            f"{RUNPOD_REST_BASE}/pods",
            headers={"Authorization": f"Bearer {api_key}"},
        )
    if response.status_code >= 400:
        raise httpx.HTTPStatusError(_error_text(response), request=response.request, response=response)


async def runpod_list_gpu_types(api_key: str) -> List[Dict[str, Any]]:
    query = "query { gpuTypes { id displayName memoryInGb } }"
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            RUNPOD_GRAPHQL_BASE,
            headers=_headers(api_key),
            json={"query": query},
        )
    if response.status_code >= 400:
        raise httpx.HTTPStatusError(_error_text(response), request=response.request, response=response)
    payload = response.json()
    if payload.get("errors"):
        raise RuntimeError(str(payload["errors"][0].get("message") or "RunPod GraphQL error"))
    rows = payload.get("data", {}).get("gpuTypes") or []
    return sorted(
        [
            {
                "id": str(row.get("id") or ""),
                "displayName": str(row.get("displayName") or row.get("id") or ""),
                "memoryInGb": row.get("memoryInGb"),
            }
            for row in rows
            if row.get("id")
        ],
        key=lambda row: row["displayName"],
    )


async def runpod_list_pods(api_key: str) -> List[Dict[str, Any]]:
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(
            f"{RUNPOD_REST_BASE}/pods",
            headers={"Authorization": f"Bearer {api_key}"},
        )
    if response.status_code >= 400:
        raise httpx.HTTPStatusError(_error_text(response), request=response.request, response=response)
    rows = response.json() or []
    pods = []
    for row in rows:
        ports = row.get("ports") or []
        proxy_url = None
        for port in ports:
            if isinstance(port, str) and port.endswith("/http"):
                proxy_url = f"https://{row.get('id')}-{port.split('/', 1)[0]}.proxy.runpod.net"
                break
        gpu = row.get("gpu") or {}
        pods.append(
            {
                "id": row.get("id"),
                "name": row.get("name") or row.get("id"),
                "desiredStatus": row.get("desiredStatus"),
                "imageName": row.get("imageName"),
                "gpuId": gpu.get("id"),
                "gpuDisplayName": gpu.get("displayName") or gpu.get("id"),
                "gpuCount": gpu.get("count"),
                "publicIp": row.get("publicIp"),
                "ports": ports,
                "proxyUrl": proxy_url,
            }
        )
    return pods


async def runpod_create_pod(api_key: str, data: Dict[str, Any]) -> Dict[str, Any]:
    payload = {
        "name": data["name"],
        "imageName": data["imageName"],
        "computeType": "GPU",
        "cloudType": data.get("cloudType") or "SECURE",
        "gpuCount": int(data.get("gpuCount") or 1),
        "gpuTypeIds": [data["gpuTypeId"]],
        "gpuTypePriority": "availability",
        "volumeInGb": int(data.get("volumeInGb") or 40),
        "containerDiskInGb": int(data.get("containerDiskInGb") or 40),
        "volumeMountPath": "/workspace",
        "ports": [f"{int(data.get('exposedHttpPort') or 8888)}/http"],
        "interruptible": bool(data.get("interruptible")),
    }
    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(
            f"{RUNPOD_REST_BASE}/pods",
            headers=_headers(api_key),
            json=payload,
        )
    if response.status_code >= 400:
        raise httpx.HTTPStatusError(_error_text(response), request=response.request, response=response)
    return response.json()


async def runpod_stop_pod(api_key: str, pod_id: str) -> Dict[str, Any]:
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            f"{RUNPOD_REST_BASE}/pods/{pod_id}/stop",
            headers={"Authorization": f"Bearer {api_key}"},
        )
    if response.status_code >= 400:
        raise httpx.HTTPStatusError(_error_text(response), request=response.request, response=response)
    return response.json()


async def runpod_delete_pod(api_key: str, pod_id: str) -> None:
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.delete(
            f"{RUNPOD_REST_BASE}/pods/{pod_id}",
            headers={"Authorization": f"Bearer {api_key}"},
        )
    if response.status_code >= 400:
        raise httpx.HTTPStatusError(_error_text(response), request=response.request, response=response)
